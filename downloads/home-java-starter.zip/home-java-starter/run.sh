#!/bin/sh
# ===========================================================================
#  run.sh  -  run one lesson file with the Java 17 that WPILib 2026 installed
#             (the macOS and Linux twin of run.cmd)
#
#    ./run.sh                     check that Java 17 is ready
#    ./run.sh HelloWorld          run lessons/HelloWorld.java
#    ./run.sh Methods check       run it with its self-check
#    ./run.sh answers/Methods     run the answer copy (only after you try!)
#
#  Why this file exists: typing one short command is easier than remembering
#  where Java lives. On macOS and Linux, WPILib 2026 installs into
#  ~/wpilib/2026 (the wpilib folder in your home folder).
#  "Permission denied"? Type  chmod +x run.sh  once, or use  sh run.sh HelloWorld
#  Mentors: if your 2026 JDK is somewhere else, set WPILIB_2026_JDK to that
#  jdk folder before running this file.
# ===========================================================================

# The folder this file is in, so it works from any folder.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# ---- 1. Find the WPILib 2026 Java (same rule the WPILib installer uses) ----
if [ -n "$WPILIB_2026_JDK" ]; then
  JDK=$WPILIB_2026_JDK
elif [ -n "$PUBLIC" ]; then
  JDK=$PUBLIC/wpilib/2026/jdk
else
  JDK=$HOME/wpilib/2026/jdk
fi
JAVA=$JDK/bin/java
if [ ! -x "$JAVA" ]; then
  echo "Could not find the Java that WPILib 2026 installs."
  echo "Looked for: $JAVA"
  echo "Install WPILib 2026 (Lesson 1, step 1) or ask a mentor for help."
  exit 2
fi
if ! "$JAVA" -version 2>&1 | grep 'version "17\.' >/dev/null; then
  echo "The Java found at $JDK is not Java 17."
  echo "These lessons need the Java 17 that comes with WPILib 2026. Ask a mentor."
  exit 2
fi

# ---- 2. No lesson name: just report that Java is ready --------------------
if [ $# -eq 0 ]; then
  echo "Java 17 from WPILib 2026 is ready."
  echo "Run a lesson file like this:  ./run.sh HelloWorld"
  exit 0
fi

# ---- 3. Work out which file was meant ---------------------------------------
# Accept HelloWorld, HelloWorld.java, lessons/HelloWorld.java,
# ./lessons/HelloWorld.java and answers/HelloWorld.
ARG=$1
case $ARG in
  ./*) ARG=${ARG#./} ;;
esac
FOLDER=lessons
case $ARG in
  answers/*) FOLDER=answers ;;
esac
NAME=${ARG##*/}
NAME=${NAME%.java}
FILE=$HERE/$FOLDER/$NAME.java
if [ ! -f "$FILE" ]; then
  echo "There is no $FOLDER/$NAME.java in this folder. Check the spelling."
  echo "The lesson files are:"
  for LESSON in "$HERE"/lessons/*.java; do
    LESSON=${LESSON##*/}
    echo "  ${LESSON%.java}"
  done
  exit 1
fi

# ---- 4. Run it. Java's own exit code is passed back to the Terminal. -------
if [ $# -ge 2 ]; then
  "$JAVA" "$FILE" "$2"
else
  "$JAVA" "$FILE"
fi
exit $?
