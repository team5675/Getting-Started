@echo off
rem ===========================================================================
rem  run.cmd  -  run one lesson file with the Java 17 that WPILib 2026 installed
rem
rem    .\run                        check that Java 17 is ready
rem    .\run HelloWorld             run lessons\HelloWorld.java
rem    .\run Methods check          run it with its self-check
rem    .\run answers\Methods        run the answer copy (only after you try!)
rem
rem  Why this file exists: typing one short command is easier than remembering
rem  where Java lives. On Windows, WPILib 2026 always installs into
rem  %PUBLIC%\wpilib\2026 (normally C:\Users\Public\wpilib\2026), for both
rem  "Install for this User" and "Install for all Users".
rem  Mentors: if your 2026 JDK is somewhere else, set WPILIB_2026_JDK to that
rem  jdk folder before running this file.
rem ===========================================================================
setlocal EnableExtensions DisableDelayedExpansion

rem ---- 1. Find the WPILib 2026 Java (same rule the WPILib installer uses) ----
if defined WPILIB_2026_JDK (
  set "JDK=%WPILIB_2026_JDK%"
) else if defined PUBLIC (
  set "JDK=%PUBLIC%\wpilib\2026\jdk"
) else (
  set "JDK=C:\Users\Public\wpilib\2026\jdk"
)
set "JAVA=%JDK%\bin\java.exe"
if not exist "%JAVA%" goto :nojava
"%JAVA%" -version 2>&1 | findstr /r /c:"version .17\." >nul
if errorlevel 1 goto :wrongjava

rem ---- 2. No lesson name: just report that Java is ready --------------------
if "%~1"=="" goto :ready

rem ---- 3. Work out which file was meant ---------------------------------------
rem Accept HelloWorld, HelloWorld.java, lessons\HelloWorld.java,
rem .\lessons\HelloWorld.java and answers\HelloWorld (forward slashes too).
set "ARG=%~1"
set "ARG=%ARG:/=\%"
if "%ARG:~0,2%"==".\" set "ARG=%ARG:~2%"
set "FOLDER=lessons"
if /i "%ARG:~0,8%"=="answers\" set "FOLDER=answers"
for %%F in ("%ARG%") do set "NAME=%%~nF"
set "FILE=%~dp0%FOLDER%\%NAME%.java"
if not exist "%FILE%" goto :nofile

rem ---- 4. Run it. Java's own exit code is passed back to the Terminal. -------
"%JAVA%" "%FILE%" %2
exit /b %ERRORLEVEL%

:ready
echo Java 17 from WPILib 2026 is ready.
echo Run a lesson file like this:  .\run HelloWorld
exit /b 0

:nofile
echo There is no %FOLDER%\%NAME%.java in this folder. Check the spelling.
echo The lesson files are:
for %%L in ("%~dp0lessons\*.java") do echo   %%~nL
exit /b 1

:nojava
echo Could not find the Java that WPILib 2026 installs.
echo Looked for: %JAVA%
echo Install WPILib 2026 (Lesson 1, step 1) or ask a mentor for help.
exit /b 2

:wrongjava
echo The Java found at %JDK% is not Java 17.
echo These lessons need the Java 17 that comes with WPILib 2026. Ask a mentor.
exit /b 2
