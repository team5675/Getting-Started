// Read the matching Java toolbox section, then do its change-and-predict task.
import java.util.ArrayList;
import java.util.EnumSet;

public class ListsPractice {
    enum Request { EJECT, RUN, HOLD }   // listed first = most important

    public static void main(String[] args) {
        // A list starts empty and grows each time you add to it.
        ArrayList<String> problems = new ArrayList<>();
        double batteryVolts = 12.1;
        boolean gyroConnected = false;
        if (batteryVolts < 12.3) {
            problems.add("Battery low: " + batteryVolts + " V");
        }
        if (!gyroConnected) {
            problems.add("Gyro not connected");
        }
        System.out.println(problems.size() + " problems");
        for (String problem : problems) {
            System.out.println("- " + problem);
        }
        System.out.println("First: " + problems.get(0));

        // A set of enum values: each value is either in the set or not.
        EnumSet<Request> active = EnumSet.noneOf(Request.class);
        active.add(Request.HOLD);
        active.add(Request.RUN);
        active.add(Request.RUN);            // already in the set: no change
        System.out.println("Active: " + active);
        System.out.println("Holding? " + active.contains(Request.HOLD));
        active.remove(Request.RUN);
        System.out.println("Active: " + active);
    }
}
