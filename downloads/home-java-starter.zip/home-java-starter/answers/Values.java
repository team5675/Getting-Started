// Team 5675 - 2. Variables and units
// TASK: distanceMeters takes speed in meters per second and time in seconds. Return the
// distance traveled at that constant speed. Use both inputs, not a fixed answer.
// HINT: Distance = speed times time. A negative speed represents motion in the opposite
// direction.
// ROBOT CONNECTION: Constants.Drive.SLOW_MODE_SCALE names a speed multiplier. Meaningful
// names and units prevent confusing meters, seconds and scale factors.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class Values {
    public static double distanceMeters(double speedMetersPerSecond, double seconds) {
        return speedMetersPerSecond * seconds;
    }

    // main is the entry point. Keep it as supplied; edit the exercise above.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        double speed = 1.5;
        double seconds = 2.0;
        System.out.println(distanceMeters(speed, seconds)); // Goal: 3.0
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("moving", 3.0, distanceMeters(1.5, 2.0));
        expect("stopped", 0.0, distanceMeters(0.0, 5.0));
        expect("reverse", -1.0, distanceMeters(-0.5, 2.0));
        expect("different time", 4.0, distanceMeters(0.5, 8.0));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
