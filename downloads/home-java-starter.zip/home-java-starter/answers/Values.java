// PART B: After the distance print inside main, write a run count starting at 4, a boolean readiness flag, and a String team name. Increase the count by one; print all three and compare a quoted name with the stored name. Change only the flag.
// TASK: Replace 0.0 with speedMetersPerSecond * seconds. Predict the distance first.
public class Values {
    public static void main(String[] args) {
        double speedMetersPerSecond = 1.5;
        double seconds = 2.0;
        double distanceMeters = speedMetersPerSecond * seconds;
        System.out.println("Distance: " + distanceMeters + " m");
        // PART B worked example. Try your own version before reading.
        int runs = 4;
        boolean ready = true;
        String teamName = "WiredCats";
        runs = runs + 1;
        System.out.println("teamName");
        System.out.println(teamName);
        System.out.println(runs);
        System.out.println(ready);
    }
}
