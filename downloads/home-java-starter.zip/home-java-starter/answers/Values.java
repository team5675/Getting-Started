// TASK: Replace 0.0 with speedMetersPerSecond * seconds. Predict the distance
// first.
// PART B: Below the PART B comment inside main, make int runs = 4, boolean
// ready = true and String teamName = "WiredCats". Add one to runs, then print
// "teamName" (quoted), teamName, runs and ready. Then change only ready to
// false and see which line changes.
public class Values {
    public static void main(String[] args) {
        double speedMetersPerSecond = 1.5;
        double seconds = 2.0;
        double distanceMeters = speedMetersPerSecond * seconds;
        System.out.println("Distance: " + distanceMeters + " m");
        // PART B worked example. Try your own version before reading.
        int runs = 4;
        boolean ready = true;
        String teamName = "WiredCats";
        runs = runs + 1;
        System.out.println("teamName");
        System.out.println(teamName);
        System.out.println(runs);
        System.out.println(ready);
    }
}
