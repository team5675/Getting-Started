// Read the matching Java toolbox section, then do its change-and-predict task.
public class OptionalPractice {
    static String describe(java.util.Optional<Double> meters) {
        if (meters.isPresent()) {
            return "Observed: " + meters.get();
        }
        return "No observation: keep estimate";
    }
    public static void main(String[] args) {
        System.out.println(describe(java.util.Optional.of(2.0)));
        System.out.println(describe(java.util.Optional.of(0.0)));
        System.out.println(describe(java.util.Optional.empty()));
    }
}
