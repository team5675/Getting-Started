// Team 5675 - Drill for Lesson 2 ("Run your first program")
// Extra practice after the lesson. Run it:  .\run FirstProgramDrill
// Check it:  .\run FirstProgramDrill check
// TASK: Do the three exercises inside main, in order.
//   1. Change ... to your first name, for example: My name is Morgan
//   2. Delete the two slashes at the start of the Robot ready line, run, read
//      the error, then fix the one missing character.
//   3. Add three println lines that print, one after another:
//        Robot: practice bot
//        Battery: OK
//        Ready!
// HINT: Each println needs its text in double quotes and ends with ;
// Capitals, spaces and the colon must match exactly.
// CHALLENGE (optional): make ONE println print two lines, Team 5675 and then
// WiredCats. Inside quotes, \n means "start a new line here". Then change
// CHECK_CHALLENGE to true so the check looks at it.
public class FirstProgramDrill {
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        // Check handling: leave these four lines as they are.
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        // Warm-up: predict the output of these three lines, then run.
        System.out.println("Drill 2 is running.");
        System.out.print("print() stays on the same line, ");
        System.out.println("and println() ends the line.");

        // Exercise 1: make it yours.
        System.out.println("My name is Morgan");

        // Exercise 2: repair a mistake. Delete the two slashes first.
        System.out.println("Robot ready");

        // Exercise 3: add your three println lines below this comment.
        System.out.println("Robot: practice bot");
        System.out.println("Battery: OK");
        System.out.println("Ready!");

        // CHALLENGE: your one println goes below this comment.
        System.out.println("Team 5675\nWiredCats");
    }

    private static void check() {
        java.util.List<String> lines = printedByMain();
        checked++;
        boolean named = false;
        for (String line : lines) {
            if (line.startsWith("My name is ") && !line.equals("My name is ...")) {
                named = true;
            }
        }
        if (!named) {
            failed++;
            System.out.println("TRY AGAIN: Exercise 1; expected My name is followed by your name; got "
                    + String.join(" / ", lines));
        }
        expectLines("Exercise 2", lines, "Robot ready");
        expectLines("Exercise 3", lines, "Robot: practice bot", "Battery: OK", "Ready!");
        if (CHECK_CHALLENGE) {
            expectLines("CHALLENGE", lines, "Team 5675", "WiredCats");
        }
        finish();
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks run your main or call your methods with several inputs.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static java.util.List<String> printedByMain() {
        java.io.PrintStream original = System.out;
        java.io.ByteArrayOutputStream captured = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(captured, true));
        try {
            main(new String[0]);
        } finally {
            System.setOut(original);
        }
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (String line : captured.toString().split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    private static void expectLines(String label, java.util.List<String> lines, String... wanted) {
        checked++;
        for (int start = 0; start + wanted.length <= lines.size(); start++) {
            boolean all = true;
            for (int i = 0; i < wanted.length; i++) {
                if (!lines.get(start + i).equals(wanted[i])) {
                    all = false;
                }
            }
            if (all) {
                return;
            }
        }
        failed++;
        System.out.println("TRY AGAIN: " + label + "; expected the line(s) " + String.join(" / ", wanted)
                + "; your program printed: " + String.join(" / ", lines));
    }

    private static void finish() {
        if (!CHECK_CHALLENGE) {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
