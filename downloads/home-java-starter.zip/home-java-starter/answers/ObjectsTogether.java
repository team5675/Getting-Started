// Team 5675 - 7A. Objects that work together
// TASK: Finish the parts marked TODO, in this order.
//   1. The Battery constructor: store label and firstReading in this
//      object's fields, and start readingCount at 1. Fix the label line.
//   2. record(volts): add 1 to readingCount. If volts is lower than
//      lowestVolts, store volts in lowestVolts.
//   3. The LowBatteryAlarm constructor: remember the battery it is given.
//   4. isSounding(): true when that battery's lowest reading is below
//      LIMIT_VOLTS, otherwise false.
//   5. Put final on the label field and on the alarm's battery field.
// HINT: this.label means this object's field; label alone means the
// parameter. A comparison such as a < b is already true or false, so it can
// be returned directly.
// ROBOT CONNECTION: KeepLightOn in the simulation starter is built the same
// way: private final PracticeLight light; and this.light = light; in its
// constructor. The command keeps the light object it was given.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
// PART B: Below the PART B comment in main, make a second battery named
// Match at 12.8 volts and an alarm for it. Record 12.5 on Match only. Print
// both alarms' answers and predict false for Match and true for Spare.
// CHALLENGE (optional): finish startNewMatch(volts) in Battery. Make volts the
// lowest reading and set readingCount back to 1; keep the label. Then change
// CHECK_CHALLENGE to true so the check looks at it.
public class ObjectsTogether {
    static final boolean CHECK_CHALLENGE = true;

    // One Battery object keeps the records for one battery.
    static class Battery {
        private final String label;
        private double lowestVolts;
        private int readingCount;

        Battery(String label, double firstReading) {
            this.label = label;
            this.lowestVolts = firstReading;
            this.readingCount = 1;
        }

        void record(double volts) {
            readingCount = readingCount + 1;
            if (volts < lowestVolts) {
                lowestVolts = volts;
            }
        }

        // CHALLENGE: start fresh for a new match, like the robot does when
        // autonomous begins. The label stays: it is the same battery.
        void startNewMatch(double volts) {
            lowestVolts = volts;
            readingCount = 1;
        }

        String getLabel() { return label; }
        double getLowestVolts() { return lowestVolts; }
        int getReadingCount() { return readingCount; }
    }

    // A LowBatteryAlarm watches the one Battery object it was given.
    static class LowBatteryAlarm {
        static final double LIMIT_VOLTS = 11.5; // made-up practice limit
        private final Battery battery;

        LowBatteryAlarm(Battery battery) {
            this.battery = battery;
        }

        boolean isSounding() {
            return battery.getLowestVolts() < LIMIT_VOLTS;
        }
    }

    // main is the entry point. Complete the TODO parts first.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        Battery spare = new Battery("Spare", 12.6);
        LowBatteryAlarm spareAlarm = new LowBatteryAlarm(spare);
        System.out.println(spare.getLabel() + " lowest " + spare.getLowestVolts()
                + " V, readings " + spare.getReadingCount());
        System.out.println("Spare alarm: " + spareAlarm.isSounding());
        spare.record(11.3);
        System.out.println(spare.getLabel() + " lowest " + spare.getLowestVolts()
                + " V, readings " + spare.getReadingCount());
        System.out.println("Spare alarm: " + spareAlarm.isSounding());
        // PART B: a second battery and its own alarm.
        Battery match = new Battery("Match", 12.8);
        LowBatteryAlarm matchAlarm = new LowBatteryAlarm(match);
        match.record(12.5);
        System.out.println("Match alarm: " + matchAlarm.isSounding());
        System.out.println("Spare alarm: " + spareAlarm.isSounding());
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static boolean isFinal(Class<?> type, String field) {
        try {
            return java.lang.reflect.Modifier.isFinal(type.getDeclaredField(field).getModifiers());
        } catch (NoSuchFieldException missing) {
            return false;
        }
    }

    private static void check() {
        Battery a = new Battery("Practice A", 12.6);
        expect("label stored by the constructor", "Practice A", String.valueOf(a.getLabel()));
        expect("first reading is the lowest so far", 12.6, a.getLowestVolts());
        expect("one reading after the constructor", 1, a.getReadingCount());
        a.record(12.1);
        expect("lower reading kept", 12.1, a.getLowestVolts());
        expect("reading count after one record", 2, a.getReadingCount());
        a.record(12.4);
        expect("higher reading does not replace the lowest", 12.1, a.getLowestVolts());
        expect("reading count after two records", 3, a.getReadingCount());
        Battery b = new Battery("Practice B", 12.8);
        expect("second battery has its own records", 12.8, b.getLowestVolts());
        expect("first battery unchanged by the second", 12.1, a.getLowestVolts());
        LowBatteryAlarm alarmB = new LowBatteryAlarm(b);
        expect("alarm quiet at 12.8 V", false, alarmB.isSounding());
        b.record(11.5);
        expect("exactly 11.5 V is not below the limit", false, alarmB.isSounding());
        b.record(11.3);
        expect("alarm sees a reading recorded after it was made", true, alarmB.isSounding());
        LowBatteryAlarm alarmA = new LowBatteryAlarm(a);
        expect("alarm for the other battery stays quiet", false, alarmA.isSounding());
        expect("label field is final", true, isFinal(Battery.class, "label"));
        expect("alarm's battery field is final", true, isFinal(LowBatteryAlarm.class, "battery"));
        if (CHECK_CHALLENGE) {
            Battery c = new Battery("Practice C", 12.6);
            LowBatteryAlarm alarmC = new LowBatteryAlarm(c);
            c.record(11.2);
            c.startNewMatch(12.7);
            expect("CHALLENGE: new match starts at the new reading", 12.7, c.getLowestVolts());
            expect("CHALLENGE: new match has one reading", 1, c.getReadingCount());
            expect("CHALLENGE: new match keeps the label", "Practice C", String.valueOf(c.getLabel()));
            expect("CHALLENGE: the alarm sees the fresh start", false, alarmC.isSounding());
        } else {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
