// Read the matching Java toolbox section, then do its change-and-predict task.
public class CallbackPractice {
    // A pretend path follower. Each loop it works out one speed and hands it
    // to the callback it was given. The follower decides WHEN to call it;
    // your lambda decides WHAT happens with the speed.
    static void followPath(java.util.function.DoubleConsumer output) {
        double[] speeds = {0.25, 0.5, 0.25};
        for (double speed : speeds) {
            output.accept(speed);
        }
    }

    // The same follower, but each loop it hands over TWO values: a speed and
    // an extra voltage. Your lambda receives both; it may use only one.
    static void followPathWithExtra(java.util.function.BiConsumer<Double, Double> output) {
        double[] speeds = {0.25, 0.5, 0.25};
        for (double speed : speeds) {
            output.accept(speed, 0.4);
        }
    }

    public static void main(String[] args) {
        // One value in: speed is the parameter name; the follower supplies it.
        followPath(speed -> System.out.println("drive " + speed));
        // Two values in: both names go inside the parentheses.
        followPathWithExtra((speed, extraVolts) -> System.out.println("drive " + speed));
    }
}
