// Read the matching Java toolbox section, then perform its change-and-predict task.
public class LambdaPractice {
    static class Controls {
        double value = 1.0;
        void show() { System.out.println(value); }
    }
    public static void main(String[] args) {
        Controls controls = new Controls();
        java.util.function.DoubleSupplier live = () -> controls.value;
        System.out.println(live.getAsDouble()); // 1.0
        controls.value = 2.0;
        System.out.println(live.getAsDouble()); // 2.0
        Runnable display = controls::show;
        display.run(); // 2.0
    }
}
