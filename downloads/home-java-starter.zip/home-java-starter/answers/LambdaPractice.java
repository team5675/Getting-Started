// Read the matching Java toolbox section, then do its change-and-predict task.
public class LambdaPractice {
    static class Controls {
        double value = 1.0;
        void show() { System.out.println(value); }
    }
    public static void main(String[] args) {
        Controls controls = new Controls();
        double saved = controls.value; // a copy of the number, taken now
        java.util.function.DoubleSupplier live = () -> controls.value;
        controls.value = 2.0;
        System.out.println(saved);              // 1.0
        System.out.println(live.getAsDouble()); // 2.0
        Runnable display = controls::show;
        display.run(); // 2.0
    }
}
