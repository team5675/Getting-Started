// Team 5675 - Pose math (Advanced 1-3: pose, swerve, odometry)
// TASK: distance(dx,dy) returns straight-line distance using Math.hypot.
// moduleSpeed(vx,vy) returns the speed of each ideal swerve module during
// translation with NO rotation. nextX(x,vx,seconds) advances a field X
// coordinate at constant field-X velocity. These simplified numbers are not a
// robot estimator.
// HINT: Math.hypot(a,b) computes sqrt(a*a + b*b). nextX is starting X plus
// velocity times time. Turning robots require the later WPILib kinematics
// lesson.
// ROBOT CONNECTION: FieldPointAim subtracts target and robot translations.
// CommandSwerveDrivetrain owns a Pose2d and logs both fused pose and
// wheels/gyro-only odometry. The real library handles heading, turning and all
// four modules.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class PoseMath {
    public static double distance(double dx, double dy) { return Math.hypot(dx, dy); }
    public static double moduleSpeed(double vx, double vy) { return Math.hypot(vx, vy); }
    public static double nextX(double x, double vx, double seconds) { return x + vx * seconds; }

    // main is the entry point. Complete the exercise methods first.
    // Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(distance(3.0, 4.0)); // 5.0 m
        System.out.println(moduleSpeed(0.6, 0.8)); // 1.0 m/s, NO rotation
        System.out.println(nextX(2.0, -0.5, 2.0)); // 1.0 m
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("distance", 5.0, distance(3, 4));
        expect("same point", 0.0, distance(0, 0));
        expect("negative offsets", 5.0, distance(-3, -4));
        expect("translation", 1.0, moduleSpeed(0.6, 0.8));
        expect("stationary modules", 0.0, moduleSpeed(0, 0));
        expect("reverse odometry", 1.0, nextX(2, -0.5, 2));
        expect("no elapsed time", 2.0, nextX(2, 3, 0));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
