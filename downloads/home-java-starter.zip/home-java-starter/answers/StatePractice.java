// Read the matching Java toolbox section, then do its change-and-predict task.
public class StatePractice {
    enum Mode { DISABLED, MANUAL, AUTO }
    static String describe(Mode mode) {
        switch (mode) {
            case DISABLED: return "Stopped";
            case MANUAL: return "Driver input";
            case AUTO: return "Scheduled path";
            default: throw new IllegalArgumentException("Unknown mode");
        }
    }
    public static void main(String[] args) {
        System.out.println(describe(Mode.DISABLED));
        System.out.println(describe(Mode.MANUAL));
        System.out.println(describe(Mode.AUTO));
    }
}
