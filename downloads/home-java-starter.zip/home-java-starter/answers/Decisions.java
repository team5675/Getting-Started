// TASK: Print LOW below 11.0, CHECK below 12.0, READY otherwise. These are fictional teaching thresholds. Try 10.9, 11.0 and 12.0.
public class Decisions {
    public static void main(String[] args) {
        double volts = 11.0;
        if (volts < 11.0) {
            System.out.println("LOW");
        } else if (volts < 12.0) {
            System.out.println("CHECK");
        } else {
            System.out.println("READY");
        }
    }
}
