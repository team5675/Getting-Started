// TASK: Print LOW below 11.0, CHECK below 12.0, READY otherwise. These are
// fictional teaching thresholds. Try 10.9, 11.0 and 12.0.
// PART B: Below the PART B comment, after the voltage chain, declare boolean
// enabled = false and write an if/else that prints MOVING when enabled is true
// and STOPPED otherwise. Run it, then change false to true. Then record the
// voltage outputs for 10.9, 11.0, 11.9 and 12.0 in learning-notes.txt.
public class Decisions {
    public static void main(String[] args) {
        double volts = 11.0;
        if (volts < 11.0) {
            System.out.println("LOW");
        } else if (volts < 12.0) {
            System.out.println("CHECK");
        } else {
            System.out.println("READY");
        }
        // PART B worked example. Try your own version before reading.
        boolean enabled = false;
        if (enabled) { System.out.println("MOVING"); }
        else { System.out.println("STOPPED"); }
    }
}
