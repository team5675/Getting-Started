// Team 5675 - Drill for Lesson 4 ("Choose with if and else")
// Extra practice after the lesson. Run it:  .\run DecisionsDrill
// Check it:  .\run DecisionsDrill check
// On a Mac, type ./run instead of .\run
// TASK: Warm-up: run the distance decision. Exercise 1: change 0.8 to 1.0,
// then to 1.2, and predict each result before you run. Exercise 2: finish
// batteryAdvice below main with if / else if / else:
//     below 11.5 volts                    ->  Change the battery
//     11.5 up to, but not including, 12.3 ->  OK for practice
//     12.3 volts or more                  ->  Ready for a match
// HINT: return hands an answer back to the line that asked (Lesson 5 explains
// it fully). Put one return inside each of the three branches. Exactly 11.5
// is not below 11.5.
// CHALLENGE (optional): finish inAimRange. Aiming is allowed only when the
// robot is enabled and the target is from 2.0 to 4.5 meters away, including
// exactly 2.0 and 4.5. Use an if inside an if. Lesson 7B shows a one-line way.
// Then change CHECK_CHALLENGE to true. The limits are made up for practice.
public class DecisionsDrill {
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        // Check handling: leave these four lines as they are.
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        // Warm-up and Exercise 1: predict, then run.
        double distanceMeters = 0.8;
        if (distanceMeters < 1.0) {
            System.out.println("Too close");
        } else {
            System.out.println("Clear");
        }

        // Exercise 2: these lines ask batteryAdvice and print its answers.
        System.out.println("11.2 volts: " + batteryAdvice(11.2));
        System.out.println("11.5 volts: " + batteryAdvice(11.5));
        System.out.println("12.3 volts: " + batteryAdvice(12.3));

        // CHALLENGE: these lines ask inAimRange.
        System.out.println("Enabled, 3.0 m: " + inAimRange(true, 3.0));
        System.out.println("Disabled, 3.0 m: " + inAimRange(false, 3.0));
    }

    static String batteryAdvice(double volts) {
        if (volts < 11.5) {
            return "Change the battery";
        } else if (volts < 12.3) {
            return "OK for practice";
        } else {
            return "Ready for a match";
        }
    }

    static boolean inAimRange(boolean enabled, double distanceMeters) {
        if (enabled) {
            if (distanceMeters >= 2.0) {
                if (distanceMeters <= 4.5) {
                    return true;
                }
            }
        }
        return false;
    }

    private static void check() {
        expect("11.2 V is below 11.5", "Change the battery", batteryAdvice(11.2));
        expect("11.49 V is still below 11.5", "Change the battery", batteryAdvice(11.49));
        expect("exactly 11.5 V is not below 11.5", "OK for practice", batteryAdvice(11.5));
        expect("12.29 V is below 12.3", "OK for practice", batteryAdvice(12.29));
        expect("exactly 12.3 V counts as 12.3 or more", "Ready for a match", batteryAdvice(12.3));
        expect("12.9 V", "Ready for a match", batteryAdvice(12.9));
        if (CHECK_CHALLENGE) {
            expect("CHALLENGE exactly 2.0 m", true, inAimRange(true, 2.0));
            expect("CHALLENGE exactly 4.5 m", true, inAimRange(true, 4.5));
            expect("CHALLENGE 1.99 m is too close", false, inAimRange(true, 1.99));
            expect("CHALLENGE 4.51 m is too far", false, inAimRange(true, 4.51));
            expect("CHALLENGE disabled means no", false, inAimRange(false, 3.0));
        }
        finish();
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks run your main or call your methods with several inputs.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static java.util.List<String> printedByMain() {
        java.io.PrintStream original = System.out;
        java.io.ByteArrayOutputStream captured = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(captured, true));
        try {
            main(new String[0]);
        } finally {
            System.setOut(original);
        }
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (String line : captured.toString().split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    private static void expectLines(String label, java.util.List<String> lines, String... wanted) {
        checked++;
        for (int start = 0; start + wanted.length <= lines.size(); start++) {
            boolean all = true;
            for (int i = 0; i < wanted.length; i++) {
                if (!lines.get(start + i).equals(wanted[i])) {
                    all = false;
                }
            }
            if (all) {
                return;
            }
        }
        failed++;
        System.out.println("TRY AGAIN: " + label + "; expected the line(s) " + String.join(" / ", wanted)
                + "; your program printed: " + String.join(" / ", lines));
    }

    private static void finish() {
        if (!CHECK_CHALLENGE) {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
