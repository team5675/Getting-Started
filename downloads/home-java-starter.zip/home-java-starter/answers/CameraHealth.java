// Team 5675 - Health and fresh measurements (Advanced 7)
// TASK: Return DISCONNECTED if heartbeat is false. Otherwise return BAD_TIME
// for non-finite or negative ageSeconds; STALE for ageSeconds > 0.5; REJECTED
// if accepted is false; or READY. This is an exercise policy, not the robot's
// exact threshold logic.
// HINT: Use Double.isFinite(ageSeconds) and ! for NOT. Check in the stated
// order. A fresh heartbeat does not prove a usable pose exists.
// ROBOT CONNECTION: LimelightNT watches a changing heartbeat. VisionSubsystem
// checks measurement timestamps and rejection reasons. A historical seed is
// different from a recently accepted camera correction.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class CameraHealth {
    public static String verdict(boolean heartbeat, double ageSeconds, boolean accepted) {
        if (!heartbeat) { return "DISCONNECTED"; }
        if (!Double.isFinite(ageSeconds) || ageSeconds < 0.0) { return "BAD_TIME"; }
        if (ageSeconds > 0.5) { return "STALE"; }
        if (!accepted) { return "REJECTED"; }
        return "READY";
    }

    // main is the entry point. Complete the exercise methods first.
    // Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(verdict(true, 0.1, true)); // READY
        System.out.println(verdict(true, 2.0, true)); // STALE
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("disconnected", "DISCONNECTED", verdict(false, 0.1, true));
        expect("future", "BAD_TIME", verdict(true, -0.1, true));
        expect("NaN", "BAD_TIME", verdict(true, Double.NaN, true));
        expect("infinity", "BAD_TIME", verdict(true, Double.POSITIVE_INFINITY, true));
        expect("stale", "STALE", verdict(true, 0.501, true));
        expect("exact boundary", "READY", verdict(true, 0.5, true));
        expect("rejected", "REJECTED", verdict(true, 0.1, false));
        expect("ready", "READY", verdict(true, 0.1, true));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
