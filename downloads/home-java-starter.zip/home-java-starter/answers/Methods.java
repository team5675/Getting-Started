// Team 5675 - 5. Methods (Java functions)
// TASK: Implement meters(cm): 100 centimeters = 1 meter. Then implement
// clamp(value, low, high): values below low become low, above high become high,
// and values between stay unchanged. Assume low <= high.
// HINT: Divide centimeters by 100.0. For clamp, return early from the two
// out-of-range cases; otherwise return value.
// PART B: Define a double minutes(double seconds) method inside Methods but
// outside main. Return fractional minutes (60 seconds per minute). Call it
// inside main with 120.0 and 30.0; store the first result before printing.
// Expect 2.0 and 0.5; also check 0.0. The supplied check command tests meters
// and clamp, not this new method.
// ROBOT CONNECTION: VisionSubsystem.xyStdDevMeters takes tag count and distance
// and returns one uncertainty number. Its last line clamps the result to a
// permitted range.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class Methods {
    public static double meters(double centimeters) {
        return centimeters / 100.0;
    }

    public static double clamp(double value, double low, double high) {
        if (value < low) { return low; }
        if (value > high) { return high; }
        return value;
    }

    // PART B: a separate method definition, outside main.
    public static double minutes(double seconds) {
        return seconds / 60.0;
    }

    // main is the entry point. Complete the exercise methods first.
    // Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(meters(75.0)); // 0.75
        System.out.println(clamp(1.5, -1.0, 1.0)); // 1.0
        // PART B: calls go inside main; returning alone does not print.
        double durationMinutes = minutes(120.0);
        System.out.println(durationMinutes); // 2.0
        System.out.println(minutes(30.0)); // 0.5
        System.out.println(minutes(0.0)); // 0.0
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("unit conversion", 0.75, meters(75.0));
        expect("whole meter", 1.0, meters(100.0));
        expect("lower clamp", -1.0, clamp(-2.0, -1.0, 1.0));
        expect("upper clamp", 1.0, clamp(2.0, -1.0, 1.0));
        expect("inside", 0.3, clamp(0.3, -1.0, 1.0));
        expect("boundary", -1.0, clamp(-1.0, -1.0, 1.0));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
