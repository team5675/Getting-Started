// Read the matching Java toolbox section, then perform its change-and-predict task.
public class InheritancePractice {
    static class Sensor { int readValue() { return 0; } }
    static class SimSensor extends Sensor {
        @Override int readValue() { return 7; }
    }
    public static void main(String[] args) {
        Sensor sensor = new SimSensor();
        System.out.println(sensor.readValue()); // 7, using the subclass behavior.
    }
}
