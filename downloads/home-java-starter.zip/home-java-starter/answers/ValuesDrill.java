// Team 5675 - Drill for Lesson 3 ("Give values useful names")
// Extra practice after the lesson. Run it:  .\run ValuesDrill
// Check it:  .\run ValuesDrill check
// On a Mac, type ./run instead of .\run
// TASK: Do the three exercises inside main, in order.
//   1. Below the Exercise 1 comment, give batteryVolts the new value 12.1,
//      then print it with the same Battery: ... volts message as above.
//   2. Full speed is 4.0 m/s and slow mode is half of full speed. Replace
//      the two 0.0 values so the program prints  Slow speed: 2.0 m/s
//   3. Add a line that prints exactly  Tags: 2  using tagsSeen.
// HINT: The variable already exists, so do not write double again when you
// change it. Text goes in quotes; a variable's name does not.
// CHALLENGE (optional): the 2026 REBUILT teleop period lasts 140 seconds.
// Make an int variable for 140, then use / and % to print  Teleop: 2:20
// For ints, 140 / 60 is 2 (the decimal part is dropped) and 140 % 60 is 20
// (the remainder). Lesson 7B explains both. Then change CHECK_CHALLENGE to
// true.
public class ValuesDrill {
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        // Check handling: leave these four lines as they are.
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        // Warm-up: three kinds of value. Predict the two lines, then run.
        double batteryVolts = 12.6;
        int tagsSeen = 2;
        String cameraName = "limelight-front";
        System.out.println("Battery: " + batteryVolts + " volts");
        System.out.println(cameraName + " sees " + tagsSeen + " tags");

        // Exercise 1: change batteryVolts, then print it again.
        batteryVolts = 12.1;
        System.out.println("Battery: " + batteryVolts + " volts");

        // Exercise 2: replace the two 0.0 values.
        double maxSpeedMetersPerSecond = 4.0;
        double slowScale = 0.5;
        double slowSpeed = maxSpeedMetersPerSecond * slowScale;
        System.out.println("Slow speed: " + slowSpeed + " m/s");

        // Exercise 3: predict these two lines first. Why are they different?
        System.out.println("tagsSeen");
        System.out.println(tagsSeen);
        // Now add your Tags: line below this comment.
        System.out.println("Tags: " + tagsSeen);

        // CHALLENGE: your teleop clock goes below this comment.
        int teleopSeconds = 140;
        System.out.println("Teleop: " + teleopSeconds / 60 + ":" + teleopSeconds % 60);
    }

    private static void check() {
        java.util.List<String> lines = printedByMain();
        expectLines("Exercise 1 (keep the first line)", lines, "Battery: 12.6 volts");
        expectLines("Exercise 1", lines, "Battery: 12.1 volts");
        expectLines("Exercise 2", lines, "Slow speed: 2.0 m/s");
        expectLines("Exercise 3", lines, "Tags: 2");
        if (CHECK_CHALLENGE) {
            expectLines("CHALLENGE", lines, "Teleop: 2:20");
        }
        finish();
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks run your main or call your methods with several inputs.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static java.util.List<String> printedByMain() {
        java.io.PrintStream original = System.out;
        java.io.ByteArrayOutputStream captured = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(captured, true));
        try {
            main(new String[0]);
        } finally {
            System.setOut(original);
        }
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (String line : captured.toString().split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    private static void expectLines(String label, java.util.List<String> lines, String... wanted) {
        checked++;
        for (int start = 0; start + wanted.length <= lines.size(); start++) {
            boolean all = true;
            for (int i = 0; i < wanted.length; i++) {
                if (!lines.get(start + i).equals(wanted[i])) {
                    all = false;
                }
            }
            if (all) {
                return;
            }
        }
        failed++;
        System.out.println("TRY AGAIN: " + label + "; expected the line(s) " + String.join(" / ", wanted)
                + "; your program printed: " + String.join(" / ", lines));
    }

    private static void finish() {
        if (!CHECK_CHALLENGE) {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
