// PART B: Inside main, add a second println about something you want to learn. Predict both lines, run, then change only the second message. For the repair exercise, remove its semicolon, read the first error, restore it, and run successfully.
// TASK: Run once. Then change only the message to Hello, WiredCats!
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, WiredCats!");
        // PART B worked example. Try your own version before reading.
        System.out.println("I want to help the robot follow a path.");
    }
}
