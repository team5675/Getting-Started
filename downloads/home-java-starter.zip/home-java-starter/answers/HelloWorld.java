// Team 5675 - 1. Hello World
// TASK: Run this file first: main prints Hello, World! Then change greeting() to return
// Hello, WiredCats! exactly. Text inside quotes is data; println displays it.
// HINT: Keep the quotation marks. The exclamation point is part of the text.
// ROBOT CONNECTION: AutoRoutines registers LogMarker to print a message when an auto reaches
// that step. Robot telemetry uses Logger.recordOutput for named values.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class HelloWorld {
    public static String greeting() {
        return "Hello, WiredCats!";
    }

    // main is the entry point. Keep it as supplied; edit the exercise above.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println("Hello, World!");
        System.out.println(greeting());
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("greeting", "Hello, WiredCats!", greeting());
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
