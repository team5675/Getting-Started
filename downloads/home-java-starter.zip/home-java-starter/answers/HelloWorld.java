// TASK: Run once. Then change only the message to Hello, WiredCats!
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, WiredCats!");
    }
}
