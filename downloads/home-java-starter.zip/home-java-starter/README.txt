TEAM 5675 - HOME JAVA STARTER - 13 October 2026

1. Install stable WPILib 2026.2.1 and its VS Code from the official release:
   https://github.com/wpilibsuite/allwpilib/releases/tag/v2026.2.1
   Mount the Windows x64 ISO, run WPILibInstaller.exe, select Everything and
   download VS Code. Windows 11 x64. Internet needed for installation.
2. Extract this entire ZIP to a writable local folder (for example C:\dev).
3. In WPILib VS Code, File > Open Folder > home-java-starter.
4. Terminal > New Terminal. Select your INSTALLED JDK path (do not guess):
   $javaForLessons = "C:\Users\Public\wpilib\2026\jdk\bin\java.exe"
   & $javaForLessons -version
   The stable 2026 installation should report Java 17. A current-user install
   may be under your own user folder; locate its jdk/bin/java.exe in File Explorer.
5. Run the first file:
   & $javaForLessons .\lessons\HelloWorld.java
   First line: Hello, World! Second line: TODO (the exercise is unfinished).
6. Read TASK at the top, edit the exercise, save, then check:
   & $javaForLessons .\lessons\HelloWorld.java check
   Correct answer: PASS: 1 checks. Explain WHY each result is right.
7. Replace HelloWorld with the next file name below. No checks are silently
   skipped. TRY AGAIN means the program ran but its answer needs work.

Order: HelloWorld, Values, Decisions, Methods, Loops, Objects, Arrays,
       PoseMath, CameraHealth, Debugging.
Read the matching teaching page and keep a learning-notes.txt file:
I predicted / I observed / I changed / I can explain / My next step.

Each file is independent. A broken exercise does not block another file.
Ctrl+C stops an accidental endless loop. Fix the FIRST compiler error first.
The answers folder holds completed examples: compare AFTER trying.
Do not move answers into lessons or edit robot code for these exercises.
No build.gradle, Gradle, robot simulator, vendor libraries, account or robot
is required. These are plain Java source programs run by the selected JDK.
Do not use the WPILib project importer. No install or security settings change
is needed to run them after Java is installed. Downloads work offline afterward.

Guide: https://team5675.github.io/Getting-Started/home-java.html
Source: site/build_home_java.py in the mentor's FRC2027 workspace.
These plain Java sources target Java 17 and also run on the mentor JDK 25.
The team will move robot lessons to released 2027 tools after a mentor verifies
the complete stack. Alpha installation is not required for beginner lessons.
