WIRED CATS 5675 - JAVA FOUNDATIONS - 20 October 2026
The same plain-Java route is used at home and in class. No robot, Gradle,
vendor libraries or GitHub account is needed for these files.
Install WPILib 2026.2.1 (it includes VS Code and Java 17) from the official release:
https://github.com/wpilibsuite/allwpilib/releases/tag/v2026.2.1
Extract ALL of this ZIP to C:\dev, so that you get C:\dev\home-java-starter.
In 2026 WPILib VS Code: File > Open Folder > C:\dev\home-java-starter.
Open Terminal > New Terminal and check that Java is ready:
  .\run
Then run a lesson file by its name:
  .\run HelloWorld
run.cmd uses the Java 17 that WPILib 2026 installs in C:\Users\Public\wpilib\2026
(for both install options), so you never type where Java lives.
On a Mac: extract to the dev folder in your home folder (~/dev/home-java-starter)
and type ./run (a forward slash) where these notes say .\run, for example
./run HelloWorld. The file named run (no .cmd) is the Mac launcher; it uses the
Java 17 that WPILib 2026 installs in ~/wpilib/2026. Save with Cmd+S on a Mac.
.\run HelloWorld prints Hello, World! Change the message to Hello, WiredCats!, SAVE (Ctrl+S),
and run the same command again. The program exits after printing.

Order and exact files:
Lesson 2 HelloWorld.java; Lesson 3 Values.java; Lesson 4 Decisions.java;
Lesson 5 Methods.java; Lesson 6 Loops.java; Lesson 7 ObjectsPractice.java;
Lesson 7A ObjectsTogether.java; Lesson 7B TextAndConditions.java.
More practice after Lessons 2-6, one drill each, with self-checks:
FirstProgramDrill, ValuesDrill, DecisionsDrill, MethodsDrill, LoopsDrill.
Later, each named on its own page: InheritancePractice, LambdaPractice,
CallbackPractice, OptionalPractice, StatePractice and ListsPractice (the five
Java toolbox pages); ArrayPractice (Robot basics 2); Debugging (Debugging and logs);
PoseMath (Advanced 3); CameraHealth (Advanced 7).
Read TASK in the file. For Lessons 2-4 compare your output with the page and
try its boundary cases. The drills, and every lesson file from Methods on,
have supplied checks:
  .\run Methods check
The later unfinished exercises report TRY AGAIN until you finish their TASK.
Each file stands alone. Fix the FIRST compiler error. Ctrl+C stops an endless
loop; if Windows asks "Terminate batch job (Y/N)?", type Y and press Enter. Compare answers AFTER trying, keeping lessons and answers separate.
Never compile both folders together: they contain duplicate class names.
Record prediction, result, one boundary case and explanation in learning-notes.txt.
After Lesson 7B, download the separate simulation starter (the robot project step).
Guide: https://team5675.github.io/Getting-Started/lesson-1-setup.html
Editable source: site/course-src/home-java-starter in the mentor workspace.

The page explains where each edit belongs. Do not paste a second class or main
into a supplied file. TASK is the guided exercise; PART B asks for your own change.
The supplied self-checks cover the original TASK. New Part B output is checked by
your prediction and the page's expected examples, not by an earlier PASS.
Extra help: https://team5675.github.io/Getting-Started/extra-help.html
Keep Java 17 even when an outside tutorial recommends a newer version.
