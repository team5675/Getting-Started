WIRED CATS 5675 - JAVA FOUNDATIONS - 15 October 2026
The same plain-Java route is used at home and in class. No robot, Gradle,
vendor libraries or GitHub account is needed for these files.
Install WPILib 2026.2.1 and its Java 17/VS Code tools from the official release:
https://github.com/wpilibsuite/allwpilib/releases/tag/v2026.2.1
Extract ALL of this ZIP to a writable local folder, for example C:\dev.
In WPILib VS Code: File > Open Folder > the extracted home-java-starter.
Open Terminal > New Terminal (PowerShell). Select the installed 2026 Java:
  $javaForLessons = 'C:\Users\Public\wpilib\2026\jdk\bin\java.exe'
  & $javaForLessons -version
That example is an all-users installation. A current-user installation may
be under your own user folder. Find the actual jdk/bin/java.exe; expect Java 17.
Do not use bare java if it selects an old Java or the 2027 alpha tools.
  & $javaForLessons .\lessons\HelloWorld.java
It prints Hello, World! Change the message to Hello, WiredCats!, SAVE (Ctrl+S),
and run the same command again. The program exits after printing.

Order and exact files:
Lesson 2 HelloWorld.java; Lesson 3 Values.java; Lesson 4 Decisions.java;
Lesson 5 Methods.java; Lesson 6 Loops.java; Lesson 7 ObjectsPractice.java.
Later: ArrayPractice.java, PoseMath.java, CameraHealth.java, Debugging.java.
Read TASK in the file. For the first three lessons compare your output with
the page and try its boundary cases. Starting at Methods, supplied checks run:
  & $javaForLessons .\lessons\Methods.java check
The later unfinished exercises report TRY AGAIN until you finish their TASK.
Each file stands alone. Fix the FIRST compiler error. Ctrl+C stops an endless
loop. Compare answers AFTER trying, keeping lessons and answers separate.
Never compile both folders together: they contain duplicate class names.
Record prediction, result, one boundary case and explanation in learning-notes.txt.
After objects, download the separate simulation starter for Lesson 8.
Guide: https://team5675.github.io/Getting-Started/lesson-1-setup.html
Editable source: site/course-src/home-java-starter in the mentor workspace.
