// Team 5675 - 5. Methods (Java functions)
// TASK: Implement meters(cm): 100 centimeters = 1 meter. Then implement
// clamp(value, low, high): values below low become low, above high become high,
// and values between stay unchanged. Assume low <= high.
// HINT: Divide centimeters by 100.0. For clamp, return early from the two
// out-of-range cases; otherwise return value.
// PART B: At the first PART B comment (outside main), write a double
// minutes(double seconds) method that returns fractional minutes (60 seconds
// per minute). At the second (inside main), store minutes(120.0) in a variable
// and print it, then print minutes(30.0) and minutes(0.0). Expect 2.0, 0.5
// and 0.0. The supplied check command tests meters and clamp, not this method.
public class Methods {
    public static double meters(double centimeters) {
        return 0.0; // TODO
    }

    public static double clamp(double value, double low, double high) {
        return 0.0; // TODO
    }

    // PART B: your minutes method goes here, outside main.

    // main is the entry point. Complete the exercise methods first.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(meters(75.0)); // 0.75
        System.out.println(clamp(1.5, -1.0, 1.0)); // 1.0
        // PART B: your calls to minutes go here.
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("unit conversion", 0.75, meters(75.0));
        expect("whole meter", 1.0, meters(100.0));
        expect("lower clamp", -1.0, clamp(-2.0, -1.0, 1.0));
        expect("upper clamp", 1.0, clamp(2.0, -1.0, 1.0));
        expect("inside", 0.3, clamp(0.3, -1.0, 1.0));
        expect("boundary", -1.0, clamp(-1.0, -1.0, 1.0));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
