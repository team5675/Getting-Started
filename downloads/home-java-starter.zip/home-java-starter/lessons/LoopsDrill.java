// Team 5675 - Drill for Lesson 6 ("Repeat and then stop")
// Extra practice after the lesson. Run it:  .\run LoopsDrill
// Check it:  .\run LoopsDrill check
// TASK: Do the three exercises in order.
//   1. In main, write a for loop that prints the even numbers 2, 4, 6, 8
//      and 10 (one per line), then print Done! once, after the loop.
//   2. countdownText(from): build the countdown as ONE piece of text. For 3,
//      return 3 2 1 Go! Start with an empty String and add to it in a loop.
//   3. loopsUntilLow(startVolts, dropPerLoop, lowVolts): a battery starts at
//      startVolts and loses dropPerLoop every loop. Use a while loop to count
//      the loops until the voltage is BELOW lowVolts.
// HINT: Exercise 1 starts at 2, keeps going while count <= 10 and adds 2 on
// each pass: count = count + 2. In Exercise 2, start at from, subtract one on
// each pass, put text = text + count + " "; inside the loop, then return
// text + "Go!". By hand: 12.0 dropping 0.5 is 11.5 after one loop (not below
// 11.5 yet) and 11.0 after two, so the answer is 2.
// CHALLENGE (optional): tickCount(loops): count the loop numbers from 1 to
// loops that divide evenly by 50, using % (the remainder). tickCount(120) is
// 2. Then change CHECK_CHALLENGE to true.
public class LoopsDrill {
    static final boolean CHECK_CHALLENGE = false;

    public static String countdownText(int from) {
        return ""; // TODO
    }

    public static int loopsUntilLow(double startVolts, double dropPerLoop, double lowVolts) {
        return 0; // TODO
    }

    public static int tickCount(int loops) {
        return 0; // CHALLENGE
    }

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        // Warm-up: trace this loop on paper first, then run.
        for (int count = 1; count <= 3; count++) {
            System.out.println("Count: " + count);
        }

        // Exercise 1: your counting loop goes below this comment.


        System.out.println("countdownText(3) = " + countdownText(3));
        System.out.println("loopsUntilLow(12.0, 0.5, 11.5) = " + loopsUntilLow(12.0, 0.5, 11.5));
    }

    private static void check() {
        java.util.List<String> lines = printedByMain();
        expectLines("Exercise 1", lines, "2", "4", "6", "8", "10", "Done!");
        expect("Exercise 2 from 3", "3 2 1 Go!", countdownText(3));
        expect("Exercise 2 from 5", "5 4 3 2 1 Go!", countdownText(5));
        expect("Exercise 2 from 0: the loop never runs", "Go!", countdownText(0));
        expect("Exercise 3: 12.0 to 11.5 to 11.0", 2, loopsUntilLow(12.0, 0.5, 11.5));
        expect("Exercise 3: from 12.8 dropping 0.15", 9, loopsUntilLow(12.8, 0.15, 11.5));
        expect("Exercise 3: already below the limit", 0, loopsUntilLow(11.0, 0.5, 11.5));
        if (CHECK_CHALLENGE) {
            expect("CHALLENGE 120 loops", 2, tickCount(120));
            expect("CHALLENGE loop 50 itself counts", 1, tickCount(50));
            expect("CHALLENGE no tick before loop 50", 0, tickCount(49));
        }
        finish();
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks run your main or call your methods with several inputs.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static java.util.List<String> printedByMain() {
        java.io.PrintStream original = System.out;
        java.io.ByteArrayOutputStream captured = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(captured, true));
        try {
            main(new String[0]);
        } finally {
            System.setOut(original);
        }
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (String line : captured.toString().split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    private static void expectLines(String label, java.util.List<String> lines, String... wanted) {
        checked++;
        for (int start = 0; start + wanted.length <= lines.size(); start++) {
            boolean all = true;
            for (int i = 0; i < wanted.length; i++) {
                if (!lines.get(start + i).equals(wanted[i])) {
                    all = false;
                }
            }
            if (all) {
                return;
            }
        }
        failed++;
        System.out.println("TRY AGAIN: " + label + "; expected the line(s) " + String.join(" / ", wanted)
                + "; your program printed: " + String.join(" / ", lines));
    }

    private static void finish() {
        if (!CHECK_CHALLENGE) {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
