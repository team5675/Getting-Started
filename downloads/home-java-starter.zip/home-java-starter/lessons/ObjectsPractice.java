// Team 5675 - 7. Classes and objects
// TASK: Counter is a class: a recipe for objects. Finish increment() and
// reset(). Each new Counter must keep its OWN value. Do not make value static.
// The constructor sets the starting value to zero.
// HINT: increment adds one to value. reset assigns zero. The two objects in
// main must not share their field.
// PART B: Below the PART B comment inside main, reset only first, then
// print both values (0 and 1). Increment only second once more and print it
// (predict 2). Keep the counters independent; shared references are an
// optional page extension.
public class ObjectsPractice {
    static class Counter {
        private int value;

        Counter() { value = 0; }
        void increment() { /* TODO */ }
        void reset() { /* TODO */ }
        int getValue() { return value; }
    }

    // main is the entry point. Complete the exercise methods first.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        Counter first = new Counter();
        Counter second = new Counter();
        first.increment();
        first.increment();
        second.increment();
        System.out.println(first.getValue()); // 2
        System.out.println(second.getValue()); // 1
        // PART B: type your new lines below this comment.
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        Counter a = new Counter(); Counter b = new Counter(); a.increment(); a.increment(); b.increment();
        expect("first object", 2, a.getValue());
        expect("second independent object", 1, b.getValue());
        a.reset(); expect("reset first", 0, a.getValue());
        expect("reset did not change second", 1, b.getValue());
        Counter alias = b;
        alias.increment(); expect("alias changes original", 2, b.getValue());
        alias.reset(); expect("alias reset", 0, b.getValue());
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
