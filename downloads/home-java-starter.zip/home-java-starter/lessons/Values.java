// TASK: Replace 0.0 with speedMetersPerSecond * seconds. Predict the distance
// first.
// PART B: Below the PART B comment inside main, make int runs = 4, boolean
// ready = true and String teamName = "WiredCats". Add one to runs, then print
// "teamName" (quoted), teamName, runs and ready. Then change only ready to
// false and see which line changes.
public class Values {
    public static void main(String[] args) {
        double speedMetersPerSecond = 1.5;
        double seconds = 2.0;
        double distanceMeters = 0.0; // TODO: use the two variables above.
        System.out.println("Distance: " + distanceMeters + " m");
        // PART B: type your new lines below this comment.
    }
}
