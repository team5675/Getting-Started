// PART B: After the distance print inside main, write a run count starting at 4, a boolean readiness flag, and a String team name. Increase the count by one; print all three and compare a quoted name with the stored name. Change only the flag.
// TASK: Replace 0.0 with speedMetersPerSecond * seconds. Predict the distance first.
public class Values {
    public static void main(String[] args) {
        double speedMetersPerSecond = 1.5;
        double seconds = 2.0;
        double distanceMeters = 0.0; // TODO: use the two variables above.
        System.out.println("Distance: " + distanceMeters + " m");
    }
}
