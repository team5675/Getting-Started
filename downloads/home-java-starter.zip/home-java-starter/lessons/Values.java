// TASK: Replace 0.0 with speedMetersPerSecond * seconds. Predict the distance first.
public class Values {
    public static void main(String[] args) {
        double speedMetersPerSecond = 1.5;
        double seconds = 2.0;
        double distanceMeters = 0.0; // TODO: use the two variables above.
        System.out.println("Distance: " + distanceMeters + " m");
    }
}
