// Team 5675 - 7. ArrayPractice
// TASK: countConnected visits a boolean array and returns how many entries are true. The
// array may be empty. A boolean is true or false; array indices start at zero.
// HINT: Start a count at 0. For each index less than connected.length, add 1 only if
// connected[i] is true.
// ROBOT CONNECTION: Constants.Vision.CAMERAS is an array of CameraConfig objects. The vision
// subsystem loops over its length instead of assuming exactly one camera.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class ArrayPractice {
    public static int countConnected(boolean[] connected) {
        return -1; // TODO
    }

    // main is the entry point. Complete the exercise methods first. Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        boolean[] cameras = {true, false, true};
        System.out.println(countConnected(cameras)); // 2
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("mixed", 2, countConnected(new boolean[] {true, false, true}));
        expect("empty", 0, countConnected(new boolean[] {}));
        expect("none", 0, countConnected(new boolean[] {false, false}));
        expect("all", 3, countConnected(new boolean[] {true, true, true}));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
