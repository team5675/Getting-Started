// Team 5675 - 10. Find a logic error
// TASK: total should add every entry in the array. The starter compiles, but starts at the
// wrong index. Predict the result for {2,3,4}, run it, then fix the loop. Put a breakpoint on
// total += values[i] and watch i and total.
// HINT: Java arrays begin at index zero. Starting at one skips the first element. Empty
// arrays should return zero.
// ROBOT CONNECTION: Robot review also needs data validity, not just compilation.
// SystemHealthCheck can read a number even when a device status is bad; investigate both
// value and status.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class Debugging {
    public static int total(int[] values) {
        int total = 0;
        for (int i = 1; i < values.length; i++) { // TODO: find the bug.
            total += values[i];
        }
        return total;
    }

    // main is the entry point. Complete the exercise methods first. Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(total(new int[] {2, 3, 4})); // Goal: 9; starter prints 7.
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("all elements", 9, total(new int[] {2, 3, 4}));
        expect("one element", 5, total(new int[] {5}));
        expect("empty", 0, total(new int[] {}));
        expect("negative", -3, total(new int[] {-1, -2}));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
