// Team 5675 - 7B. Text and combined conditions
// TASK: Finish the three methods marked TODO.
//   1. inAimRange(enabled, distanceMeters): true only when the robot is
//      enabled AND the distance is from 2.0 to 4.5 meters, including
//      exactly 2.0 and exactly 4.5.
//   2. shouldStop(mode, batteryLow): true when mode is "disabled" OR the
//      battery is low. Compare text with equals, not ==.
//   3. clockText(totalSeconds): minutes and seconds, such as 2:20 for 140.
//      Seconds below 10 get a leading 0: 65 gives 1:05.
// HINT: && means AND, || means OR. For whole numbers, 140 / 60 is 2 and
// 140 % 60 is 20 (the remainder).
// PART B: Add a method isMatchMode(String mode) that is true for
// "autonomous" or "teleop". At the end of main, print its answer for
// "teleop" and for "disabled". Predict true, then false.
public class TextAndConditions {
    public static boolean inAimRange(boolean enabled, double distanceMeters) {
        return false; // TODO
    }

    public static boolean shouldStop(String mode, boolean batteryLow) {
        return false; // TODO
    }

    public static String clockText(int totalSeconds) {
        return ""; // TODO
    }

    // main is the entry point. Complete the exercise methods first.
    // Part B adds lines at the end of main.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println("Aim at 3.0 m, enabled: " + inAimRange(true, 3.0));
        System.out.println("Aim at 3.0 m, disabled: " + inAimRange(false, 3.0));
        System.out.println("Stop when disabled: " + shouldStop("disabled", false));
        System.out.println("Stop in teleop, good battery: " + shouldStop("teleop", false));
        System.out.println("Teleop clock: " + clockText(140));
        System.out.println("Short clock: " + clockText(65));
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        expect("aim at exactly 2.0 m", true, inAimRange(true, 2.0));
        expect("aim at exactly 4.5 m", true, inAimRange(true, 4.5));
        expect("aim at 3.0 m", true, inAimRange(true, 3.0));
        expect("too close at 1.99 m", false, inAimRange(true, 1.99));
        expect("too far at 4.51 m", false, inAimRange(true, 4.51));
        expect("disabled never aims", false, inAimRange(false, 3.0));
        expect("stop when disabled", true, shouldStop("disabled", false));
        expect("keep going in teleop", false, shouldStop("teleop", false));
        expect("stop for a low battery", true, shouldStop("teleop", true));
        // Text built while the program runs, like text read from a controller
        // or a file. == compares objects, so only equals gets this one right.
        String start = "dis";
        String built = start + "abled";
        expect("stop for disabled text built from two pieces", true, shouldStop(built, false));
        expect("clock for 140 s", "2:20", clockText(140));
        expect("clock for 65 s", "1:05", clockText(65));
        expect("clock for exactly 60 s", "1:00", clockText(60));
        expect("clock for 9 s", "0:09", clockText(9));
        expect("clock for 0 s", "0:00", clockText(0));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
