// TASK: Print LOW below 11.0, CHECK below 12.0, READY otherwise. These are fictional teaching thresholds. Try 10.9, 11.0 and 12.0.
public class Decisions {
    public static void main(String[] args) {
        double volts = 11.0;
        // TODO: replace the print below with an if / else if / else chain.
        System.out.println("TODO");
    }
}
