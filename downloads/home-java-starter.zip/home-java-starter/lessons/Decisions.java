// PART B: After the voltage example in Decisions.java, declare boolean enabled = false. Write an if/else that prints MOVING when true and STOPPED otherwise. Run both values. Then make a table of the voltage outputs for 10.9, 11.0, 11.9 and 12.0.
// TASK: Print LOW below 11.0, CHECK below 12.0, READY otherwise. These are fictional teaching thresholds. Try 10.9, 11.0 and 12.0.
public class Decisions {
    public static void main(String[] args) {
        double volts = 11.0;
        // TODO: replace the print below with an if / else if / else chain.
        System.out.println("TODO");
    }
}
