// Team 5675 - 3. if, else if, else
// TASK: For these fictional exercise thresholds only: below 11.0 returns LOW; from 11.0 up to
// but not including 12.0 returns CHECK; 12.0 or higher returns READY. Use an if / else if /
// else chain.
// HINT: Check volts < 11.0 first, then volts < 12.0. Exactly 11.0 belongs in CHECK.
// ROBOT CONNECTION: SystemHealthCheck.updateCameraRow checks missing heartbeat before the
// wrong pipeline. The first true branch selects the explanation.
// SYSTEMCORE-2027: plain Java; no WPILib imports or hardware dependencies.
public class Decisions {
    public static String label(double volts) {
        return "TODO";
    }

    // main is the entry point. Keep it as supplied; edit the exercise above.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(label(10.9)); // LOW
        System.out.println(label(11.0)); // CHECK
        System.out.println(label(12.0)); // READY
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("below first boundary", "LOW", label(10.9));
        expect("exact first boundary", "CHECK", label(11.0));
        expect("below second boundary", "CHECK", label(11.99));
        expect("exact second boundary", "READY", label(12.0));
        expect("above boundaries", "READY", label(12.5));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
