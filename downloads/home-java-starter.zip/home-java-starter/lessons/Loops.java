// Team 5675 - 6. for and while loops
// TASK: sumThrough(n) returns 1 + 2 + ... + n using a for loop. Return 0 when n
// is 0. Then write the same behavior in sumWithWhile(n) using while. Assume n
// is between 0 and 100.
// HINT: Start total at 0 and i at 1. Include n with <=. In while, increase i
// inside the body so the loop ends.
// PART B: After the existing output lines inside main, write a for loop to
// print 5, 4, 3, 2, 1 on separate lines. Predict the first failed condition.
// Try starts of 1 and 0, then restore 5. The supplied check command tests the
// sum methods, not this new countdown.
public class Loops {
    public static int sumThrough(int n) {
        return -1; // TODO
    }

    public static int sumWithWhile(int n) {
        return -1; // TODO
    }

    // main is the entry point. Complete the exercise methods first.
    // Part B may add calls here.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println(sumThrough(4)); // 10
        System.out.println(sumWithWhile(4)); // 10
        System.out.println("Save your change, then run with check to test it.");
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks call your methods with several inputs, including boundary cases.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static void check() {
        
        expect("for empty", 0, sumThrough(0));
        expect("for one", 1, sumThrough(1));
        expect("for four", 10, sumThrough(4));
        expect("while empty", 0, sumWithWhile(0));
        expect("while one", 1, sumWithWhile(1));
        expect("while four", 10, sumWithWhile(4));
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
