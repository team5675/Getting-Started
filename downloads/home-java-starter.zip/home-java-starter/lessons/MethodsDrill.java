// Team 5675 - Drill for Lesson 5 ("Give an action a name")
// Extra practice after the lesson. Run it:  .\run MethodsDrill
// Check it:  .\run MethodsDrill check
// TASK: Finish the three methods marked TODO, in order.
//   1. metersToCentimeters(meters): 1 meter is 100 centimeters.
//   2. voltsToOutput(volts): a motor output runs from -1.0 to 1.0; on a
//      12-volt battery, output is volts divided by 12.0.
//   3. outputToVolts(output): output times 12.0, but first keep output
//      between -1.0 and 1.0 by CALLING the supplied clamp method.
// HINT: Each method ends by returning its answer. clamp is finished: it is
// the same rule you wrote in Methods.java. outputToVolts(1.5) is 12.0.
// CHALLENGE (optional): finish distanceBetween with Math.hypot(dx, dy), and
// applyDeadband: return 0.0 when value is closer to 0 than deadband in either
// direction (Math.abs helps), otherwise value. Then change CHECK_CHALLENGE to
// true.
public class MethodsDrill {
    static final boolean CHECK_CHALLENGE = false;

    public static double metersToCentimeters(double meters) {
        return 0.0; // TODO
    }

    public static double voltsToOutput(double volts) {
        return 0.0; // TODO
    }

    public static double outputToVolts(double output) {
        return 0.0; // TODO: call clamp first.
    }

    // Supplied and finished.
    public static double clamp(double value, double low, double high) {
        if (value < low) {
            return low;
        }
        if (value > high) {
            return high;
        }
        return value;
    }

    public static double distanceBetween(double x1, double y1, double x2, double y2) {
        return 0.0; // CHALLENGE
    }

    public static double applyDeadband(double value, double deadband) {
        return value; // CHALLENGE
    }

    // main is the entry point. Complete the exercise methods first.
    public static void main(String[] args) {
        if (args.length > 0 && args[0].equals("check")) {
            check();
            return;
        }
        System.out.println("2.54 meters = " + metersToCentimeters(2.54) + " cm");
        System.out.println("6.0 volts = output " + voltsToOutput(6.0));
        System.out.println("output 1.5 = " + outputToVolts(1.5) + " volts");
        System.out.println("Save your change, then run with check to test it.");
    }

    private static void check() {
        expect("2.54 m in centimeters", 254.0, metersToCentimeters(2.54));
        expect("0.5 m in centimeters", 50.0, metersToCentimeters(0.5));
        expect("6 volts is half output", 0.5, voltsToOutput(6.0));
        expect("-12 volts is full reverse", -1.0, voltsToOutput(-12.0));
        expect("0.25 output is 3 volts", 3.0, outputToVolts(0.25));
        expect("1.5 is clamped to 1.0 first", 12.0, outputToVolts(1.5));
        expect("-3.0 is clamped to -1.0 first", -12.0, outputToVolts(-3.0));
        if (CHECK_CHALLENGE) {
            expect("CHALLENGE (0,0) to (3,4)", 5.0, distanceBetween(0, 0, 3, 4));
            expect("CHALLENGE (4,6) to (1,2)", 5.0, distanceBetween(4, 6, 1, 2));
            expect("CHALLENGE 0.05 is inside the deadband", 0.0, applyDeadband(0.05, 0.1));
            expect("CHALLENGE -0.05 is inside too", 0.0, applyDeadband(-0.05, 0.1));
            expect("CHALLENGE -0.5 passes through", -0.5, applyDeadband(-0.5, 0.1));
        }
        finish();
    }

    // SELF-CHECK SUPPORT: you do not need to edit or understand this yet.
    // Checks run your main or call your methods with several inputs.
    private static int failed = 0;
    private static int checked = 0;

    private static void expect(String label, Object expected, Object actual) {
        checked++;
        boolean same;
        if (expected instanceof Number && actual instanceof Number) {
            double a = ((Number) expected).doubleValue();
            double b = ((Number) actual).doubleValue();
            same = Double.isFinite(b) && Math.abs(a - b) < 0.000001;
        } else {
            same = expected.equals(actual);
        }
        if (!same) {
            failed++;
            System.out.println("TRY AGAIN: " + label + "; expected " + expected + "; got " + actual);
        }
    }

    private static java.util.List<String> printedByMain() {
        java.io.PrintStream original = System.out;
        java.io.ByteArrayOutputStream captured = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(captured, true));
        try {
            main(new String[0]);
        } finally {
            System.setOut(original);
        }
        java.util.List<String> lines = new java.util.ArrayList<>();
        for (String line : captured.toString().split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    private static void expectLines(String label, java.util.List<String> lines, String... wanted) {
        checked++;
        for (int start = 0; start + wanted.length <= lines.size(); start++) {
            boolean all = true;
            for (int i = 0; i < wanted.length; i++) {
                if (!lines.get(start + i).equals(wanted[i])) {
                    all = false;
                }
            }
            if (all) {
                return;
            }
        }
        failed++;
        System.out.println("TRY AGAIN: " + label + "; expected the line(s) " + String.join(" / ", wanted)
                + "; your program printed: " + String.join(" / ", lines));
    }

    private static void finish() {
        if (!CHECK_CHALLENGE) {
            System.out.println("The CHALLENGE is not checked yet. When you try it, change CHECK_CHALLENGE to true.");
        }
        if (failed == 0) {
            System.out.println("PASS: " + checked + " checks. Explain WHY each result is right.");
        } else {
            System.out.println(failed + " of " + checked + " checks need another try. Read the TASK and HINT.");
            System.exit(1);
        }
    }
}
