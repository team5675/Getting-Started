package frc.robot.sim;

import java.util.function.BooleanSupplier;
import edu.wpi.first.wpilibj.simulation.DIOSim;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/** SUPPLIED for Motor lab 1's "Your turn": a pretend limit switch on DIO port 0.
 * You do not need to edit this file.
 *
 * <p>A roboRIO DIO port has a built-in pull-up resistor. With the switch released, the
 * port reads true. Pressing a normally open switch connects the port to ground, so it
 * reads false. Every loop, this class copies a pretend "pressed" signal (the station's
 * Object present box) into the simulated port with that same rule. So DigitalInput code
 * that works here works unchanged on a real roboRIO, such as the one in BOB.
 *
 * <p>It is a subsystem only so the scheduler runs it every loop. It does nothing on a robot.
 */
public class SimLimitSwitch extends SubsystemBase {
    private final DIOSim port;
    private final BooleanSupplier pressed;

    public SimLimitSwitch(int channel, BooleanSupplier pressed) {
        this.port = new DIOSim(channel);
        this.pressed = pressed;
    }

    @Override public void simulationPeriodic() {
        port.setValue(!pressed.getAsBoolean()); // pressed connects the pin to ground: false
    }
}
