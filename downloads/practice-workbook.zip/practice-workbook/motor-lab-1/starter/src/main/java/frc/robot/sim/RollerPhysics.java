package frc.robot.sim;

import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.math.system.plant.LinearSystemId;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.simulation.FlywheelSim;

/** SUPPLIED: the pretend world for the motor labs. You do not need to edit this file.
 *
 * <p>On a real robot, physics happens by itself. In simulation, something has to do the
 * physics math, or a "motor" would reach any speed instantly. WPILib's FlywheelSim does that
 * math for one Kraken X60: volts push current through the motor, current makes torque,
 * torque speeds the roller up, and the spinning motor pushes back against the battery.
 *
 * <p>This class adds three things every real mechanism has and FlywheelSim leaves out:
 * <ul>
 *   <li>friction, which uses up a few volts before the roller moves at all (Motor lab 1
 *       measures it and calls it kS);</li>
 *   <li>a load while the station's "Object present" box is checked, which drags harder;</li>
 *   <li>a speed reading that is one loop (20 ms) old, as a real sensor's reading is.</li>
 * </ul>
 * Fictional teaching numbers: one Kraken X60, a 3:1 reduction and a heavy roller.
 * Never copy them to a robot.
 */
public final class RollerPhysics {
    /** One Kraken X60, using WPILib's model of CTRE's published motor curve. */
    public static final DCMotor MOTOR = DCMotor.getKrakenX60(1);
    /** The motor turns 3 times for every 1 turn of the roller. */
    public static final double GEARING = 3.0;
    /** How hard the roller is to spin up, in kg*m^2. A heavier roller takes longer. */
    public static final double MOMENT_OF_INERTIA = 0.02;
    /** The answer key for Motor lab 1: volts used up by friction. Measure it first, then look. */
    public static final double FRICTION_VOLTS = 0.15;
    /** Extra drag, in the same volts units, while "Object present" is checked. */
    public static final double LOAD_VOLTS = 0.60;
    /** The robot loop runs every 20 ms. */
    public static final double LOOP_SECONDS = 0.02;

    private final FlywheelSim flywheel = new FlywheelSim(
            LinearSystemId.createFlywheelSystem(MOTOR, MOMENT_OF_INERTIA, GEARING), MOTOR);
    private double volts;
    private double measuredRps;
    private double rotations;

    /** Move the pretend world forward one loop, with these volts at the motor. */
    public void update(double appliedVolts, boolean loaded, double dtSeconds) {
        double friction = FRICTION_VOLTS + (loaded ? LOAD_VOLTS : 0.0);
        double before = flywheel.getAngularVelocityRadPerSec();
        volts = appliedVolts;
        double pushing; // the volts left over after friction takes its share
        if (before == 0.0) {
            // At rest, friction holds the roller until the motor pushes harder than friction.
            pushing = Math.abs(volts) <= friction ? 0.0 : volts - Math.copySign(friction, volts);
        } else {
            // While it moves, friction always works against the direction of motion.
            pushing = volts - Math.copySign(friction, before);
        }
        flywheel.setInputVoltage(pushing);
        flywheel.update(dtSeconds);
        double after = flywheel.getAngularVelocityRadPerSec();
        // Friction can stop a roller, but it can never start one turning backwards.
        if (before != 0.0 && Math.signum(after) != Math.signum(before) && Math.abs(volts) <= friction) {
            flywheel.setAngularVelocity(0.0);
            after = 0.0;
        }
        rotations += Units.radiansToRotations((before + after) / 2 * dtSeconds);
        measuredRps = Units.radiansToRotations(before); // the sensor reports the speed one loop ago
    }

    /** Roller speed in rotations per second, as a sensor reports it: one loop old. */
    public double measuredSpeedRps() {
        return measuredRps;
    }

    /** Motor current in amps. A motor that is not turning yet draws the most current. */
    public double currentAmps() {
        return MOTOR.getCurrent(flywheel.getAngularVelocityRadPerSec() * GEARING, volts);
    }

    /** Roller speed right now, with no sensor delay. The TalonFX step uses it. */
    public double trueSpeedRps() {
        return Units.radiansToRotations(flywheel.getAngularVelocityRadPerSec());
    }

    /** Roller turns since the program started. The TalonFX step uses it. */
    public double rotations() {
        return rotations;
    }

    /** The speed this model settles at with steady volts (at most 12). The checks use it. */
    public static double steadySpeedRps(double volts, boolean loaded) {
        double friction = FRICTION_VOLTS + (loaded ? LOAD_VOLTS : 0.0);
        if (Math.abs(volts) <= friction) {
            return 0.0;
        }
        double pushing = volts - Math.copySign(friction, volts);
        return Units.radiansToRotations(pushing * MOTOR.KvRadPerSecPerVolt / GEARING);
    }
}
