package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.commands.RampVolts;
import frc.robot.sim.RollerPhysics;
import frc.robot.sim.SimLimitSwitch;
import frc.robot.subsystems.MotorRoller;

/** Motor lab 1 checks: volts in, speed out, and your two measurements.
 * Each loop moves the simulated clock exactly 20 ms, so every run gives the same numbers.
 */
public class MotorLab1Test {
    private static final TrainingInput TELEOP = new TrainingInput("teleop", 0, 0, 0, false, false, false, 0, false);

    private void step(double seconds) {
        for (int i = 0; i < (int) Math.round(seconds / RollerPhysics.LOOP_SECONDS); i++) {
            SimHooks.stepTiming(RollerPhysics.LOOP_SECONDS);
            CommandScheduler.getInstance().run();
        }
    }

    @Test void voltsSpeedAndYourMeasurements() {
        HAL.initialize(500, 0); SimHooks.pauseTiming(); DriverStationSim.resetData();
        CommandScheduler scheduler = CommandScheduler.getInstance();
        scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
        SimControls.publish(TELEOP);
        MotorRoller motor = new MotorRoller(() -> false);
        try {
            // TODO 1: a request never asks for more than the battery can give.
            motor.setVolts(5.0);
            assertEquals(5.0, motor.getRequestedVolts(), 1e-9, "setVolts(5.0) should request 5 V");
            motor.setVolts(20.0);
            assertEquals(12.0, motor.getRequestedVolts(), 1e-9, "setVolts(20.0) should be limited to 12 V");
            motor.setVolts(-20.0);
            assertEquals(-12.0, motor.getRequestedVolts(), 1e-9, "setVolts(-20.0) should be limited to -12 V");
            motor.setVolts(0.0);

            // TODO 2: runAtVolts holds its volts while it runs, then sets 0 V.
            Command six = motor.runAtVolts(6.0);
            assertTrue(six.getRequirements().contains(motor), "runAtVolts must require the roller (use runEnd from the subsystem)");
            scheduler.schedule(six); step(2.0);
            assertTrue(six.isScheduled(), "runAtVolts should keep running until it is released");
            assertEquals(6.0, motor.getAppliedVolts(), 1e-9, "runAtVolts(6.0) should apply 6 V");
            assertEquals(RollerPhysics.steadySpeedRps(6.0, false), motor.getSpeedRps(), 0.05,
                    "After 2 s at 6 V the roller should be at its steady speed");
            six.cancel(); step(0.04);
            assertEquals(0.0, motor.getAppliedVolts(), 1e-9, "When runAtVolts ends, the motor must get 0 V");
            step(3.0);
            assertEquals(0.0, motor.getSpeedRps(), 1e-9, "With 0 V, friction should stop the roller within 3 s");

            // Disabling cancels the command; re-enabling does not restart it.
            scheduler.schedule(six); step(0.5);
            SimControls.publish(TrainingInput.disabled()); step(0.04);
            assertFalse(six.isScheduled(), "Disabling the robot should cancel runAtVolts");
            assertEquals(0.0, motor.getAppliedVolts(), 1e-9, "A disabled robot must apply 0 V");
            SimControls.publish(TELEOP); step(0.04);
            assertEquals(0.0, motor.getAppliedVolts(), 1e-9, "Re-enabling must not restart a canceled command");
            step(3.0);

            // TODO 3: RampVolts raises the volts steadily; friction holds the roller at first.
            RampVolts ramp = new RampVolts(motor, 0.5);
            scheduler.schedule(ramp); step(0.2);
            assertEquals(0.1, motor.getRequestedVolts(), 0.021, "RampVolts(motor, 0.5) should ask for about 0.1 V after 0.2 s");
            assertEquals(0.0, motor.getSpeedRps(), 1e-9, "Below the friction volts, the roller should not turn yet");
            step(1.8);
            assertEquals(1.0, motor.getRequestedVolts(), 0.021, "RampVolts(motor, 0.5) should ask for about 1.0 V after 2 s");
            assertTrue(motor.getSpeedRps() > 0.5, "Above the friction volts, the roller should turn");
            ramp.cancel(); step(0.04);
            assertEquals(0.0, motor.getAppliedVolts(), 1e-9, "When RampVolts ends, the motor must get 0 V");

            // TODO 4: your measurements, compared with the model's answer key.
            double slow = RollerPhysics.steadySpeedRps(3.0, false);
            double fast = RollerPhysics.steadySpeedRps(9.0, false);
            double kv = (9.0 - 3.0) / (fast - slow);
            double ks = 3.0 - kv * slow;
            assertEquals(ks, MotorRoller.KS_VOLTS, 0.05,
                    "KS_VOLTS: use 3 V minus KV times the speed at 3 V, or the volts where the ramp starts the roller");
            assertEquals(kv, MotorRoller.KV_VOLTS_PER_RPS, 0.05 * kv,
                    "KV_VOLTS_PER_RPS: use (9 - 3) divided by (speed at 9 V - speed at 3 V)");

            // Supplied for "Your turn": the pretend switch reads like a real roboRIO pull-up input.
            AtomicBoolean pressed = new AtomicBoolean(false);
            new SimLimitSwitch(0, pressed::get);
            try (DigitalInput limitSwitch = new DigitalInput(0)) {
                step(0.04);
                assertTrue(limitSwitch.get(), "Supplied SimLimitSwitch: a released switch should read true");
                pressed.set(true); step(0.04);
                assertFalse(limitSwitch.get(), "Supplied SimLimitSwitch: a pressed switch should read false");
            }
        } finally {
            scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
            SimControls.publish(TrainingInput.disabled()); SimHooks.resumeTiming();
        }
    }
}
