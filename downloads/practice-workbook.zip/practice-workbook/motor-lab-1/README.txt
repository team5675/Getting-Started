Use the matching motor-lab-1.html (Motor lab 1) on the course website.
Add the starter files to your project: in the Terminal, type  .\robot motors1
It copies starter/src files to the same paths under src and never replaces
a file you already have, so your own edits are kept.
Complete TODOs before consulting answer. The test file checks your edited classes.
src/main/java/frc/robot/sim holds two supplied files you do not need to edit:
RollerPhysics.java is the pretend world (WPILib's Kraken X60 model plus friction),
and SimLimitSwitch.java is a pretend limit switch for the "Your turn" exercise.
