package frc.robot.subsystems;

import java.util.function.BooleanSupplier;
import edu.wpi.first.math.MathUtil;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.sim.RollerPhysics;
import org.littletonrobotics.junction.Logger;

/** Motor labs 1 and 2: a roller driven by one simulated Kraken X60.
 * Speeds are roller rotations per second (rps). Fictional teaching numbers only.
 */
public class MotorRoller extends SubsystemBase {
    /** A 12 V battery cannot give the motor more than 12 V. */
    public static final double MAX_VOLTS = 12.0;
    // MOTOR LAB 1 TODO 4: your two measurements from the step test.
    public static final double KS_VOLTS = 0.15;           // volts to overcome friction
    public static final double KV_VOLTS_PER_RPS = 0.358;  // extra volts for each 1 rps
    // MOTOR LAB 2 TODO 3: your feedback gain.
    public static final double KP_VOLTS_PER_RPS = 0.0;    // extra volts for each 1 rps of error

    private final RollerPhysics physics = new RollerPhysics();
    private final BooleanSupplier objectPresent;
    private double requestedVolts;
    private double appliedVolts;
    private double targetRps;

    public MotorRoller(BooleanSupplier objectPresent) {
        this.objectPresent = objectPresent;
    }

    /** Ask for these volts. The next loop applies them while the robot is enabled. */
    public void setVolts(double volts) {
        // MOTOR LAB 1 TODO 1: keep the request between -MAX_VOLTS and +MAX_VOLTS.
        requestedVolts = MathUtil.clamp(volts, -MAX_VOLTS, MAX_VOLTS);
    }

    public double getRequestedVolts() { return requestedVolts; }
    public double getAppliedVolts() { return appliedVolts; }
    public double getSpeedRps() { return physics.measuredSpeedRps(); }
    public double getCurrentAmps() { return physics.currentAmps(); }

    /** Hold these volts while the command runs; 0 V when it ends. */
    public Command runAtVolts(double volts) {
        // MOTOR LAB 1 TODO 2: run sets the volts every loop; end sets 0 V.
        return runEnd(() -> setVolts(volts), () -> setVolts(0.0)).withName("Run at " + volts + " V");
    }

    /** SUPPLIED for Motor lab 1: 3 V, then 6 V, then 9 V for two seconds each, then 0 V.
     * One run gives three steady speeds. Each step's end() sets 0 V just before the next
     * step starts, so AppliedVolts touches 0 for one 20 ms loop between steps. That is
     * normal: end() always runs.
     */
    public Command stepTest() {
        return Commands.sequence(
                runAtVolts(3.0).withTimeout(2.0),
                runAtVolts(6.0).withTimeout(2.0),
                runAtVolts(9.0).withTimeout(2.0))
            .withName("Step test");
    }

    /** Motor lab 2: the volts that should hold targetRps, given the measured speed. */
    public static double speedVolts(double targetRps, double measuredRps) {
        // MOTOR LAB 2 TODO 1: feedforward, the volts you predict from Motor lab 1.
        // MOTOR LAB 2 TODO 3: feedback, extra volts in proportion to the error.
        return 0.0;
    }

    /** Motor lab 2: hold targetRps while the command runs; 0 V when it ends. */
    public Command runAtSpeed(double targetRps) {
        // MOTOR LAB 2 TODO 2: every loop, set the volts from speedVolts; end sets 0 V.
        return Commands.print("Motor lab 2 is not done yet: runAtSpeed does nothing.");
    }

    /** SUPPLIED: apply the request and record the evidence. */
    @Override public void periodic() {
        // Like a real motor controller, never drive the motor while the robot is disabled.
        appliedVolts = DriverStation.isDisabled() ? 0.0 : requestedVolts;
        Logger.recordOutput("Training/Motor/RequestedVolts", requestedVolts);
        Logger.recordOutput("Training/Motor/AppliedVolts", appliedVolts);
        Logger.recordOutput("Training/Motor/SpeedRps", getSpeedRps());
        Logger.recordOutput("Training/Motor/TargetRps", targetRps);
        Logger.recordOutput("Training/Motor/CurrentAmps", getCurrentAmps());
        Logger.recordOutput("Training/Motor/ObjectPresent", objectPresent.getAsBoolean());
    }

    /** SUPPLIED: in simulation only, move the pretend world forward one loop. */
    @Override public void simulationPeriodic() {
        physics.update(appliedVolts, objectPresent.getAsBoolean(), RollerPhysics.LOOP_SECONDS);
    }
}
