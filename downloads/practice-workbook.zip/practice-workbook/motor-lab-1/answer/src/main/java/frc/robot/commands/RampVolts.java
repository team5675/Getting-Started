package frc.robot.commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.MotorRoller;

/** Motor lab 1: raise the volts slowly while the button is held, starting from 0 V.
 * A slow ramp shows the dead zone: below the friction volts, the roller does not turn.
 */
public class RampVolts extends Command {
    private final MotorRoller roller;
    private final double voltsPerSecond;
    private final Timer timer = new Timer();

    public RampVolts(MotorRoller roller, double voltsPerSecond) {
        this.roller = roller;
        this.voltsPerSecond = voltsPerSecond;
        addRequirements(roller);
    }

    @Override public void initialize() {
        timer.restart(); // start counting from 0 every time the command starts
    }

    @Override public void execute() {
        // MOTOR LAB 1 TODO 3: ask for voltsPerSecond times the seconds since the start.
        roller.setVolts(voltsPerSecond * timer.get());
    }

    @Override public void end(boolean interrupted) {
        roller.setVolts(0.0);
        timer.stop();
    }
}
