Use the matching motor-lab-2.html (Motor lab 2) on the course website.
Finish Motor lab 1 first: Motor lab 2 continues your own MotorRoller.java.
Add the check to your project: in the Terminal, type  .\robot motors2
It copies MotorLab2Test.java into src and never replaces a file you already have.
answer/ holds a complete MotorRoller.java to compare with after you try.
