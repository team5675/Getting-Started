package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.sim.RollerPhysics;
import frc.robot.subsystems.MotorRoller;

/** Motor lab 2 checks: feedforward math, feedback math, then holding 20 rps with and
 * without a load. Uses YOUR KS, KV and KP. Same simulated 20 ms clock as Motor lab 1.
 */
public class MotorLab2Test {
    private static final TrainingInput TELEOP = new TrainingInput("teleop", 0, 0, 0, false, false, false, 0, false);
    private static final double TARGET = 20.0;

    private void step(double seconds) {
        for (int i = 0; i < (int) Math.round(seconds / RollerPhysics.LOOP_SECONDS); i++) {
            SimHooks.stepTiming(RollerPhysics.LOOP_SECONDS);
            CommandScheduler.getInstance().run();
        }
    }

    @Test void feedforwardThenFeedback() {
        HAL.initialize(500, 0); SimHooks.pauseTiming(); DriverStationSim.resetData();
        CommandScheduler scheduler = CommandScheduler.getInstance();
        scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
        SimControls.publish(TELEOP);
        AtomicBoolean object = new AtomicBoolean(false);
        MotorRoller motor = new MotorRoller(object::get);
        try {
            double ks = MotorRoller.KS_VOLTS, kv = MotorRoller.KV_VOLTS_PER_RPS, kp = MotorRoller.KP_VOLTS_PER_RPS;
            assertTrue(ks > 0 && kv > 0, "Finish Motor lab 1 first: KS_VOLTS and KV_VOLTS_PER_RPS must hold your measurements");

            // TODO 1: feedforward, the volts you predict before measuring anything.
            assertEquals(ks + kv * 10, MotorRoller.speedVolts(10, 10), 1e-9,
                    "At 10 rps with no error, speedVolts should be KS_VOLTS + KV_VOLTS_PER_RPS * 10");
            assertEquals(-(ks + kv * 10), MotorRoller.speedVolts(-10, -10), 1e-9,
                    "Backwards, friction pushes the other way: multiply KS_VOLTS by Math.signum(targetRps)");
            assertEquals(0.0, MotorRoller.speedVolts(0, 0), 1e-9, "A target of 0 rps should ask for 0 V");

            // TODO 3: feedback adds KP times the error, and the error is target minus measured.
            assertEquals(2 * kp, MotorRoller.speedVolts(10, 8) - MotorRoller.speedVolts(10, 10), 1e-9,
                    "2 rps too slow should add KP_VOLTS_PER_RPS * 2 volts (error = target - measured)");

            // TODO 2: runAtSpeed holds 20 rps.
            Command hold = motor.runAtSpeed(TARGET);
            assertTrue(hold.getRequirements().contains(motor), "runAtSpeed must require the roller (use runEnd from the subsystem)");
            scheduler.schedule(hold);
            double peak = 0, low = Double.MAX_VALUE, high = -Double.MAX_VALUE;
            for (int loop = 1; loop <= 100; loop++) {        // 100 loops = 2 seconds
                step(RollerPhysics.LOOP_SECONDS);
                double speed = motor.getSpeedRps();
                peak = Math.max(peak, speed);
                if (loop >= 50) {                             // from 1 s to 2 s
                    low = Math.min(low, speed);
                    high = Math.max(high, speed);
                }
            }
            assertTrue(hold.isScheduled(), "runAtSpeed should keep running until it is released");
            assertTrue(peak <= TARGET + 1.0, String.format(
                    "The speed reached %.2f rps, more than 1 rps over %.0f. If it rose and fell back, KP is too high; "
                    + "if it stayed high, check KS and KV.", peak, TARGET));
            assertTrue(low >= TARGET - 0.5 && high <= TARGET + 0.5, String.format(
                    "From 1 s to 2 s the speed should stay within 0.5 rps of %.0f; it went from %.2f to %.2f. "
                    + "Swinging up and down: lower KP. Always low or always high: check KS and KV, then raise KP.",
                    TARGET, low, high));

            // The load arrives: feedforward cannot see it, feedback can.
            object.set(true); step(0.5);
            assertEquals(TARGET, motor.getSpeedRps(), 1.0, String.format(
                    "0.5 s after the load arrives, the speed should be back within 1 rps of %.0f. "
                    + "Feedforward alone cannot see a load: raise KP.", TARGET));
            hold.cancel(); step(0.04);
            assertEquals(0.0, motor.getAppliedVolts(), 1e-9, "When runAtSpeed ends, the motor must get 0 V");
        } finally {
            scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
            SimControls.publish(TrainingInput.disabled()); SimHooks.resumeTiming();
        }
    }
}
