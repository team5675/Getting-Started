package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 6: loops. Goes with Lesson 6, "Repeat and then stop".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check06".
 */
public class Practice06Loops {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        // ---- Warm-up: the Lesson 6 loop. Trace it on paper first, then Run. ----
        for (int count = 1; count <= 3; count++) {
            System.out.println("Count: " + count);
        }

        // ---- Exercise 1: count DOWN ----
        // Write a for loop that prints 5, 4, 3, 2, 1 (one number per line), then print "Go!"
        // once, after the loop. Hint: start at 5, keep going while count >= 1, and use count--
        // (subtract one) instead of count++.
        for (int count = 5; count >= 1; count--) {
            System.out.println(count);
        }
        System.out.println("Go!");

        // ---- These lines call your methods for Exercises 2 and 3. ----
        System.out.println("countdownText(3) = " + countdownText(3));
        System.out.println("loopsUntilLow(12.0, 0.5, 11.5) = " + loopsUntilLow(12.0, 0.5, 11.5));
        System.out.println("loopsUntilLow(12.8, 0.15, 11.5) = " + loopsUntilLow(12.8, 0.15, 11.5));
        System.out.println("tickCount(120) = " + tickCount(120));
    }

    /**
     * Exercise 2: build the countdown as ONE piece of text instead of printing it. For from = 3
     * return "3 2 1 Go!". Start with an empty String, then add to it inside a loop:
     *
     * <pre>
     *   String text = "";
     *   ... inside the loop:  text = text + count + " ";
     *   ... after the loop:   return text + "Go!";
     * </pre>
     */
    static String countdownText(int from) {
        String text = "";
        for (int count = from; count >= 1; count--) {
            text = text + count + " ";
        }
        return text + "Go!";
    }

    /**
     * Exercise 3: a pretend battery starts at startVolts and loses dropPerLoop volts every loop.
     * Return how many loops it takes until the voltage is BELOW lowVolts.
     *
     * <p>New kind of loop: "while (question) { ... }" repeats as long as the question is true.
     *
     * <pre>
     *   double volts = startVolts;
     *   int loops = 0;
     *   while (volts &gt;= lowVolts) {
     *       ... take dropPerLoop away from volts, and add 1 to loops
     *   }
     *   return loops;
     * </pre>
     *
     * <p>Check by hand: from 12.0, dropping 0.5, it's 11.5 after one loop (not below 11.5 yet)
     * and 11.0 after two, so the answer is 2.
     */
    static int loopsUntilLow(double startVolts, double dropPerLoop, double lowVolts) {
        double volts = startVolts;
        int loops = 0;
        while (volts >= lowVolts) {
            volts = volts - dropPerLoop;
            loops = loops + 1;
        }
        return loops;
    }

    /**
     * CHALLENGE: robot code runs 50 times a second. Suppose it prints "tick" on every loop
     * number that divides evenly by 50 (loop 50, loop 100, ...). Using a for loop from 1 to
     * loops and the % (remainder) operator, return how many ticks happen in that many loops.
     * tickCount(120) is 2. Part 2 of the guide uses this exact trick in a real robot program.
     */
    static int tickCount(int loops) {
        int ticks = 0;
        for (int loop = 1; loop <= loops; loop++) {
            if (loop % 50 == 0) {
                ticks++;
            }
        }
        return ticks;
    }
}
