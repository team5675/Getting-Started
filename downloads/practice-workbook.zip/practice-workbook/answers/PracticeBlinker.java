package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 9, Exercise 2: a light that blinks by itself.
 *
 * <p>Robot code never waits. You can't write "turn on, wait half a second, turn off" inside a
 * periodic method: the whole robot would freeze while it waited. Instead, the object COUNTS loops
 * and changes the light when enough loops have gone by. 25 loops * 20 ms = half a second.
 */
public class PracticeBlinker {
    private boolean on = false;
    private int loopsSinceChange = 0;

    /**
     * Exercise 2: called once per loop (every 20 ms). Add 1 to loopsSinceChange. When it reaches
     * 25, flip the light (on = !on) and set loopsSinceChange back to 0.
     *
     * <p>Check by hand: the light starts OFF, is ON after 25 calls, OFF after 50, ON after 75.
     */
    public void periodic() {
        loopsSinceChange = loopsSinceChange + 1;
        if (loopsSinceChange == 25) {
            on = !on;
            loopsSinceChange = 0;
        }
    }

    public boolean isOn() {
        return on;
    }
}
