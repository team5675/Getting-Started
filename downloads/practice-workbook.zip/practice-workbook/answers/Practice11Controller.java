package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 11: from stick numbers to robot speeds. Goes with Part 2, "Reading a controller".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check11".
 *
 * <p>Facts you need (from the lesson page):
 *
 * <ul>
 *   <li>A stick axis reads from -1.0 to 1.0. On an Xbox controller, pushing the left stick
 *       FORWARD (away from you) gives a NEGATIVE Y reading.
 *   <li>In WPILib, the robot's +X is forward and +Y is to its left.
 * </ul>
 */
public class Practice11Controller {
    /** Change to true when you want the self-check to look at Exercises 1 to 4. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        double[] rawValues = {0.03, 0.08, 0.10, 0.50, -0.50, 1.00};
        for (double raw : rawValues) {
            System.out.println("raw " + raw + " -> deadband " + String.format("%.3f", applyDeadband(raw, 0.08))
                    + " -> curve " + String.format("%.3f", curve(applyDeadband(raw, 0.08))));
        }
        System.out.println("Stick pushed fully forward (leftY = -1.0): forward = "
                + forwardFromStick(-1.0));
        System.out.println("Half stick, slow mode: " + String.format("%.3f", stickToSpeed(-0.5, 4.0, true))
                + " m/s");
    }

    /** Exercise 1: turn the left stick's Y reading into "forward" for the robot (+ = forward). */
    static double forwardFromStick(double leftY) {
        return -leftY;
    }

    /**
     * Exercise 2: a deadband that doesn't jump. Inside the deadband (Math.abs(value) less than OR
     * EQUAL to deadband) return 0.0. Outside it, stretch what's left so the output still reaches
     * 1.0 at full stick:
     *
     * <pre>
     *   positive value:  (value - deadband) / (1.0 - deadband)
     *   negative value:  (value + deadband) / (1.0 - deadband)
     * </pre>
     *
     * <p>With deadband 0.08: 0.08 -> 0.0, 0.54 -> 0.5, 1.0 -> 1.0, -1.0 -> -1.0. This is what WPILib's
     * MathUtil.applyDeadband does.
     */
    static double applyDeadband(double value, double deadband) {
        if (Math.abs(value) <= deadband) {
            return 0.0;
        }
        if (value > 0) {
            return (value - deadband) / (1.0 - deadband);
        }
        return (value + deadband) / (1.0 - deadband);
    }

    /**
     * Exercise 3: square the value but keep its sign, so small pushes become gentler while full
     * stick stays 1.0. 0.5 -> 0.25 and -0.5 -> -0.25. Hint: Math.copySign(value * value, value).
     */
    static double curve(double value) {
        return Math.copySign(value * value, value);
    }

    /**
     * Exercise 4: put it together for the forward direction. Use forwardFromStick, then
     * applyDeadband with 0.08, then curve, then multiply by maxSpeed. In slow mode, also multiply
     * by 0.35. stickToSpeed(-1.0, 4.0, false) is 4.0 m/s; stickToSpeed(-1.0, 4.0, true) is 1.4.
     */
    static double stickToSpeed(double leftY, double maxSpeed, boolean slow) {
        double shaped = curve(applyDeadband(forwardFromStick(leftY), 0.08));
        double speed = shaped * maxSpeed;
        if (slow) {
            speed = speed * 0.35;
        }
        return speed;
    }

    /**
     * CHALLENGE: a ROUND deadband for the whole stick (x and y together). Find the stick's
     * distance from center, r = Math.hypot(x, y). If r is at most deadband, return {0.0, 0.0}.
     * Otherwise work out the new length, newR = (Math.min(r, 1.0) - deadband) / (1.0 - deadband),
     * and return {x * newR / r, y * newR / r}: same direction, new length. The real robot does
     * this so that gentle diagonal pushes stay diagonal.
     */
    static double[] roundDeadband(double x, double y, double deadband) {
        double r = Math.hypot(x, y);
        if (r <= deadband) {
            return new double[] {0.0, 0.0};
        }
        double newR = (Math.min(r, 1.0) - deadband) / (1.0 - deadband);
        return new double[] {x * newR / r, y * newR / r};
    }
}
