package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 4: decisions with if / else. Goes with Lesson 4, "Choose with if and else".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check04".
 *
 * <p>The limits in this file are made-up practice numbers, not real robot rules.
 */
public class Practice04Decisions {
    /** Change to true when you want the self-check to look at Exercise 2. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        // ---- Warm-up: the Lesson 4 decision, one more time. Predict, then Run. ----
        double distanceMeters = 0.8;
        if (distanceMeters < 1.0) {
            System.out.println("Too close");
        } else {
            System.out.println("Clear");
        }

        // ---- Exercise 1: test the boundary (no check; just predict and run) ----
        // Change 0.8 above to 1.0, then to 1.2. Before each run, write down your prediction.

        // ---- Exercise 2: finish batteryAdvice() further down this file ----
        // These lines ASK batteryAdvice() for an answer and print what comes back.
        System.out.println("11.2 volts: " + batteryAdvice(11.2));
        System.out.println("11.5 volts: " + batteryAdvice(11.5));
        System.out.println("12.3 volts: " + batteryAdvice(12.3));
        System.out.println("12.9 volts: " + batteryAdvice(12.9));

        // ---- CHALLENGE: finish inAimRange() further down ----
        System.out.println("Enabled, 3.0 m: " + inAimRange(true, 3.0));
        System.out.println("Disabled, 3.0 m: " + inAimRange(false, 3.0));
    }

    /**
     * Exercise 2. Practice battery rule (made up for this exercise):
     *
     * <pre>
     *   below 11.5 volts                   ->  "Change the battery"
     *   11.5 up to, but not including, 12.3 ->  "OK for practice"
     *   12.3 volts or more                 ->  "Ready for a match"
     * </pre>
     *
     * <p>New words: "else if" asks a SECOND question, only when the first answer was false.
     * "return" hands an answer back to the line that asked. (Lesson 5 explains return fully.)
     * Write one return inside each of the three blocks, like this shape:
     *
     * <pre>
     *   if (first question) {
     *       return "first answer";
     *   } else if (second question) {
     *       return "second answer";
     *   } else {
     *       return "third answer";
     *   }
     * </pre>
     */
    static String batteryAdvice(double volts) {
        if (volts < 11.5) {
            return "Change the battery";
        } else if (volts < 12.3) {
            return "OK for practice";
        } else {
            return "Ready for a match";
        }
    }

    /**
     * CHALLENGE. Practice rule (made up): aiming is allowed only when the robot is enabled AND
     * the target is from 2.0 to 4.5 meters away, including exactly 2.0 and exactly 4.5.
     *
     * <p>&amp;&amp; means "and": both sides must be true. || means "or": at least one side is true.
     * Try to write it with a single return line.
     */
    static boolean inAimRange(boolean enabled, double distanceMeters) {
        return enabled && distanceMeters >= 2.0 && distanceMeters <= 4.5;
    }
}
