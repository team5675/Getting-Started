package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class PracticeLight extends SubsystemBase {
    private boolean on = false;

    public void setOn(boolean requestedState) {
        on = requestedState;
        System.out.println("Light on: " + on);
    }
}
