package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.PracticeLight;

public class KeepLightOn extends Command {
    private final PracticeLight light;

    public KeepLightOn(PracticeLight light) {
        this.light = light;
        addRequirements(light);
    }

    @Override
    public void initialize() {
        light.setOn(true);
    }

    @Override
    public void end(boolean interrupted) {
        light.setOn(false);
    }
}
