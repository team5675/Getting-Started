package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 9, challenge: a value that can only change a little each loop.
 *
 * <p>If a driver slams the stick from 0 to full, the robot can tip or the wheels can slip. A
 * "rate limiter" lets the speed climb toward the request a bit every loop instead. WPILib has a
 * real one called SlewRateLimiter; writing a simple one shows how it works.
 */
public class PracticeRateLimiter {
    private final double maxStepPerLoop;
    private double value = 0.0;

    /** @param maxStepPerLoop the most the value may change in one loop (always positive) */
    public PracticeRateLimiter(double maxStepPerLoop) {
        this.maxStepPerLoop = maxStepPerLoop;
    }

    /**
     * CHALLENGE: called once per loop with the value we WANT. Move value toward target by at
     * most maxStepPerLoop, store it, and return it. If the target is closer than one step, go
     * straight to the target.
     *
     * <p>Check by hand with steps of 0.25: asking for 1.0 five times gives 0.25, 0.5, 0.75, 1.0,
     * 1.0. Then asking for 0.0 gives 0.75.
     */
    public double next(double target) {
        if (target > value + maxStepPerLoop) {
            value = value + maxStepPerLoop;
        } else if (target < value - maxStepPerLoop) {
            value = value - maxStepPerLoop;
        } else {
            value = target;
        }
        return value;
    }
}
