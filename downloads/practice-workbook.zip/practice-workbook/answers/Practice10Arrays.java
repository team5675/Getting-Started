package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE 10: arrays, many values of the same kind. Goes with Part 2, "Many of the same thing".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check10".
 *
 * <p>Wheel order in every array here: front-left, front-right, back-left, back-right. The robot
 * code uses the same order.
 */
public class Practice10Arrays {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        double[] batteryReadings = {12.6, 12.4, 12.1, 11.9};
        double[] wheelSpeeds = {2.1, -2.4, 1.9, 2.6};

        System.out.println("Average battery: " + average(batteryReadings));
        System.out.println("Fastest wheel: " + maxAbs(wheelSpeeds));

        double[] limited = desaturate(wheelSpeeds, 2.0);
        for (int i = 0; i < limited.length; i++) {
            System.out.println("Wheel " + i + ": " + String.format("%.3f", limited[i]) + " m/s");
        }
        System.out.println("Lowest reading is at index " + indexOfLowest(batteryReadings));
    }

    /**
     * Exercise 1: the average of all the values. Add them up in a loop, then divide by
     * values.length. (You may assume the array is never empty.)
     */
    static double average(double[] values) {
        double total = 0.0;
        for (double value : values) {
            total = total + value;
        }
        return total / values.length;
    }

    /**
     * Exercise 2: the biggest SIZE in the array, ignoring the sign. For {2.1, -2.4, 1.9} the answer
     * is 2.4: a wheel spinning backward at 2.4 m/s is still the fastest. Hint: Math.abs.
     */
    static double maxAbs(double[] values) {
        double biggest = 0.0;
        for (double value : values) {
            if (Math.abs(value) > biggest) {
                biggest = Math.abs(value);
            }
        }
        return biggest;
    }

    /**
     * Exercise 3: no wheel may go faster than maxSpeed. If the fastest wheel (use your maxAbs) is
     * too fast, multiply EVERY wheel by the same number, maxSpeed / fastest, so the robot still
     * moves in the same direction, only slower. Otherwise keep the speeds as they are.
     *
     * <p>Return a NEW array; don't change the one you were given. Start with:
     * {@code double[] result = new double[speeds.length];}
     */
    static double[] desaturate(double[] speeds, double maxSpeed) {
        double[] result = new double[speeds.length];
        double fastest = maxAbs(speeds);
        double scale = 1.0;
        if (fastest > maxSpeed) {
            scale = maxSpeed / fastest;
        }
        for (int i = 0; i < speeds.length; i++) {
            result[i] = speeds[i] * scale;
        }
        return result;
    }

    /**
     * CHALLENGE: the INDEX (position number) of the smallest value, not the value itself. For
     * {12.6, 12.4, 12.1, 11.9} the answer is 3. If two values tie, return the first one.
     */
    static int indexOfLowest(double[] values) {
        int best = 0;
        for (int i = 1; i < values.length; i++) {
            if (values[i] < values[best]) {
                best = i;
            }
        }
        return best;
    }
}
