package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE A6: time stamps. Goes with Advanced 6, "When was that picture taken?".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * Ctrl+Shift+P -> "WPILib: Test Robot Code" and look for "CheckA6".
 */
public class PracticeA6Timestamps {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge (PracticeStreamClock). */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        double picture = pictureTimeSeconds(12_345_678L, 35.0);
        System.out.println("Picture taken at " + String.format("%.4f", picture) + " s");
        System.out.println("Age check at 12.360 s: " + ageProblem(12.360 - picture));
        System.out.println("Age check, wrong units: " + ageProblem(12.360 - 12_345_678.0));
        System.out.println("3 m/s for 50 ms moves " + String.format("%.1f", distanceDuringLatencyCm(3.0, 0.050)) + " cm");
    }

    /**
     * Exercise 1: the robot received the camera's packet at receivedMicros MICROseconds on its clock
     * (that's the 2026 unit), and the camera says the picture is latencyMs milliseconds older than
     * that. Return when the picture was taken, in SECONDS.
     *
     * <p>12,345,678 microseconds with 35 ms of latency -> 12.345678 - 0.035 = 12.310678 s.
     */
    static double pictureTimeSeconds(long receivedMicros, double latencyMs) {
        return receivedMicros / 1_000_000.0 - latencyMs / 1000.0;
    }

    /**
     * Exercise 2: is a picture's age believable? Return null if it's fine, otherwise a reason:
     *
     * <pre>
     *   below -0.05 s       -> "picture time is in the future"   (a little slack for clock jitter)
     *   above 0.5 s         -> "picture is too old"
     *   otherwise           -> null
     * </pre>
     */
    static String ageProblem(double ageSeconds) {
        if (ageSeconds < -0.05) {
            return "picture time is in the future";
        } else if (ageSeconds > 0.5) {
            return "picture is too old";
        }
        return null;
    }

    /**
     * Exercise 3: how many CENTIMETERS does a robot moving at speedMetersPerSec travel during
     * latencySeconds? (This is how far behind a picture is if you pretend it was taken "now".)
     */
    static double distanceDuringLatencyCm(double speedMetersPerSec, double latencySeconds) {
        return speedMetersPerSec * latencySeconds * 100.0;
    }
}
