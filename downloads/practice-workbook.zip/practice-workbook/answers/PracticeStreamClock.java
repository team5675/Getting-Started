package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE A6, challenge: keep a separate time-stamp verdict for each camera stream.
 *
 * <p>A Limelight sends two pose streams, MegaTag1 and MegaTag2, and they don't always arrive in the
 * same loop. In October 2026 the robot kept ONE verdict for both, so a good MegaTag2 packet could
 * hide a bad MegaTag1 packet. This class keeps two, the way the robot does now.
 */
public class PracticeStreamClock {
    private String mt1Problem = null;
    private String mt2Problem = null;

    /**
     * Challenge: A NEW packet arrived on one stream (1 = MegaTag1, 2 = MegaTag2). Judge it with
     * PracticeA6Timestamps.ageProblem(ageSeconds) and store the verdict for THAT stream only.
     */
    public void newPacket(int stream, double ageSeconds) {
        String verdict = PracticeA6Timestamps.ageProblem(ageSeconds);
        if (stream == 1) {
            mt1Problem = verdict;
        } else if (stream == 2) {
            mt2Problem = verdict;
        }
    }

    /**
     * Challenge: null if both streams are fine. Otherwise "MegaTag1: " + its problem if MegaTag1 has one
     * (it's checked first because it seeds the pose), else "MegaTag2: " + its problem.
     */
    public String problem() {
        if (mt1Problem != null) {
            return "MegaTag1: " + mt1Problem;
        } else if (mt2Problem != null) {
            return "MegaTag2: " + mt2Problem;
        }
        return null;
    }
}
