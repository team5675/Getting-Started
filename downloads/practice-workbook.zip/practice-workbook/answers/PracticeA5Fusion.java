package frc.robot.practice;

/**
 * ANSWER KEY for PRACTICE A5: blending and trust. Goes with Advanced 5, "Blend wheels and camera".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "CheckA5".
 *
 * <p>Plain Java on purpose: these are the rules inside the robot's vision code, small enough to
 * write and test yourself.
 */
public class PracticeA5Fusion {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = true;

    /** Change to true when you want the self-check to look at the challenge (PracticeSeedTracker). */
    static final boolean CHECK_CHALLENGE = true;

    public static void main(String[] args) {
        System.out.println("blend(5.00, 5.40, 0.1, 0.3) = " + String.format("%.3f", blend(5.00, 5.40, 0.1, 0.3)));
        System.out.println("camera std dev, 1 tag at 2 m = " + cameraStdDev(1, 2.0));
        System.out.println("camera std dev, 2 tags at 2 m = " + cameraStdDev(2, 2.0));
        System.out.println("reject? " + rejectReason(true, 2, 0.04, 3.0, 2.0, 0.5));
        System.out.println("reject? " + rejectReason(true, 2, 0.04, 18.0, 2.0, 0.5));
    }

    /**
     * Exercise 1: WPILib's blending rule for one measurement. The camera gets this share of the
     * difference: share = odometryStdDev / (odometryStdDev + cameraStdDev). Return
     * odometryX + share * (cameraX - odometryX).
     *
     * <p>blend(5.00, 5.40, 0.1, 0.3) is 5.10: the camera gets a quarter of the 0.40 m difference.
     */
    static double blend(double odometryX, double cameraX, double odometryStdDev, double cameraStdDev) {
        double share = odometryStdDev / (odometryStdDev + cameraStdDev);
        return odometryX + share * (cameraX - odometryX);
    }

    /**
     * Exercise 2: how much to trust a camera fix, as a standard deviation in meters. Bigger means
     * trust it LESS. This is the robot's rule, slightly simplified:
     *
     * <pre>
     *   stdDev = 0.5 + 0.15 * avgDistanceMeters
     *   2 or more tags: multiply by 0.5
     *   finally keep it between 0.1 and 3.0 (Math.max and Math.min, or your clamp from Practice 5)
     * </pre>
     */
    static double cameraStdDev(int tagCount, double avgDistanceMeters) {
        double stdDev = 0.5 + 0.15 * avgDistanceMeters;
        if (tagCount >= 2) {
            stdDev = stdDev * 0.5;
        }
        return Math.max(0.1, Math.min(3.0, stdDev));
    }

    /**
     * Exercise 3: should this camera fix be thrown away? Return the FIRST reason that applies, in
     * this order, or null if the fix is fine:
     *
     * <pre>
     *   not connected                         -> "camera not connected"
     *   tagCount is 0                         -> "no tags"
     *   ageSeconds below 0 or above 0.5       -> "bad timestamp"
     *   x outside -0.25 to 16.79, or
     *   y outside -0.25 to 8.32               -> "off the field"
     *   turn rate faster than Math.PI rad/s   -> "turning too fast" (use Math.abs: either direction)
     * </pre>
     *
     * <p>null means "no value". Return it with: return null;
     */
    static String rejectReason(boolean connected, int tagCount, double ageSeconds,
            double x, double y, double turnRateRadPerSec) {
        if (!connected) {
            return "camera not connected";
        } else if (tagCount == 0) {
            return "no tags";
        } else if (ageSeconds < 0 || ageSeconds > 0.5) {
            return "bad timestamp";
        } else if (x < -0.25 || x > 16.79 || y < -0.25 || y > 8.32) {
            return "off the field";
        } else if (Math.abs(turnRateRadPerSec) > Math.PI) {
            return "turning too fast";
        }
        return null;
    }
}
