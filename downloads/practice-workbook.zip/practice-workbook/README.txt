TEAM 5675 PRACTICE WORKBOOK  (WPILib 2026, Java)
================================================

Extra exercises for the robot-project lessons (from the robot loop on), with
self-checks. Practice for Lessons 2-7B is in the Java foundations download
(home-java-starter): drills after Lessons 2-6, then Lessons 7A and 7B.
Full instructions with pictures: the "Your practice workbook" page of the guide.

This folder is a complete project: a copy of the simulation starter with the
practice files already added. Nothing needs to be copied in from another download.

SET UP (once, about 15 minutes)
  1. Right-click practice-workbook.zip > Extract All. Replace the suggested
     path with C:\dev and click Extract. You now have C:\dev\practice-workbook.
  2. Check that this folder contains build.gradle, robot.cmd, src and answers.
     (On a Mac: double-click the ZIP, drag the folder into ~/dev, and use
     ./robot.sh wherever these notes say .\robot.)
     Keep it outside OneDrive, like sim-starter.
  3. In 2026 WPILib VS Code: File > Open Folder > C:\dev\practice-workbook.

RUN A PRACTICE FILE
  Open src/main/java/frc/robot/practice/Practice09RobotLoop.java.
  Click the small gray "Run" just above "public static void main".
  The output appears in the Terminal.

CHECK YOUR WORK
  Change CHECK_MY_WORK = false to true near the top of the practice file, save,
  then open a PowerShell Terminal in the project folder and run:
  .\robot test --tests "frc.robot.practice.*"
  BUILD SUCCESSFUL = every check you switched on passed.
  FAILED = that exercise isn't finished yet; the next lines give a hint.
  CHECK_CHALLENGE does the same for the optional (star) challenge.

WHICH FILE GOES WITH WHICH LESSON
  Lessons 2-7B  not here: see home-java-starter (drills, ObjectsTogether,
                TextAndConditions)
  Lesson 8  answers/lesson-8 (known-good light subsystem and command)
  Part 2, the robot loop        Practice09RobotLoop + PracticeBlinker + PracticeRateLimiter
  Part 2, arrays                Practice10Arrays
  Part 2, reading a controller  Practice11Controller
  Advanced 4, cameras           PracticeA4Cameras (uses WPILib geometry)
  Advanced 5, fusion            PracticeA5Fusion + PracticeSeedTracker
  Advanced 6, time stamps       PracticeA6Timestamps + PracticeStreamClock
  Advanced 8, camera check      PracticeA8CameraCheck

  The optional challenges are marked CHALLENGE in each file.

ANSWERS
  The "answers" folder has finished versions. Try first, then compare
  (right-click a file tab > Split Right to see two files side by side).
  Its numbered subfolders 01-06 belong to the simulation labs; ignore them here.
