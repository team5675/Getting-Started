TEAM 5675 PRACTICE WORKBOOK  (WPILib 2026, Java)
================================================

Extra exercises for the Getting Started lessons, with self-checks.
Full instructions with pictures: the "Your practice workbook" page of the guide.

SET UP (once, about 15 minutes)
  1. Extract a fresh sim-starter download to C:\dev\practice-workbook.
     This folder must contain build.gradle, gradlew.bat and src. Do not create
     another WPILib template or merge into your plain-Java lessons folder.
  2. Copy this download's "src" folder into C:\dev\practice-workbook
     (the folder that contains build.gradle). Windows merges the folders; nothing
     should be replaced. Copy the "answers" folder there too.
  3. File > Open Folder > C:\dev\practice-workbook.

RUN A PRACTICE FILE
  Open src/main/java/frc/robot/practice/Practice02FirstProgram.java.
  Click the small gray "Run" just above "public static void main".
  The output appears in the Terminal.

CHECK YOUR WORK
  Change CHECK_MY_WORK = false to true near the top of the practice file, save,
  then open a PowerShell Terminal in the project folder and run:
  .\gradlew.bat test --tests "frc.robot.practice.*"
  BUILD SUCCESSFUL = every check you switched on passed.
  FAILED = that exercise isn't finished yet; the next lines give a hint.
  CHECK_CHALLENGE does the same for the optional (star) challenge.

WHICH FILE GOES WITH WHICH LESSON
  Lesson 2  Practice02FirstProgram
  Lesson 3  Practice03Values
  Lesson 4  Practice04Decisions
  Lesson 5  Practice05Methods
  Lesson 6  Practice06Loops
  Lesson 7  Practice07Objects + PracticeBattery
  Lesson 8  answers/lesson-8 (known-good light subsystem and command)
  Part 2, the robot loop        Practice09RobotLoop + PracticeBlinker + PracticeRateLimiter
  Part 2, arrays                Practice10Arrays
  Part 2, reading a controller  Practice11Controller
  Advanced 4, cameras           PracticeA4Cameras (uses WPILib geometry)
  Advanced 5, fusion            PracticeA5Fusion + PracticeSeedTracker
  Advanced 6, time stamps       PracticeA6Timestamps + PracticeStreamClock
  Advanced 8, camera check      PracticeA8CameraCheck

  The optional challenges are marked CHALLENGE in each file.

ANSWERS
  The "answers" folder has finished versions. Try first, then compare
  (right-click a file tab > Split Right to see two files side by side).
