package frc.robot.practice;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Transform2d;

/**
 * PRACTICE A4: from a camera sighting to a robot pose. Goes with Advanced 4, "Cameras and
 * AprilTags". This file uses WPILib's geometry classes, so it only runs inside a WPILib project
 * (your practice workbook is one).
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * Ctrl+Shift+P -> "WPILib: Test Robot Code" and look for "CheckA4".
 *
 * <p>All positions are made up for practice. They are not a real field layout.
 */
public class PracticeA4Cameras {
    /** Change to true when you want the self-check to look at Exercises 1 and 2. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        Pose2d tagOnField = new Pose2d(8.0, 4.0, Rotation2d.fromDegrees(180));
        Transform2d cameraToTag = new Transform2d(3.0, 0.5, Rotation2d.fromDegrees(180));
        Transform2d robotToCamera = new Transform2d(0.30, 0.0, new Rotation2d());
        System.out.println("Robot: " + robotFromTag(tagOnField, cameraToTag, robotToCamera));

        System.out.println("2 degrees off at 3 m: " + String.format("%.3f", sidewaysError(3.0, 2.0)) + " m");
        System.out.println("2 degrees off at 6 m: " + String.format("%.3f", sidewaysError(6.0, 2.0)) + " m");

        Pose2d[] estimates = {
            new Pose2d(4.68, 3.52, new Rotation2d()),
            new Pose2d(4.73, 3.49, new Rotation2d()),
            new Pose2d(4.69, 3.49, new Rotation2d()),
        };
        System.out.println("Average: " + averagePosition(estimates));
    }

    /**
     * Exercise 1: the MegaTag1 idea. You know where the tag is on the field, where the camera saw it
     * (cameraToTag), and where the camera sits on the robot (robotToCamera). Return the robot's pose
     * on the field. Two steps, both with transformBy and inverse():
     *
     * <pre>
     *   camera on field = tag on field, moved back along cameraToTag
     *   robot on field  = camera on field, moved back along robotToCamera
     * </pre>
     *
     * <p>With the numbers in main(), the answer is x 4.70, y 3.50, heading 0 degrees.
     */
    static Pose2d robotFromTag(Pose2d tagOnField, Transform2d cameraToTag, Transform2d robotToCamera) {
        return new Pose2d();
    }

    /**
     * Exercise 2: if a camera's direction is off by a small angle, a tag at distanceMeters appears
     * sideways by about distanceMeters * sin(angle). Return that, in meters. Math.sin needs RADIANS:
     * use Math.toRadians(angleErrorDegrees). 2 degrees at 3 m is about 0.105 m.
     */
    static double sidewaysError(double distanceMeters, double angleErrorDegrees) {
        return 0.0;
    }

    /**
     * CHALLENGE: average several position estimates, the way more frames give a steadier answer.
     * Average the x values and the y values separately. Use the FIRST estimate's heading. Return a
     * new Pose2d.
     */
    static Pose2d averagePosition(Pose2d[] estimates) {
        return new Pose2d();
    }
}
