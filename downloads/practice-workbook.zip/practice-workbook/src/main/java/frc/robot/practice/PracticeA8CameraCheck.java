package frc.robot.practice;

/**
 * PRACTICE A8: judging a camera against a tape measure. Goes with Advanced 8.
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "CheckA8".
 *
 * <p>The readings are made up for practice.
 */
public class PracticeA8CameraCheck {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        double referenceX = 2.000; // measured with a tape measure and a jig
        double[] cameraX = {2.031, 2.027, 2.035, 2.029, 2.033, 2.030, 2.028, 2.034, 2.032, 2.031};

        double b = bias(cameraX, referenceX);
        System.out.println("Bias: " + String.format("%.4f", b) + " m");
        System.out.println("Scatter: " + String.format("%.4f", scatter(cameraX)) + " m");
        System.out.println("Verdict (limit 5 cm, reference +/-1 cm): " + verdict(b, 0.010, 0.050));
        System.out.println("Verdict (limit 5 cm, reference +/-2.5 cm): " + verdict(b, 0.025, 0.050));
        System.out.println("Heading uncertainty: " + String.format("%.2f", headingUncertaintyDegrees(750, 5)) + " degrees");
    }

    /** Exercise 1: how far the camera's AVERAGE reading is from the measured reference (average - reference). */
    static double bias(double[] cameraValues, double reference) {
        return 0.0;
    }

    /**
     * Exercise 2: how spread out the readings are: the standard deviation. For each value, square
     * its distance from the average; add those up; divide by (count - 1); take Math.sqrt.
     */
    static double scatter(double[] values) {
        return 0.0;
    }

    /**
     * Exercise 3: the decision. The true bias could be anywhere from |bias| - referenceUncertainty
     * to |bias| + referenceUncertainty.
     *
     * <pre>
     *   |bias| + uncertainty is at most limit   -> "PASS"         (even the worst case is OK)
     *   |bias| - uncertainty is above limit     -> "FAIL"         (even the best case is too far)
     *   otherwise                               -> "INCONCLUSIVE" (measure the reference better)
     * </pre>
     */
    static String verdict(double bias, double referenceUncertainty, double limit) {
        return "not written yet";
    }

    /**
     * CHALLENGE: a jig touches the robot at two points contactSpacingMm apart. If one point can be
     * off by gapDifferenceMm more than the other, the robot's heading is uncertain by
     * atan(gap / spacing). Return that angle in DEGREES (Math.atan and Math.toDegrees).
     * 5 mm over 750 mm is about 0.38 degrees.
     */
    static double headingUncertaintyDegrees(double contactSpacingMm, double gapDifferenceMm) {
        return 0.0;
    }
}
