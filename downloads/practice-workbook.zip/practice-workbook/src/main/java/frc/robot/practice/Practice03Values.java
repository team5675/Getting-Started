package frc.robot.practice;

/**
 * PRACTICE 3: variables (named values). Goes with Lesson 3, "Give information a name".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * Ctrl+Shift+P -> "WPILib: Test Robot Code" and look for "Check03".
 *
 * <p>The numbers here are made up for practice. They are not real robot settings.
 */
public class Practice03Values {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        // ---- Warm-up: three kinds of value. Predict the two printed lines, then Run. ----
        double batteryVolts = 12.6;          // double: a number that can have a decimal point
        int tagsSeen = 2;                    // int: a whole number
        String cameraName = "limelight-front"; // String: text, always in double quotes

        System.out.println("Battery: " + batteryVolts + " volts");
        System.out.println(cameraName + " sees " + tagsSeen + " tags");

        // ---- Exercise 1: change a value that already exists ----
        // Below this comment, give batteryVolts a NEW value of 12.1. Don't write "double" again:
        // the variable already exists, you're only changing what it holds.
        // Then copy the "Battery: ..." print line from above so it prints the new value.


        // ---- Exercise 2: arithmetic with variables ----
        // Full speed is 4.0 meters per second and slow mode is half of full speed.
        // Replace the two 0.0 values so this prints:   Slow speed: 2.0 m/s
        double maxSpeedMetersPerSec = 0.0;
        double slowScale = 0.0;
        double slowSpeed = maxSpeedMetersPerSec * slowScale;
        System.out.println("Slow speed: " + slowSpeed + " m/s");

        // ---- Exercise 3: text or a name? ----
        // Predict these two lines BEFORE you run. Why are they different?
        System.out.println("tagsSeen");
        System.out.println(tagsSeen);
        // Now add a line that prints exactly   Tags: 2
        // using the tagsSeen variable (don't type the 2 yourself).


        // ---- CHALLENGE: whole numbers divide differently ----
        // Teleop lasts 135 seconds. Make an int variable for 135, then use / and % to print
        //   Teleop: 2:15
        // Hint: for ints, 135 / 60 is 2 (the decimal part is dropped) and 135 % 60 is 15
        // (% gives the REMAINDER). Try 75 seconds too: what goes wrong with 1:5, and how
        // could an if fix it? (The check only tests 135.)

    }
}
