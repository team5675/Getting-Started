package frc.robot.practice;

/**
 * PRACTICE A6, challenge: keep a separate time-stamp verdict for each camera stream.
 *
 * <p>A Limelight sends two pose streams, MegaTag1 and MegaTag2, and they don't always arrive in the
 * same loop. In October 2026 the robot kept ONE verdict for both, so a good MegaTag2 packet could
 * hide a bad MegaTag1 packet. This class keeps two, the way the robot does now.
 */
public class PracticeStreamClock {
    private String mt1Problem = null;
    private String mt2Problem = null;

    /**
     * Challenge: A NEW packet arrived on one stream (1 = MegaTag1, 2 = MegaTag2). Judge it with
     * PracticeA6Timestamps.ageProblem(ageSeconds) and store the verdict for THAT stream only.
     */
    public void newPacket(int stream, double ageSeconds) {
    }

    /**
     * Challenge: null if both streams are fine. Otherwise "MegaTag1: " + its problem if MegaTag1 has one
     * (it's checked first because it seeds the pose), else "MegaTag2: " + its problem.
     */
    public String problem() {
        return null;
    }
}
