package frc.robot.practice;

/**
 * PRACTICE 2: print messages. Goes with Lesson 2, "Run your first program".
 *
 * <p>HOW TO RUN THIS FILE: look just above the line "public static void main" below. VS Code shows
 * two small gray words, Run | Debug. Click Run. The output appears in the TERMINAL panel at the
 * bottom of the window. This file is plain Java, so no simulator is needed.
 *
 * <p>HOW TO CHECK YOUR WORK: finish the exercises, change CHECK_MY_WORK below from false to true,
 * save, then press Ctrl+Shift+P and choose "WPILib: Test Robot Code". Look for "Check02" in the
 * results. A check that says FAILED tells you which exercise to look at again.
 *
 * <p>Everyone: Exercises 1 to 3. Programmed before? Also do the challenge, and set
 * CHECK_CHALLENGE to true.
 */
public class Practice02FirstProgram {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        // ---- Warm-up: read these three lines, PREDICT the output, then click Run. ----
        System.out.println("Practice 2 is running.");
        System.out.print("print() stays on the same line, ");
        System.out.println("and println() ends the line.");

        // ---- Exercise 1: make it yours ----
        // Change the text between the quotes so it says your first name, for example:
        //   My name is Morgan
        System.out.println("My name is ...");

        // ---- Exercise 2: repair a mistake ----
        // The line below is switched off: the two slashes at the start make it a "comment",
        // and Java ignores comments. Delete the two slashes, click Run, and read the error.
        // Then fix the one missing character and run again.
        // System.out.println("Robot ready")

        // ---- Exercise 3: three lines in a row ----
        // Add three println statements below this comment so the program prints these three
        // lines, one after another:
        //   Robot: practice bot
        //   Battery: OK
        //   Ready!


        // ---- CHALLENGE ----
        // Make ONE println statement that prints TWO lines:
        //   Team 5675
        //   WiredCats
        // Hint: inside the quotes, \n means "start a new line here".

    }
}
