package frc.robot.practice;

/**
 * PRACTICE 7 (part 2 of 2): objects. Goes with Lesson 7, "Build two separate objects".
 *
 * <p>First finish the exercises inside PracticeBattery.java (same folder). Then Run this file.
 * Check: set CHECK_MY_WORK to true in THIS file, save, then type
 * .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check07".
 */
public class Practice07Objects {
    /** Change to true when you want the self-check to look at Exercises 1 and 2. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        // Two objects made from ONE class. Each starts with its own first reading.
        PracticeBattery batteryA = new PracticeBattery("Battery A", 12.8);
        PracticeBattery batteryB = new PracticeBattery("Battery B", 12.6);

        // Predict before you Run: which battery's lowest reading changes on each line?
        batteryA.record(12.4);
        batteryA.record(11.3);
        batteryA.record(12.0);
        batteryB.record(12.5);

        printRecord(batteryA);
        printRecord(batteryB);

        // After the challenge works, a new match starts fresh for Battery A only:
        batteryA.startNewMatch(12.7);
        printRecord(batteryA);
    }

    /** Prints one battery's records. This method works on WHICHEVER object you hand it. */
    static void printRecord(PracticeBattery battery) {
        System.out.println(battery.getLabel() + ": lowest " + battery.getLowestVolts()
                + " V, readings: " + battery.getReadingCount()
                + ", dropped too low: " + battery.droppedTooLow());
    }
}
