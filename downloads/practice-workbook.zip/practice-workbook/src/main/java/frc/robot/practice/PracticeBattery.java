package frc.robot.practice;

/**
 * PRACTICE 7 (part 1 of 2): a class. Goes with Lesson 7, "Build two objects".
 *
 * <p>One PracticeBattery object keeps the records for ONE battery: its label, the lowest voltage
 * seen so far, and how many readings it has had. Practice07Objects makes two of them and shows
 * that each keeps its own records.
 *
 * <p>The real robot does the same kind of thing: the health check keeps the highest current
 * seen on each power channel, and resets those records at the start of every auto.
 */
public class PracticeBattery {
    // Fields: each PracticeBattery object gets its own copy of these three.
    private String label;
    private double lowestVolts;
    private int readingCount;

    /** The constructor: runs once, when "new PracticeBattery(...)" creates an object. */
    public PracticeBattery(String batteryLabel, double firstReading) {
        label = batteryLabel;
        lowestVolts = firstReading;
        readingCount = 1;
    }

    /**
     * Exercise 1: record one new voltage reading. Add 1 to readingCount. Then, if volts is
     * lower than lowestVolts, store volts in lowestVolts.
     */
    public void record(double volts) {
        // Write your two steps here.
    }

    /**
     * Exercise 2: return true if the lowest reading so far is below 11.5 volts (a made-up
     * practice limit), otherwise false. Hint: a comparison like (a &lt; b) is already true or
     * false, so you can return it directly.
     */
    public boolean droppedTooLow() {
        return false;
    }

    /**
     * CHALLENGE: start fresh for a new match, like the robot does when auto begins. Make
     * volts the lowest reading and set the reading count back to 1. Keep the label.
     */
    public void startNewMatch(double volts) {
    }

    // Getters: methods that hand back a field's value. These are finished.

    public String getLabel() {
        return label;
    }

    public double getLowestVolts() {
        return lowestVolts;
    }

    public int getReadingCount() {
        return readingCount;
    }
}
