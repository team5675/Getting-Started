package frc.robot.practice;

/**
 * PRACTICE 9: the robot loop. Goes with Part 2, "The robot's heartbeat".
 *
 * <p>A real robot program runs its periodic methods every 20 milliseconds (0.02 s), 50 times a
 * second. Here we pretend: main() calls periodic() 100 times in a row, which stands for 2 seconds.
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * Ctrl+Shift+P -> "WPILib: Test Robot Code" and look for "Check09".
 */
public class Practice09RobotLoop {
    /** Change to true when you want the self-check to look at Exercises 1 and 2. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenge. */
    static final boolean CHECK_CHALLENGE = false;

    /** How long one robot loop lasts, in seconds. */
    static final double LOOP_SECONDS = 0.02;

    public static void main(String[] args) {
        System.out.println("A 135-second teleop is " + loopsIn(135.0) + " loops");

        // Pretend to be WPILib: call periodic() 100 times, one call per 20 ms.
        PracticeBlinker blinker = new PracticeBlinker();
        boolean wasOn = blinker.isOn();
        for (int loop = 1; loop <= 100; loop++) {
            blinker.periodic();
            if (blinker.isOn() != wasOn) {
                double seconds = loop * LOOP_SECONDS;
                System.out.println("At " + String.format("%.2f", seconds) + " s the light turned "
                        + (blinker.isOn() ? "ON" : "OFF"));
                wasOn = blinker.isOn();
            }
        }

        // CHALLENGE: a speed that can't jump. Ask for full speed at once and watch it ramp up.
        PracticeRateLimiter limiter = new PracticeRateLimiter(0.25);
        for (int loop = 1; loop <= 5; loop++) {
            System.out.println("Loop " + loop + ": speed " + limiter.next(1.0));
        }
    }

    /**
     * Exercise 1: how many 20 ms loops happen in this many seconds? Divide by LOOP_SECONDS, then
     * round to the nearest whole number with Math.round(...). Math.round gives back a "long" (a
     * bigger kind of whole number), so put (int) in front of it to make an int:
     * {@code (int) Math.round(...)}.
     */
    static int loopsIn(double seconds) {
        return 0;
    }
}
