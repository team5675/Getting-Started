package frc.robot.practice;

/**
 * PRACTICE A5, challenge: the robot's "can we trust the heading?" memory, in miniature.
 *
 * <p>Two separate facts (see Advanced 5):
 *
 * <ul>
 *   <li>headingTrusted: a camera fix lined the heading up with the field, and nothing has
 *       overwritten it since. While true, the camera may correct x and y (MegaTag2).
 *   <li>refreshWanted: we'd like a fresh full fix (MegaTag1), which is only allowed while disabled.
 * </ul>
 *
 * <p>Start: not trusted, refresh wanted. Fill in the four methods marked *.
 */
public class PracticeSeedTracker {
    private boolean headingTrusted = false;
    private boolean refreshWanted = true;

    /** Challenge: The robot was disabled: ask for a fresh fix, but KEEP trusting the heading. */
    public void requestRefresh() {
    }

    /** Challenge: Someone reset the heading or doubts it: stop trusting it AND ask for a fresh fix. */
    public void forget() {
    }

    /** Challenge: A good full fix was used: the heading is trusted, and no refresh is needed now. */
    public void seeded() {
    }

    /** Challenge: May the robot try a full fix now? Only while disabled AND a refresh is wanted. */
    public boolean canAttemptSeed(boolean disabled) {
        return false;
    }

    /** Finished: true when the camera may correct x and y. */
    public boolean headingTrusted() {
        return headingTrusted;
    }

    /** Finished: true while a fresh full fix has been asked for. */
    public boolean refreshWanted() {
        return refreshWanted;
    }
}
