package frc.robot.practice;

/**
 * PRACTICE 5: methods that take inputs and return answers. Goes with Lesson 5, "Give an action a name".
 *
 * <p>Run: click the small Run above main(). Check: set CHECK_MY_WORK to true, save, then
 * type .\robot test --tests "frc.robot.practice.*" in the Terminal; look for "Check05".
 *
 * <p>Each exercise is a method below main(). Its comment says what it should return. Right now each
 * one returns a placeholder, so the program runs but prints wrong answers until you fix them.
 */
public class Practice05Methods {
    /** Change to true when you want the self-check to look at Exercises 1 to 3. */
    static final boolean CHECK_MY_WORK = false;

    /** Change to true when you want the self-check to look at the challenges. */
    static final boolean CHECK_CHALLENGE = false;

    public static void main(String[] args) {
        // ---- Warm-up: Java comes with methods you can call. Predict, then Run. ----
        System.out.println("Math.abs(-3.5) = " + Math.abs(-3.5));
        System.out.println("Math.max(2, 7) = " + Math.max(2, 7));

        // ---- These lines call YOUR methods. ----
        System.out.println("2.54 meters = " + metersToCentimeters(2.54) + " cm");
        System.out.println("clamp(1.4, -1.0, 1.0) = " + clamp(1.4, -1.0, 1.0));
        System.out.println("clamp(-0.3, -1.0, 1.0) = " + clamp(-0.3, -1.0, 1.0));
        System.out.println("outputToVolts(0.25) = " + outputToVolts(0.25));
        System.out.println("outputToVolts(1.5) = " + outputToVolts(1.5));

        // challenges:
        System.out.println("distanceBetween(0, 0, 3, 4) = " + distanceBetween(0, 0, 3, 4));
        System.out.println("applyDeadband(0.05, 0.1) = " + applyDeadband(0.05, 0.1));
    }

    /** Exercise 1: return the same length in centimeters (1 meter is 100 centimeters). */
    static double metersToCentimeters(double meters) {
        return 0.0;
    }

    /**
     * Exercise 2: keep a value inside a range. If value is below min, return min. If it is above
     * max, return max. Otherwise return value unchanged. (WPILib has its own, MathUtil.clamp; the
     * robot code uses that one. Writing it yourself shows how it works.)
     */
    static double clamp(double value, double min, double max) {
        return value;
    }

    /**
     * Exercise 3: a motor "output" goes from -1.0 (full reverse) to 1.0 (full forward). Turn it
     * into volts on a 12-volt battery: output times 12. But first keep the output between -1.0 and
     * 1.0 by CALLING your clamp() method. So outputToVolts(1.5) should be 12.0, not 18.0.
     */
    static double outputToVolts(double output) {
        return 0.0;
    }

    /**
     * CHALLENGE: the straight-line distance between point (x1, y1) and point (x2, y2). Hint:
     * Math.hypot(dx, dy) returns the length of the hypotenuse of a right triangle. The advanced
     * track uses exactly this to find the distance from the robot to a field target.
     */
    static double distanceBetween(double x1, double y1, double x2, double y2) {
        return 0.0;
    }

    /**
     * CHALLENGE: a joystick never rests at exactly 0. If the value is closer to 0 than
     * deadband (in either direction), return 0.0; otherwise return value unchanged. Hint:
     * Math.abs. (Part 2 of the guide improves this so the output doesn't jump.)
     */
    static double applyDeadband(double value, double deadband) {
        return value;
    }
}
