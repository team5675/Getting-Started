package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Self-check for Practice03Values. Read the message of any FAILED check for a hint. */
class Check03Values {
    @Test
    void exercise1_newBatteryValue() throws Exception {
        assumeTrue(Practice03Values.CHECK_MY_WORK, "Practice 3" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice03Values::main);
        assertTrue(lines.contains("Battery: 12.6 volts") && lines.contains("Battery: 12.1 volts"),
                "Exercise 1: keep the first Battery line, then change batteryVolts to 12.1 and"
                        + " print it again with the same message" + printed(lines));
    }

    @Test
    void exercise2_slowSpeed() throws Exception {
        assumeTrue(Practice03Values.CHECK_MY_WORK, "Practice 3" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice03Values::main);
        assertTrue(lines.contains("Slow speed: 2.0 m/s"),
                "Exercise 2: full speed is 4.0 and slow mode is half of it, so the line should be"
                        + " Slow speed: 2.0 m/s" + printed(lines));
    }

    @Test
    void exercise3_tagsLine() throws Exception {
        assumeTrue(Practice03Values.CHECK_MY_WORK, "Practice 3" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice03Values::main);
        assertTrue(lines.contains("Tags: 2"),
                "Exercise 3: print \"Tags: \" + tagsSeen" + printed(lines));
    }

    @Test
    void challenge_teleopClock() throws Exception {
        assumeTrue(Practice03Values.CHECK_CHALLENGE, "Practice 3" + NO_CHALLENGE);
        List<String> lines = linesPrintedBy(Practice03Values::main);
        assertTrue(lines.contains("Teleop: 2:20"),
                "CHALLENGE: expected the line Teleop: 2:20" + printed(lines));
    }
}
