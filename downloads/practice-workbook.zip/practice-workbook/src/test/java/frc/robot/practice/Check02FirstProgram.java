package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Self-check for Practice02FirstProgram. Read the message of any FAILED check for a hint. */
class Check02FirstProgram {
    @Test
    void exercise1_myNameIs() throws Exception {
        assumeTrue(Practice02FirstProgram.CHECK_MY_WORK, "Practice 2" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice02FirstProgram::main);
        boolean found = false;
        for (String line : lines) {
            if (line.startsWith("My name is ") && !line.equals("My name is ...")
                    && line.length() > "My name is ".length()) {
                found = true;
            }
        }
        assertTrue(found, "Exercise 1: change \"...\" to your name, like: My name is Morgan"
                + printed(lines));
    }

    @Test
    void exercise2_robotReady() throws Exception {
        assumeTrue(Practice02FirstProgram.CHECK_MY_WORK, "Practice 2" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice02FirstProgram::main);
        assertTrue(lines.contains("Robot ready"),
                "Exercise 2: remove the // and add the missing semicolon so it prints Robot ready"
                        + printed(lines));
    }

    @Test
    void exercise3_threeLinesInARow() throws Exception {
        assumeTrue(Practice02FirstProgram.CHECK_MY_WORK, "Practice 2" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice02FirstProgram::main);
        assertTrue(hasLinesInARow(lines, "Robot: practice bot", "Battery: OK", "Ready!"),
                "Exercise 3: expected these three lines in a row: Robot: practice bot / Battery: OK"
                        + " / Ready!  (check spelling, capitals and the colon)" + printed(lines));
    }

    @Test
    void challenge_twoLinesFromOnePrintln() throws Exception {
        assumeTrue(Practice02FirstProgram.CHECK_CHALLENGE, "Practice 2" + NO_CHALLENGE);
        List<String> lines = linesPrintedBy(Practice02FirstProgram::main);
        assertTrue(hasLinesInARow(lines, "Team 5675", "WiredCats"),
                "CHALLENGE: expected Team 5675 and WiredCats on two lines in a row" + printed(lines));
    }
}
