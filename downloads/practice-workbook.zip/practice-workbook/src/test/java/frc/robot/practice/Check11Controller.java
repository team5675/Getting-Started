package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for Practice11Controller. */
class Check11Controller {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_forwardFromStick() {
        assumeTrue(Practice11Controller.CHECK_MY_WORK, "Practice 11" + NOT_YET);
        assertEquals(1.0, Practice11Controller.forwardFromStick(-1.0), CLOSE,
                "Exercise 1: stick fully forward reads -1.0, which should mean forward = +1.0");
        assertEquals(-0.5, Practice11Controller.forwardFromStick(0.5), CLOSE,
                "Exercise 1: stick pulled back halfway means backward");
    }

    @Test
    void exercise2_applyDeadband() {
        assumeTrue(Practice11Controller.CHECK_MY_WORK, "Practice 11" + NOT_YET);
        assertEquals(0.0, Practice11Controller.applyDeadband(0.03, 0.08), CLOSE, "Exercise 2: inside");
        assertEquals(0.0, Practice11Controller.applyDeadband(0.08, 0.08), CLOSE,
                "Exercise 2: exactly on the edge counts as inside");
        assertEquals(0.5, Practice11Controller.applyDeadband(0.54, 0.08), CLOSE,
                "Exercise 2: (0.54 - 0.08) / (1 - 0.08) = 0.5");
        assertEquals(-0.5, Practice11Controller.applyDeadband(-0.54, 0.08), CLOSE,
                "Exercise 2: negative values use (value + deadband)");
        assertEquals(1.0, Practice11Controller.applyDeadband(1.0, 0.08), CLOSE,
                "Exercise 2: full stick still gives 1.0");
    }

    @Test
    void exercise3_curve() {
        assumeTrue(Practice11Controller.CHECK_MY_WORK, "Practice 11" + NOT_YET);
        assertEquals(0.25, Practice11Controller.curve(0.5), CLOSE, "Exercise 3: 0.5 squared");
        assertEquals(-0.25, Practice11Controller.curve(-0.5), CLOSE, "Exercise 3: keep the minus sign");
        assertEquals(1.0, Practice11Controller.curve(1.0), CLOSE, "Exercise 3: full stays full");
    }

    @Test
    void exercise4_stickToSpeed() {
        assumeTrue(Practice11Controller.CHECK_MY_WORK, "Practice 11" + NOT_YET);
        assertEquals(4.0, Practice11Controller.stickToSpeed(-1.0, 4.0, false), CLOSE,
                "Exercise 4: full forward, normal mode");
        assertEquals(1.4, Practice11Controller.stickToSpeed(-1.0, 4.0, true), CLOSE,
                "Exercise 4: full forward, slow mode: 4.0 * 0.35");
        assertEquals(-1.0, Practice11Controller.stickToSpeed(0.54, 4.0, false), CLOSE,
                "Exercise 4: pulled back to 0.54: deadband gives -0.5, curve gives -0.25, * 4.0");
        assertEquals(0.0, Practice11Controller.stickToSpeed(-0.05, 4.0, false), CLOSE,
                "Exercise 4: a resting stick doesn't move the robot");
    }

    @Test
    void challenge_roundDeadband() {
        assumeTrue(Practice11Controller.CHECK_CHALLENGE, "Practice 11" + NO_CHALLENGE);
        assertArrayEquals(new double[] {0.0, 0.0}, Practice11Controller.roundDeadband(0.05, 0.05, 0.08),
                CLOSE, "Challenge: (0.05, 0.05) is about 0.07 from center: inside");
        double[] diagonal = Practice11Controller.roundDeadband(0.3, 0.4, 0.08);
        assertEquals(0.75, diagonal[0] / diagonal[1], CLOSE, "Challenge: the direction must not change: x / y stays 0.3 / 0.4");
        assertEquals((0.5 - 0.08) / 0.92, Math.hypot(diagonal[0], diagonal[1]), CLOSE,
                "Challenge: length 0.5 becomes (0.5 - 0.08) / 0.92");
        double[] corner = Practice11Controller.roundDeadband(1.0, 1.0, 0.08);
        assertEquals(1.0, Math.hypot(corner[0], corner[1]), CLOSE,
                "Challenge: a stick in the corner is longer than 1: Math.min keeps the length at 1.0");
    }
}
