package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for PracticeA5Fusion and PracticeSeedTracker. */
class CheckA5Fusion {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_blend() {
        assumeTrue(PracticeA5Fusion.CHECK_MY_WORK, "Practice A5" + NOT_YET);
        assertEquals(5.10, PracticeA5Fusion.blend(5.00, 5.40, 0.1, 0.3), CLOSE, "Exercise 1: a quarter of 0.40");
        assertEquals(5.20, PracticeA5Fusion.blend(5.00, 5.40, 0.3, 0.3), CLOSE, "Exercise 1: equal trust: halfway");
        assertEquals(4.90, PracticeA5Fusion.blend(5.00, 4.60, 0.1, 0.3), CLOSE,
                "Exercise 1: works when the camera says LESS than odometry too");
    }

    @Test
    void exercise2_cameraStdDev() {
        assumeTrue(PracticeA5Fusion.CHECK_MY_WORK, "Practice A5" + NOT_YET);
        assertEquals(0.8, PracticeA5Fusion.cameraStdDev(1, 2.0), CLOSE, "Exercise 2: 0.5 + 0.15 * 2");
        assertEquals(0.4, PracticeA5Fusion.cameraStdDev(2, 2.0), CLOSE, "Exercise 2: two tags halve it");
        assertEquals(3.0, PracticeA5Fusion.cameraStdDev(1, 30.0), CLOSE, "Exercise 2: never more than 3.0");
        assertEquals(0.25, PracticeA5Fusion.cameraStdDev(3, 0.0), CLOSE, "Exercise 2: 0.5 * 0.5 = 0.25");
    }

    @Test
    void exercise3_rejectReason() {
        assumeTrue(PracticeA5Fusion.CHECK_MY_WORK, "Practice A5" + NOT_YET);
        assertNull(PracticeA5Fusion.rejectReason(true, 2, 0.04, 3.0, 2.0, 0.5), "Exercise 3: a good fix -> null");
        assertEquals("camera not connected", PracticeA5Fusion.rejectReason(false, 0, 9.0, 99, 99, 9),
                "Exercise 3: the FIRST reason wins");
        assertEquals("no tags", PracticeA5Fusion.rejectReason(true, 0, 0.04, 3.0, 2.0, 0.5), "Exercise 3");
        assertEquals("bad timestamp", PracticeA5Fusion.rejectReason(true, 1, 0.6, 3.0, 2.0, 0.5), "Exercise 3: too old");
        assertEquals("bad timestamp", PracticeA5Fusion.rejectReason(true, 1, -0.1, 3.0, 2.0, 0.5), "Exercise 3: future");
        assertEquals("off the field", PracticeA5Fusion.rejectReason(true, 1, 0.04, 18.0, 2.0, 0.5), "Exercise 3: x");
        assertEquals("off the field", PracticeA5Fusion.rejectReason(true, 1, 0.04, 3.0, -0.3, 0.5), "Exercise 3: y");
        assertNull(PracticeA5Fusion.rejectReason(true, 1, 0.04, -0.2, 8.3, 0.5),
                "Exercise 3: just outside the wall but inside the 0.25 m margin is still OK");
        assertEquals("turning too fast", PracticeA5Fusion.rejectReason(true, 1, 0.04, 3.0, 2.0, -4.0),
                "Exercise 3: turning fast the other way counts too");
    }

    @Test
    void challenge_seedTrackerSurvivesTheGapBetweenAutoAndTeleop() {
        assumeTrue(PracticeA5Fusion.CHECK_CHALLENGE, "Practice A5" + NO_CHALLENGE);
        PracticeSeedTracker t = new PracticeSeedTracker();
        assertEquals(false, t.headingTrusted(), "Challenge: at boot nothing is trusted");
        assertEquals(true, t.canAttemptSeed(true), "Challenge: disabled at boot: try a full fix");
        assertEquals(false, t.canAttemptSeed(false), "Challenge: never seed while enabled");
        t.seeded();
        assertEquals(true, t.headingTrusted(), "Challenge: a fix makes the heading trusted");
        assertEquals(false, t.canAttemptSeed(true), "Challenge: no refresh needed right after a fix");
        t.requestRefresh(); // auto ends: the robot is disabled for a few seconds
        assertEquals(true, t.headingTrusted(), "Challenge: disabling must NOT take trust away");
        assertEquals(true, t.canAttemptSeed(true), "Challenge: but a fresh fix is welcome while disabled");
        // teleop starts without a new fix
        assertEquals(true, t.headingTrusted(), "Challenge: vision keeps working in teleop");
        t.forget(); // someone pressed the reset button
        assertEquals(false, t.headingTrusted(), "Challenge: forget() takes trust away");
        assertEquals(true, t.refreshWanted(), "Challenge: and asks for a fresh fix");
    }
}
