package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for Practice09RobotLoop, PracticeBlinker and PracticeRateLimiter. */
class Check09RobotLoop {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_loopsIn() {
        assumeTrue(Practice09RobotLoop.CHECK_MY_WORK, "Practice 9" + NOT_YET);
        assertEquals(50, Practice09RobotLoop.loopsIn(1.0), "Exercise 1: 1 second is 50 loops");
        assertEquals(6750, Practice09RobotLoop.loopsIn(135.0), "Exercise 1: 135 seconds is 6750 loops");
        assertEquals(1000, Practice09RobotLoop.loopsIn(20.0),
                "Exercise 1: 20 seconds is 1000 loops. Got 999? Use Math.round, not just (int)");
    }

    @Test
    void exercise2_blinkerFlipsEvery25Loops() {
        assumeTrue(Practice09RobotLoop.CHECK_MY_WORK, "Practice 9" + NOT_YET);
        PracticeBlinker blinker = new PracticeBlinker();
        for (int i = 1; i <= 24; i++) {
            blinker.periodic();
        }
        assertEquals(false, blinker.isOn(), "Exercise 2: still OFF after 24 loops");
        blinker.periodic();
        assertEquals(true, blinker.isOn(), "Exercise 2: ON after 25 loops");
        for (int i = 1; i <= 25; i++) {
            blinker.periodic();
        }
        assertEquals(false, blinker.isOn(), "Exercise 2: OFF again after 50 loops. Did you reset the count?");
        for (int i = 1; i <= 25; i++) {
            blinker.periodic();
        }
        assertEquals(true, blinker.isOn(), "Exercise 2: ON again after 75 loops");
    }

    @Test
    void challenge_rateLimiter() {
        assumeTrue(Practice09RobotLoop.CHECK_CHALLENGE, "Practice 9" + NO_CHALLENGE);
        PracticeRateLimiter limiter = new PracticeRateLimiter(0.25);
        assertEquals(0.25, limiter.next(1.0), CLOSE, "Challenge: first step toward 1.0");
        assertEquals(0.5, limiter.next(1.0), CLOSE, "Challenge: second step");
        limiter.next(1.0);
        assertEquals(1.0, limiter.next(1.0), CLOSE, "Challenge: reaches 1.0 on the fourth loop");
        assertEquals(1.0, limiter.next(1.0), CLOSE, "Challenge: and stays there, not past it");
        assertEquals(0.75, limiter.next(0.0), CLOSE, "Challenge: going down is limited too");
        assertEquals(0.8, limiter.next(0.8), CLOSE, "Challenge: a target closer than one step is reached exactly");
    }
}
