package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for Practice04Decisions. Boundaries are tested on purpose: that's where bugs live. */
class Check04Decisions {
    @Test
    void exercise2_belowTheFirstLimit() {
        assumeTrue(Practice04Decisions.CHECK_MY_WORK, "Practice 4" + NOT_YET);
        assertEquals("Change the battery", Practice04Decisions.batteryAdvice(11.2),
                "Exercise 2: 11.2 volts is below 11.5");
        assertEquals("Change the battery", Practice04Decisions.batteryAdvice(11.49),
                "Exercise 2: 11.49 volts is still below 11.5");
    }

    @Test
    void exercise2_exactlyOnTheBoundaries() {
        assumeTrue(Practice04Decisions.CHECK_MY_WORK, "Practice 4" + NOT_YET);
        assertEquals("OK for practice", Practice04Decisions.batteryAdvice(11.5),
                "Exercise 2: exactly 11.5 is NOT below 11.5, so it's OK for practice");
        assertEquals("Ready for a match", Practice04Decisions.batteryAdvice(12.3),
                "Exercise 2: exactly 12.3 counts as 12.3 or more");
    }

    @Test
    void exercise2_inTheMiddleAndAbove() {
        assumeTrue(Practice04Decisions.CHECK_MY_WORK, "Practice 4" + NOT_YET);
        assertEquals("OK for practice", Practice04Decisions.batteryAdvice(12.29),
                "Exercise 2: 12.29 is below 12.3");
        assertEquals("Ready for a match", Practice04Decisions.batteryAdvice(12.9),
                "Exercise 2: 12.9 is above 12.3");
    }

    @Test
    void challenge_inAimRange() {
        assumeTrue(Practice04Decisions.CHECK_CHALLENGE, "Practice 4" + NO_CHALLENGE);
        assertEquals(true, Practice04Decisions.inAimRange(true, 2.0), "Challenge: exactly 2.0 m is allowed");
        assertEquals(true, Practice04Decisions.inAimRange(true, 4.5), "Challenge: exactly 4.5 m is allowed");
        assertEquals(true, Practice04Decisions.inAimRange(true, 3.0), "Challenge: 3.0 m is in range");
        assertEquals(false, Practice04Decisions.inAimRange(true, 1.99), "Challenge: 1.99 m is too close");
        assertEquals(false, Practice04Decisions.inAimRange(true, 4.51), "Challenge: 4.51 m is too far");
        assertEquals(false, Practice04Decisions.inAimRange(false, 3.0), "Challenge: disabled means no");
    }
}
