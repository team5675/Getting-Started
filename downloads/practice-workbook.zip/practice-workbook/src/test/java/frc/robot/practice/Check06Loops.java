package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Self-check for Practice06Loops. Read the message of any FAILED check for a hint. */
class Check06Loops {
    @Test
    void exercise1_countdownLines() throws Exception {
        assumeTrue(Practice06Loops.CHECK_MY_WORK, "Practice 6" + NOT_YET);
        List<String> lines = linesPrintedBy(Practice06Loops::main);
        assertTrue(hasLinesInARow(lines, "5", "4", "3", "2", "1", "Go!"),
                "Exercise 1: expected 5, 4, 3, 2, 1 on separate lines, then Go!" + printed(lines));
    }

    @Test
    void exercise2_countdownText() {
        assumeTrue(Practice06Loops.CHECK_MY_WORK, "Practice 6" + NOT_YET);
        assertEquals("3 2 1 Go!", Practice06Loops.countdownText(3), "Exercise 2: from 3");
        assertEquals("5 4 3 2 1 Go!", Practice06Loops.countdownText(5), "Exercise 2: from 5");
        assertEquals("Go!", Practice06Loops.countdownText(0),
                "Exercise 2: from 0 the loop never runs, so only Go! is left");
    }

    @Test
    void exercise3_loopsUntilLow() {
        assumeTrue(Practice06Loops.CHECK_MY_WORK, "Practice 6" + NOT_YET);
        assertEquals(2, Practice06Loops.loopsUntilLow(12.0, 0.5, 11.5),
                "Exercise 3: 12.0 -> 11.5 (not below yet) -> 11.0, so 2 loops");
        assertEquals(9, Practice06Loops.loopsUntilLow(12.8, 0.15, 11.5),
                "Exercise 3: from 12.8 dropping 0.15 it takes 9 loops to get below 11.5");
        assertEquals(0, Practice06Loops.loopsUntilLow(11.0, 0.5, 11.5),
                "Exercise 3: already below the limit, so 0 loops");
    }

    @Test
    void challenge_tickCount() {
        assumeTrue(Practice06Loops.CHECK_CHALLENGE, "Practice 6" + NO_CHALLENGE);
        assertEquals(2, Practice06Loops.tickCount(120), "Challenge: loops 50 and 100");
        assertEquals(1, Practice06Loops.tickCount(50), "Challenge: loop 50 itself counts");
        assertEquals(0, Practice06Loops.tickCount(49), "Challenge: no tick before loop 50");
        assertEquals(10, Practice06Loops.tickCount(500), "Challenge: 500 loops is 10 seconds");
    }
}
