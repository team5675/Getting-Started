package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Transform2d;
import org.junit.jupiter.api.Test;

/** Self-check for PracticeA4Cameras. */
class CheckA4Cameras {
    private static final double CLOSE = 1e-6;

    @Test
    void exercise1_robotFromTag() {
        assumeTrue(PracticeA4Cameras.CHECK_MY_WORK, "Practice A4" + NOT_YET);
        Pose2d tag = new Pose2d(8.0, 4.0, Rotation2d.fromDegrees(180));
        Pose2d robot = PracticeA4Cameras.robotFromTag(tag,
                new Transform2d(3.0, 0.5, Rotation2d.fromDegrees(180)),
                new Transform2d(0.30, 0.0, new Rotation2d()));
        assertEquals(4.70, robot.getX(), CLOSE, "Exercise 1: x should be 8.0 - 3.0 - 0.30");
        assertEquals(3.50, robot.getY(), CLOSE, "Exercise 1: y should be 4.0 - 0.5");
        assertEquals(0.0, robot.getRotation().getDegrees(), CLOSE, "Exercise 1: heading 0");
        // A robot facing the other way, with a camera on its back
        Pose2d tag2 = new Pose2d(1.0, 2.0, new Rotation2d());
        Pose2d robot2 = PracticeA4Cameras.robotFromTag(tag2,
                new Transform2d(2.0, 0.0, Rotation2d.fromDegrees(180)),
                new Transform2d(-0.25, 0.0, Rotation2d.fromDegrees(180)));
        assertEquals(3.25, robot2.getX(), CLOSE,
                "Exercise 1: use transformBy(... .inverse()) twice; a camera on the robot's back works too");
        assertEquals(2.0, robot2.getY(), CLOSE, "Exercise 1: y");
    }

    @Test
    void exercise2_sidewaysError() {
        assumeTrue(PracticeA4Cameras.CHECK_MY_WORK, "Practice A4" + NOT_YET);
        assertEquals(3.0 * Math.sin(Math.toRadians(2.0)), PracticeA4Cameras.sidewaysError(3.0, 2.0), CLOSE,
                "Exercise 2: 3.0 * sin(2 degrees); remember Math.toRadians");
        assertEquals(0.0, PracticeA4Cameras.sidewaysError(5.0, 0.0), CLOSE, "Exercise 2: no angle error");
    }

    @Test
    void challenge_averagePosition() {
        assumeTrue(PracticeA4Cameras.CHECK_CHALLENGE, "Practice A4" + NO_CHALLENGE);
        Pose2d avg = PracticeA4Cameras.averagePosition(new Pose2d[] {
            new Pose2d(4.68, 3.52, Rotation2d.fromDegrees(10)),
            new Pose2d(4.73, 3.49, new Rotation2d()),
            new Pose2d(4.69, 3.49, new Rotation2d())});
        assertEquals(4.70, avg.getX(), CLOSE, "Challenge: average x");
        assertEquals(3.50, avg.getY(), CLOSE, "Challenge: average y");
        assertEquals(10.0, avg.getRotation().getDegrees(), CLOSE, "Challenge: heading from the FIRST estimate");
    }
}
