package frc.robot.practice;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Helpers for the self-checks. You don't need to read or change this file. */
final class PracticeCheck {
    private PracticeCheck() {}

    /** Something with the same shape as a main() method. */
    interface MainMethod {
        void run(String[] args) throws Exception;
    }

    /** Runs a practice program's main() and returns the lines it printed (spaces trimmed). */
    static List<String> linesPrintedBy(MainMethod main) throws Exception {
        PrintStream original = System.out;
        ByteArrayOutputStream captured = new ByteArrayOutputStream();
        System.setOut(new PrintStream(captured, true, StandardCharsets.UTF_8));
        try {
            main.run(new String[0]);
        } finally {
            System.setOut(original);
        }
        List<String> lines = new ArrayList<>();
        for (String line : captured.toString(StandardCharsets.UTF_8).split("\\R")) {
            lines.add(line.strip());
        }
        return lines;
    }

    /** True if the expected lines appear one right after another somewhere in the output. */
    static boolean hasLinesInARow(List<String> lines, String... expected) {
        for (int start = 0; start + expected.length <= lines.size(); start++) {
            boolean allMatch = true;
            for (int i = 0; i < expected.length; i++) {
                if (!lines.get(start + i).equals(expected[i])) {
                    allMatch = false;
                    break;
                }
            }
            if (allMatch) {
                return true;
            }
        }
        return false;
    }

    /** A message that shows what the program actually printed, to help find the difference. */
    static String printed(List<String> lines) {
        return "\nYour program printed:\n  " + String.join("\n  ", lines);
    }

    static final String NOT_YET =
            " is not being checked yet. Set CHECK_MY_WORK = true in that file when you're ready.";
    static final String NO_CHALLENGE =
            " challenge is not being checked. Set CHECK_CHALLENGE = true in that file to check it.";
}
