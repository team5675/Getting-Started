package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for PracticeA8CameraCheck. */
class CheckA8CameraCheck {
    private static final double[] READINGS = {2.031, 2.027, 2.035, 2.029, 2.033, 2.030, 2.028, 2.034, 2.032, 2.031};

    @Test
    void exercise1_bias() {
        assumeTrue(PracticeA8CameraCheck.CHECK_MY_WORK, "Practice A8" + NOT_YET);
        assertEquals(0.031, PracticeA8CameraCheck.bias(READINGS, 2.000), 1e-9, "Exercise 1: average 2.031 - 2.000");
        assertEquals(-0.5, PracticeA8CameraCheck.bias(new double[] {1.0, 2.0}, 2.0), 1e-9,
                "Exercise 1: bias can be negative");
    }

    @Test
    void exercise2_scatter() {
        assumeTrue(PracticeA8CameraCheck.CHECK_MY_WORK, "Practice A8" + NOT_YET);
        assertEquals(Math.sqrt(0.000060 / 9), PracticeA8CameraCheck.scatter(READINGS), 1e-9,
                "Exercise 2: the squared distances add up to 0.000060; divide by 9 (count - 1)");
        assertEquals(0.0, PracticeA8CameraCheck.scatter(new double[] {3.0, 3.0, 3.0}), 1e-12,
                "Exercise 2: identical readings have no scatter");
    }

    @Test
    void exercise3_verdict() {
        assumeTrue(PracticeA8CameraCheck.CHECK_MY_WORK, "Practice A8" + NOT_YET);
        assertEquals("PASS", PracticeA8CameraCheck.verdict(0.031, 0.010, 0.050), "Exercise 3: 0.041 <= 0.050");
        assertEquals("INCONCLUSIVE", PracticeA8CameraCheck.verdict(0.031, 0.025, 0.050),
                "Exercise 3: could be 0.006 or 0.056");
        assertEquals("FAIL", PracticeA8CameraCheck.verdict(0.090, 0.010, 0.050), "Exercise 3: even 0.080 is too far");
        assertEquals("FAIL", PracticeA8CameraCheck.verdict(-0.090, 0.010, 0.050), "Exercise 3: use the SIZE of the bias");
    }

    @Test
    void challenge_headingUncertainty() {
        assumeTrue(PracticeA8CameraCheck.CHECK_CHALLENGE, "Practice A8" + NO_CHALLENGE);
        assertEquals(Math.toDegrees(Math.atan(5.0 / 750.0)), PracticeA8CameraCheck.headingUncertaintyDegrees(750, 5),
                1e-9, "Challenge: atan(5 / 750) in degrees");
        assertEquals(Math.toDegrees(Math.atan(5.0 / 375.0)), PracticeA8CameraCheck.headingUncertaintyDegrees(375, 5),
                1e-9, "Challenge: closer contacts -> twice the uncertainty");
    }
}
