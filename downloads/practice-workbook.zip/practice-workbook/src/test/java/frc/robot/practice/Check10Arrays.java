package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for Practice10Arrays. */
class Check10Arrays {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_average() {
        assumeTrue(Practice10Arrays.CHECK_MY_WORK, "Practice 10" + NOT_YET);
        assertEquals(12.25, Practice10Arrays.average(new double[] {12.6, 12.4, 12.1, 11.9}), CLOSE,
                "Exercise 1: (12.6 + 12.4 + 12.1 + 11.9) / 4");
        assertEquals(5.0, Practice10Arrays.average(new double[] {5.0}), CLOSE,
                "Exercise 1: the average of one value is that value");
    }

    @Test
    void exercise2_maxAbs() {
        assumeTrue(Practice10Arrays.CHECK_MY_WORK, "Practice 10" + NOT_YET);
        assertEquals(2.6, Practice10Arrays.maxAbs(new double[] {2.1, -2.4, 1.9, 2.6}), CLOSE,
                "Exercise 2: 2.6 is the biggest size");
        assertEquals(3.0, Practice10Arrays.maxAbs(new double[] {1.0, -3.0, 2.0}), CLOSE,
                "Exercise 2: -3.0 counts as size 3.0");
    }

    @Test
    void exercise3_desaturate() {
        assumeTrue(Practice10Arrays.CHECK_MY_WORK, "Practice 10" + NOT_YET);
        double[] speeds = {2.0, -4.0, 1.0, 3.0};
        double[] result = Practice10Arrays.desaturate(speeds, 2.0);
        assertArrayEquals(new double[] {1.0, -2.0, 0.5, 1.5}, result, CLOSE,
                "Exercise 3: the fastest is 4.0, so every wheel is multiplied by 2.0 / 4.0 = 0.5");
        assertArrayEquals(new double[] {2.0, -4.0, 1.0, 3.0}, speeds, CLOSE,
                "Exercise 3: don't change the array you were given; return a new one");
        double[] slow = {1.0, 0.5, -1.5, 0.0};
        double[] same = Practice10Arrays.desaturate(slow, 2.0);
        assertArrayEquals(slow, same, CLOSE, "Exercise 3: nothing is too fast, so nothing changes");
        assertNotSame(slow, same, "Exercise 3: still return a NEW array, even when nothing changes");
    }

    @Test
    void challenge_indexOfLowest() {
        assumeTrue(Practice10Arrays.CHECK_CHALLENGE, "Practice 10" + NO_CHALLENGE);
        assertEquals(3, Practice10Arrays.indexOfLowest(new double[] {12.6, 12.4, 12.1, 11.9}), "Challenge: last one");
        assertEquals(0, Practice10Arrays.indexOfLowest(new double[] {1.0, 2.0, 3.0}), "Challenge: first one");
        assertEquals(1, Practice10Arrays.indexOfLowest(new double[] {5.0, 2.0, 2.0}), "Challenge: a tie: the first");
    }
}
