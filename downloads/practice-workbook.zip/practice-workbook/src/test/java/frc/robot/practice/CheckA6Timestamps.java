package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for PracticeA6Timestamps and PracticeStreamClock. */
class CheckA6Timestamps {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_pictureTime() {
        assumeTrue(PracticeA6Timestamps.CHECK_MY_WORK, "Practice A6" + NOT_YET);
        assertEquals(12.310678, PracticeA6Timestamps.pictureTimeSeconds(12_345_678L, 35.0), CLOSE,
                "Exercise 1: divide microseconds by 1,000,000 and ms by 1,000, then subtract");
        assertEquals(1.0, PracticeA6Timestamps.pictureTimeSeconds(1_000_000L, 0.0), CLOSE,
                "Exercise 1: 1,000,000 microseconds is 1 second. Got 0? Divide by 1_000_000.0, not by an int");
    }

    @Test
    void exercise2_ageProblem() {
        assumeTrue(PracticeA6Timestamps.CHECK_MY_WORK, "Practice A6" + NOT_YET);
        assertNull(PracticeA6Timestamps.ageProblem(0.05), "Exercise 2: 50 ms old is fine");
        assertNull(PracticeA6Timestamps.ageProblem(0.5), "Exercise 2: exactly 0.5 s is still allowed");
        assertNull(PracticeA6Timestamps.ageProblem(-0.04), "Exercise 2: a tiny negative is clock jitter");
        assertEquals("picture time is in the future", PracticeA6Timestamps.ageProblem(-0.06), "Exercise 2");
        assertEquals("picture is too old", PracticeA6Timestamps.ageProblem(0.51), "Exercise 2");
        assertEquals("picture time is in the future", PracticeA6Timestamps.ageProblem(-12_345_665.6),
                "Exercise 2: wrong units make a huge number");
    }

    @Test
    void exercise3_distanceDuringLatency() {
        assumeTrue(PracticeA6Timestamps.CHECK_MY_WORK, "Practice A6" + NOT_YET);
        assertEquals(15.0, PracticeA6Timestamps.distanceDuringLatencyCm(3.0, 0.050), 1e-6,
                "Exercise 3: 3 m/s * 0.05 s = 0.15 m = 15 cm");
        assertEquals(2.0, PracticeA6Timestamps.distanceDuringLatencyCm(1.0, 0.020), 1e-6, "Exercise 3");
    }

    @Test
    void challenge_oneStreamCannotHideTheOther() {
        assumeTrue(PracticeA6Timestamps.CHECK_CHALLENGE, "Practice A6" + NO_CHALLENGE);
        PracticeStreamClock clock = new PracticeStreamClock();
        assertNull(clock.problem(), "Challenge: no packets yet: no problem");
        clock.newPacket(1, -1000.0); // MegaTag1 arrives with an impossible time
        assertEquals("MegaTag1: picture time is in the future", clock.problem(), "Challenge: name the stream");
        clock.newPacket(2, 0.03); // only MegaTag2 updates, and it's fine
        assertNotNull(clock.problem(), "Challenge: a good MegaTag2 packet must not hide the MegaTag1 problem");
        clock.newPacket(1, 0.03); // MegaTag1 recovers
        assertNull(clock.problem(), "Challenge: both fine again");
        clock.newPacket(2, 0.9);
        assertEquals("MegaTag2: picture is too old", clock.problem(), "Challenge: MegaTag2 problems count too");
    }
}
