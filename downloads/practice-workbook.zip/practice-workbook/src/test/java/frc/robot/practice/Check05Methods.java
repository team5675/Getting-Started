package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/**
 * Self-check for Practice05Methods. Decimal answers are compared "within 0.000001", because
 * computers store most decimals as very close approximations.
 */
class Check05Methods {
    private static final double CLOSE = 1e-6;

    @Test
    void exercise1_metersToCentimeters() {
        assumeTrue(Practice05Methods.CHECK_MY_WORK, "Practice 5" + NOT_YET);
        assertEquals(254.0, Practice05Methods.metersToCentimeters(2.54), CLOSE,
                "Exercise 1: 2.54 meters is 254 centimeters");
        assertEquals(50.0, Practice05Methods.metersToCentimeters(0.5), CLOSE,
                "Exercise 1: 0.5 meters is 50 centimeters");
    }

    @Test
    void exercise2_clamp() {
        assumeTrue(Practice05Methods.CHECK_MY_WORK, "Practice 5" + NOT_YET);
        assertEquals(1.0, Practice05Methods.clamp(1.4, -1.0, 1.0), CLOSE,
                "Exercise 2: 1.4 is above max, so return max");
        assertEquals(-1.0, Practice05Methods.clamp(-2.0, -1.0, 1.0), CLOSE,
                "Exercise 2: -2.0 is below min, so return min");
        assertEquals(-0.3, Practice05Methods.clamp(-0.3, -1.0, 1.0), CLOSE,
                "Exercise 2: -0.3 is inside the range, so return it unchanged");
        assertEquals(5.0, Practice05Methods.clamp(5.0, 0.0, 5.0), CLOSE,
                "Exercise 2: exactly max is inside the range");
    }

    @Test
    void exercise3_outputToVolts() {
        assumeTrue(Practice05Methods.CHECK_MY_WORK, "Practice 5" + NOT_YET);
        assertEquals(3.0, Practice05Methods.outputToVolts(0.25), CLOSE,
                "Exercise 3: 0.25 of 12 volts is 3 volts");
        assertEquals(12.0, Practice05Methods.outputToVolts(1.5), CLOSE,
                "Exercise 3: clamp 1.5 to 1.0 first, so the answer is 12 volts, not 18");
        assertEquals(-12.0, Practice05Methods.outputToVolts(-3.0), CLOSE,
                "Exercise 3: clamp -3.0 to -1.0 first");
    }

    @Test
    void challenge_distanceBetween() {
        assumeTrue(Practice05Methods.CHECK_CHALLENGE, "Practice 5" + NO_CHALLENGE);
        assertEquals(5.0, Practice05Methods.distanceBetween(0, 0, 3, 4), CLOSE,
                "Challenge: (0,0) to (3,4) is 5 (a 3-4-5 triangle)");
        assertEquals(5.0, Practice05Methods.distanceBetween(4, 6, 1, 2), CLOSE,
                "Challenge: (4,6) to (1,2) is also 5: dx = -3, dy = -4");
    }

    @Test
    void challenge_applyDeadband() {
        assumeTrue(Practice05Methods.CHECK_CHALLENGE, "Practice 5" + NO_CHALLENGE);
        assertEquals(0.0, Practice05Methods.applyDeadband(0.05, 0.1), CLOSE, "Challenge: 0.05 is inside");
        assertEquals(0.0, Practice05Methods.applyDeadband(-0.05, 0.1), CLOSE,
                "Challenge: -0.05 is inside too: use Math.abs");
        assertEquals(0.5, Practice05Methods.applyDeadband(0.5, 0.1), CLOSE, "Challenge: 0.5 passes through");
        assertEquals(-0.5, Practice05Methods.applyDeadband(-0.5, 0.1), CLOSE,
                "Challenge: -0.5 passes through unchanged");
    }
}
