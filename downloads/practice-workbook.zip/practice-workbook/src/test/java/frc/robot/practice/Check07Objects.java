package frc.robot.practice;

import static frc.robot.practice.PracticeCheck.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Test;

/** Self-check for PracticeBattery and Practice07Objects. */
class Check07Objects {
    private static final double CLOSE = 1e-9;

    @Test
    void exercise1_recordKeepsTheLowestAndCounts() {
        assumeTrue(Practice07Objects.CHECK_MY_WORK, "Practice 7" + NOT_YET);
        PracticeBattery battery = new PracticeBattery("Test", 12.8);
        battery.record(12.4);
        assertEquals(12.4, battery.getLowestVolts(), CLOSE, "Exercise 1: 12.4 is lower than 12.8");
        battery.record(12.6);
        assertEquals(12.4, battery.getLowestVolts(), CLOSE,
                "Exercise 1: 12.6 is HIGHER than 12.4, so the lowest stays 12.4");
        assertEquals(3, battery.getReadingCount(),
                "Exercise 1: one reading from the constructor plus two record() calls is 3");
    }

    @Test
    void exercise1_twoObjectsKeepSeparateRecords() {
        assumeTrue(Practice07Objects.CHECK_MY_WORK, "Practice 7" + NOT_YET);
        PracticeBattery a = new PracticeBattery("A", 12.8);
        PracticeBattery b = new PracticeBattery("B", 12.6);
        a.record(11.3);
        assertEquals(11.3, a.getLowestVolts(), CLOSE, "Exercise 1: A recorded 11.3");
        assertEquals(12.6, b.getLowestVolts(), CLOSE,
                "Exercise 1: B never saw 11.3. Did you use a field that ALL batteries share?");
        assertEquals(1, b.getReadingCount(), "Exercise 1: B has only its first reading");
    }

    @Test
    void exercise2_droppedTooLow() {
        assumeTrue(Practice07Objects.CHECK_MY_WORK, "Practice 7" + NOT_YET);
        PracticeBattery battery = new PracticeBattery("Test", 12.0);
        assertEquals(false, battery.droppedTooLow(), "Exercise 2: 12.0 is not below 11.5");
        battery.record(11.5);
        assertEquals(false, battery.droppedTooLow(), "Exercise 2: exactly 11.5 is not below 11.5");
        battery.record(11.4);
        assertEquals(true, battery.droppedTooLow(), "Exercise 2: 11.4 is below 11.5");
        battery.record(12.5);
        assertEquals(true, battery.droppedTooLow(),
                "Exercise 2: it DID drop too low earlier, even though the latest reading is fine");
    }

    @Test
    void challenge_startNewMatch() {
        assumeTrue(Practice07Objects.CHECK_CHALLENGE, "Practice 7" + NO_CHALLENGE);
        PracticeBattery battery = new PracticeBattery("Test", 12.8);
        battery.record(11.0);
        battery.startNewMatch(12.7);
        assertEquals(12.7, battery.getLowestVolts(), CLOSE, "Challenge: the new match starts at 12.7");
        assertEquals(1, battery.getReadingCount(), "Challenge: the count starts over at 1");
        assertEquals("Test", battery.getLabel(), "Challenge: keep the label");
        assertEquals(false, battery.droppedTooLow(), "Challenge: the old 11.0 is forgotten");
    }
}
