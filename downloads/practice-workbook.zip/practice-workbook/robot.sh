#!/bin/sh
# ===========================================================================
#  robot.sh  -  build, simulate or test this project with WPILib 2026's Java
#               (the macOS and Linux twin of robot.cmd)
#
#    ./robot.sh                                   start the simulation
#    ./robot.sh build                             compile and run the reference test
#    ./robot.sh test -PcheckStudent --rerun-tasks check your own labs (after Lab 6)
#    ./robot.sh lab8                              add Lesson 8's starter files to src
#    ./robot.sh lab7                              add Lab 7's starter files to src
#    ./robot.sh motors1                           add Motor lab 1's starter files to src
#    ./robot.sh motors2                           add Motor lab 2's check to src
#    ./robot.sh talonfx                           add Motor lab 3's files, and Phoenix 6
#                                                 to vendordeps
#
#  These five copy only files that src (or vendordeps) does not have yet, so
#  they never replace your own edits. Anything else after "robot.sh" is passed
#  straight to Gradle, so
#  ./robot.sh test --tests "frc.robot.LightCommandTest" works too.
#
#  To stop the simulation: click in the Terminal and press Ctrl+C.
#  "Permission denied"? Type  chmod +x robot.sh  once, or use  sh robot.sh
#
#  On macOS and Linux, WPILib 2026 installs into ~/wpilib/2026 (the wpilib
#  folder in your home folder). Mentors: if your 2026 JDK is somewhere else,
#  set WPILIB_2026_JDK to that jdk folder first.
# ===========================================================================

# The folder this file is in, so it works from any folder.
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

# ---- 0. "./robot.sh lab8", "lab7", "motors1"...: add a lab's starter files -
LAB=
VENDOR=
case $1 in
  [Ll][Aa][Bb]8) LAB=command-lab; LESSON="Lesson 8" ;;
  [Ll][Aa][Bb]7) LAB=mechanism-lab; LESSON="Lab 7" ;;
  [Mm][Oo][Tt][Oo][Rr][Ss]1) LAB=motor-lab-1; LESSON="Motor lab 1" ;;
  [Mm][Oo][Tt][Oo][Rr][Ss]2) LAB=motor-lab-2; LESSON="Motor lab 2" ;;
  [Tt][Aa][Ll][Oo][Nn][Ff][Xx]) LAB=talonfx-lab; LESSON="Motor lab 3"; VENDOR=1 ;;
esac

# Copy each file under folder $1 to the same place under folder $2, but only
# when $2 does not have that file yet (like robocopy /XC /XN /XO). Prints each
# copied file with prefix $3 and sets COPIED=1. Returns 1 if a copy failed.
copy_new() {
  [ -d "$1" ] || return 1
  FILES=$(cd "$1" && find . -type f | sort) || return 1
  set -f
  OLD_IFS=$IFS
  IFS='
'
  for REL in $FILES; do
    REL=${REL#./}
    TARGET=$2/$REL
    if [ ! -e "$TARGET" ]; then
      if ! { mkdir -p "${TARGET%/*}" && cp "$1/$REL" "$TARGET"; }; then
        IFS=$OLD_IFS
        set +f
        return 1
      fi
      echo "  $3$REL"
      COPIED=1
    fi
  done
  IFS=$OLD_IFS
  set +f
  return 0
}

if [ -n "$LAB" ]; then
  FROM=$HERE/$LAB/starter/src
  if [ ! -d "$FROM" ]; then
    echo "This folder has no $LAB/starter/src."
    echo "Extract the whole sim-starter ZIP again, or ask a mentor."
    exit 1
  fi
  echo "Adding the $LESSON starter files to src. Files you already have are kept."
  COPIED=0
  if ! copy_new "$FROM" "$HERE/src" src/; then
    echo "Copying the $LESSON files failed. Nothing you edited was replaced. Ask a mentor."
    exit 1
  fi
  if [ -n "$VENDOR" ]; then
    # Motor lab 3 also adds one library description file (Phoenix 6) to vendordeps.
    echo "Adding the Phoenix 6 library file to vendordeps. Your next build downloads Phoenix 6 once."
    if ! copy_new "$HERE/$LAB/starter/vendordeps" "$HERE/vendordeps" vendordeps/; then
      echo "Copying the $LESSON files failed. Nothing you edited was replaced. Ask a mentor."
      exit 1
    fi
    if [ "$COPIED" = 1 ]; then
      echo "Done. The files listed above are now in src and vendordeps."
    else
      echo "Nothing new to add: these files are already in src and vendordeps. Your edits were kept."
    fi
    exit 0
  fi
  if [ "$COPIED" = 1 ]; then
    echo "Done. The files listed above are now in src."
  else
    echo "Nothing new to add: these files are already in src. Your edits were kept."
  fi
  exit 0
fi

# ---- 1. Find the WPILib 2026 Java (same rule the WPILib installer uses) ----
if [ -n "$WPILIB_2026_JDK" ]; then
  JDK=$WPILIB_2026_JDK
elif [ -n "$PUBLIC" ]; then
  JDK=$PUBLIC/wpilib/2026/jdk
else
  JDK=$HOME/wpilib/2026/jdk
fi
if [ ! -x "$JDK/bin/java" ]; then
  echo "Could not find the Java that WPILib 2026 installs."
  echo "Looked for: $JDK/bin/java"
  echo "Install WPILib 2026 (Lesson 1, step 1) or ask a mentor for help."
  exit 2
fi
if ! "$JDK/bin/java" -version 2>&1 | grep 'version "17\.' >/dev/null; then
  echo "The Java found at $JDK is not Java 17."
  echo "This project needs the Java 17 that comes with WPILib 2026. Ask a mentor."
  exit 2
fi

# ---- 2. Gradle reads JAVA_HOME. Run from this project's own folder. -------
JAVA_HOME=$JDK
export JAVA_HOME
cd "$HERE" || exit 2
if [ ! -f gradlew ]; then
  echo "gradlew is missing from $HERE"
  echo "Extract the whole sim-starter ZIP again, then try once more."
  exit 2
fi
# "sh gradlew" works even if the ZIP tool dropped gradlew's run permission.
if [ $# -eq 0 ]; then
  sh ./gradlew simulateJava
else
  sh ./gradlew "$@"
fi
exit $?
