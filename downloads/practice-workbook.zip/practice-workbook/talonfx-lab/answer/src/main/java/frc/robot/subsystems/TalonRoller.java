package frc.robot.subsystems;

import java.util.function.BooleanSupplier;
import com.ctre.phoenix6.configs.TalonFXConfiguration;
import com.ctre.phoenix6.controls.NeutralOut;
import com.ctre.phoenix6.controls.VelocityVoltage;
import com.ctre.phoenix6.hardware.TalonFX;
import com.ctre.phoenix6.signals.NeutralModeValue;
import com.ctre.phoenix6.sim.TalonFXSimState;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.sim.RollerPhysics;
import org.littletonrobotics.junction.Logger;

/** Motor lab 3: the same roller, now driven by a simulated TalonFX motor controller.
 * The TalonFX does the feedforward and feedback math from Motor lab 2 itself, about
 * 1000 times a second, using the numbers you give it in Slot0.
 * Fictional teaching numbers and CAN ID. Never copy them to a robot.
 */
public class TalonRoller extends SubsystemBase {
    /** A pretend CAN ID. On a robot, each device's ID is set with Phoenix Tuner X. */
    public static final int CAN_ID = 10;
    /** The most current the motor may draw. Team motors always have a limit. */
    public static final double CURRENT_LIMIT_AMPS = 60.0;

    private final TalonFX motor = new TalonFX(CAN_ID);
    private final VelocityVoltage speedRequest = new VelocityVoltage(0).withSlot(0);
    private final NeutralOut stopRequest = new NeutralOut();
    private final RollerPhysics physics = new RollerPhysics();
    private final BooleanSupplier objectPresent;
    private double targetRps;

    public TalonRoller(BooleanSupplier objectPresent) {
        this.objectPresent = objectPresent;
        TalonFXConfiguration config = new TalonFXConfiguration();
        // Report roller rotations, not motor rotations: the motor turns 3 times per roller turn.
        config.Feedback.SensorToMechanismRatio = RollerPhysics.GEARING;
        // MOTOR LAB 3 TODO 2: give Slot0 the three numbers from Motor labs 1 and 2.
        config.Slot0.kS = MotorRoller.KS_VOLTS;
        config.Slot0.kV = MotorRoller.KV_VOLTS_PER_RPS;
        config.Slot0.kP = MotorRoller.KP_VOLTS_PER_RPS;
        // MOTOR LAB 3 TODO 3: turn on a stator current limit of CURRENT_LIMIT_AMPS.
        config.CurrentLimits.StatorCurrentLimit = CURRENT_LIMIT_AMPS;
        config.CurrentLimits.StatorCurrentLimitEnable = true;
        // Coast lets the roller spin down freely when stopped; Brake stops it fast.
        // This simulation does not model the difference, but a robot does.
        config.MotorOutput.NeutralMode = NeutralModeValue.Coast;
        // A configuration message can be lost, so try a few times, as CTRE's own examples do.
        for (int attempt = 0; attempt < 5; attempt++) {
            if (motor.getConfigurator().apply(config).isOK()) {
                break;
            }
        }
    }

    /** Hold targetRps while the command runs; let the motor go neutral when it ends. */
    public Command runAtSpeed(double targetRps) {
        // MOTOR LAB 3 TODO 1: every loop, send speedRequest.withVelocity(targetRps);
        // when it ends, send stopRequest.
        return runEnd(() -> {
            this.targetRps = targetRps;
            motor.setControl(speedRequest.withVelocity(targetRps));
        }, () -> {
            this.targetRps = 0.0;
            motor.setControl(stopRequest);
        }).withName("TalonFX hold " + targetRps + " rps");
    }

    /** Roller speed, as the TalonFX measures it. */
    public double getSpeedRps() { return motor.getVelocity().getValueAsDouble(); }
    /** Current in the motor's windings, as the TalonFX measures it. */
    public double getStatorCurrentAmps() { return motor.getStatorCurrent().getValueAsDouble(); }
    /** Volts the TalonFX is sending to the motor. */
    public double getMotorVolts() { return motor.getMotorVoltage().getValueAsDouble(); }

    /** SUPPLIED: record the evidence. */
    @Override public void periodic() {
        Logger.recordOutput("Training/Talon/TargetRps", targetRps);
        Logger.recordOutput("Training/Talon/SpeedRps", getSpeedRps());
        Logger.recordOutput("Training/Talon/MotorVolts", getMotorVolts());
        Logger.recordOutput("Training/Talon/StatorCurrentAmps", getStatorCurrentAmps());
        Logger.recordOutput("Training/Talon/ObjectPresent", objectPresent.getAsBoolean());
    }

    /** SUPPLIED: in simulation only, connect the pretend TalonFX to the pretend world.
     * The TalonFX tells us its motor volts; the physics answers with the new rotor
     * position and speed. Rotor values are motor turns, so multiply by the gearing.
     */
    @Override public void simulationPeriodic() {
        TalonFXSimState sim = motor.getSimState();
        sim.setSupplyVoltage(12.0);
        physics.update(sim.getMotorVoltage(), objectPresent.getAsBoolean(), RollerPhysics.LOOP_SECONDS);
        sim.setRawRotorPosition(physics.rotations() * RollerPhysics.GEARING);
        sim.setRotorVelocity(physics.trueSpeedRps() * RollerPhysics.GEARING);
    }
}
