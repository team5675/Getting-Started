package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.sim.RollerPhysics;
import frc.robot.subsystems.TalonRoller;

/** Motor lab 3 checks: the simulated TalonFX holds 20 rps with YOUR Slot0 numbers and keeps
 * its current under the limit. CTRE's simulated TalonFX runs on the real clock, not the
 * stepped clock of Motor labs 1 and 2, so this check takes about four seconds and allows
 * a little more tolerance.
 */
public class TalonLabTest {
    private static final TrainingInput TELEOP = new TrainingInput("teleop", 0, 0, 0, false, false, false, 0, false);
    private static final double TARGET = 20.0;

    private void run(double seconds) {
        for (int i = 0; i < (int) Math.round(seconds / RollerPhysics.LOOP_SECONDS); i++) {
            CommandScheduler.getInstance().run();
            Timer.delay(RollerPhysics.LOOP_SECONDS);
        }
    }

    @Test void sameRollerOnATalonFX() {
        HAL.initialize(500, 0); DriverStationSim.resetData();
        CommandScheduler scheduler = CommandScheduler.getInstance();
        scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
        SimControls.publish(TELEOP);
        AtomicBoolean object = new AtomicBoolean(false);
        TalonRoller roller = new TalonRoller(object::get);
        try {
            Timer.delay(0.1); // CTRE's advice: let the simulated TalonFX start and see "enabled"

            // TODO 1: runAtSpeed sends the velocity request every loop.
            Command hold = roller.runAtSpeed(TARGET);
            assertTrue(hold.getRequirements().contains(roller), "runAtSpeed must require the roller (use runEnd from the subsystem)");
            scheduler.schedule(hold);
            double peakAmps = 0;
            for (int loop = 0; loop < 100; loop++) {         // about 2 seconds
                run(RollerPhysics.LOOP_SECONDS);
                peakAmps = Math.max(peakAmps, Math.abs(roller.getStatorCurrentAmps()));
            }
            assertTrue(hold.isScheduled(), "runAtSpeed should keep running until it is released");

            // TODO 2: Slot0 holds your kS, kV and kP.
            assertEquals(TARGET, roller.getSpeedRps(), 1.0, String.format(
                    "After 2 s the TalonFX should hold about %.0f rps. Give Slot0 your kS, kV and kP.", TARGET));

            // TODO 3: the current limit keeps the start-up surge down.
            assertTrue(peakAmps <= TalonRoller.CURRENT_LIMIT_AMPS + 10, String.format(
                    "The motor drew %.0f A while speeding up. Turn on the stator current limit of %.0f A.",
                    peakAmps, TalonRoller.CURRENT_LIMIT_AMPS));

            // The load arrives: the TalonFX's own feedback answers it.
            object.set(true); run(1.0);
            assertEquals(TARGET, roller.getSpeedRps(), 1.5, String.format(
                    "One second after the load arrives, the speed should be back within 1.5 rps of %.0f. "
                    + "Slot0 needs your kP.", TARGET));
            hold.cancel(); run(0.2);
            assertEquals(0.0, roller.getMotorVolts(), 0.05, "When runAtSpeed ends, the TalonFX should send 0 V (NeutralOut)");
        } finally {
            scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
            SimControls.publish(TrainingInput.disabled());
        }
    }
}
