Use the matching motor-lab-3.html (Motor lab 3) on the course website.
Finish Motor labs 1 and 2 first: TalonRoller uses your KS, KV and KP from MotorRoller.java.
Add the files to your project: in the Terminal, type  .\robot talonfx
It copies starter/src files to the same paths under src, and the Phoenix 6 library
file (Phoenix6-frc2026-latest.json, CTRE's version 26.3.0) into vendordeps. It never
replaces a file you already have. Your next build downloads Phoenix 6 once, so be online.
Complete TODOs before consulting answer. The test file checks your edited class.
To go back to the project you had before this lab, use the backup you made first.
Without one, do all three: delete vendordeps/Phoenix6-frc2026-latest.json,
src/main/java/frc/robot/subsystems/TalonRoller.java and src/test/java/frc/robot/TalonLabTest.java;
delete the three TalonRoller lines you added to StudentProgram.java; and remove the //
in front of your Motor lab 2 B line. Deleting only the files leaves StudentProgram
using TalonRoller, and the build stops with "cannot find symbol".
If a mentor says this computer should not get CTRE's files, skip this lab.
