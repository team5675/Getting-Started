Team 5675 - First PathPlanner Lab, 13 October 2026
Use GUI 2026.1.2. Open starter (the folder containing deploy), not deploy itself.
No build.gradle: this is a standalone GUI folder, not deployable robot code.
All robot parameters are fictional preview settings; do not copy to hardware.
Task: extend FirstLine end from (1.5,1) to (2,1), set previous control to (1.67,1),
and both starting/ending rotation to 90 degrees. Keep speed/acceleration 0.5,
starting/ending speed 0, Reset Odometry true. Add wait 1 second after the path
in FirstAuto. Preview, inspect the saved files, then compare with answers.
Keep Hot Reload off. No robot connection is required. No 2027 game is implied.
Guide: https://team5675.github.io/Getting-Started/pathplanner-first-path.html
JSON structure/reference checks passed; native GUI open/save/play still needs
mentor acceptance. An editor preview is not robot-code or hardware validation.
