# WiredCats simulation starter

A laptop-only practice project for the Getting Started course. Finish Java Lessons
1-7 first, then follow `robot-project.html`, Lesson 8 and `sim-lab.html` on the
course website. Start with the working timed light; add one connection per lab.

## Set up on Windows 11 (the tested course route)

1. Install the class-approved WPILib 2026.2.1 tools with Java 17 and VS Code.
2. Extract this folder outside OneDrive, for example `C:\dev\sim-starter`.
3. Open the folder containing `build.gradle` in WPILib VS Code 2026.
4. Open a PowerShell terminal there. Select your installed Java 17 folder:

```powershell
$env:JAVA_HOME = 'C:\Users\Public\wpilib\2026\jdk'
& "$env:JAVA_HOME\bin\java.exe" -version
.\gradlew.bat build
.\gradlew.bat simulateJava
```

Adjust that example JAVA_HOME if you installed for the current user. The first
build downloads pinned dependencies. Wait for `WiredCats training ready`, then
open http://127.0.0.1:8767/ in a browser on this computer. Start Disabled.
Select Timed light, then Autonomous: the indicator turns on for two seconds.
Disable also ends it early. Stop Java with Ctrl+C in its Terminal before editing
or opening a completed log. Save, then restart to load code changes.

The project has no hardware deployment target. It rejects real hardware. The
model integrates velocities directly; it does not model wheel physics or cameras.
Keep this stable-2026 project separate from the SystemCore alpha bench. Never
use the 2027 importer on it. Anticipated migration points use SYSTEMCORE-2027.

## Controls follow your screen

Choose Teleop, then click the keyboard area. Lab 2 enables driving.

| Key | Visible movement / action |
| --- | --- |
| W | Up, +Y |
| S | Down, -Y |
| A | Left, -X |
| D | Right, +X |
| Q / E | Turn counterclockwise / clockwise |
| Space | Hold the indicator on, after Lab 1 |
| Shift | Slow mode, 0.35 times normal speed |
| H | Pause/resume the simulated sensor heartbeat |
| R | Reset pose, only while Disabled |
| Escape | Disable and release all input |

Turning the robot does not rotate these controls. The grid's fixed field frame
has +X right, +Y up and heading zero right. This is a teaching grid, not the 2027
field or a driver-station perspective. On-screen buttons can also be held with
a pointer, or by focusing a button and holding Enter/Space. Switching windows
or hiding the page disables the model. A stale control connection also disables
it; choose a mode again after reconnecting. Do not run another Driver Station.

## Six cumulative labs

Edit `src/main/java/frc/robot/StudentProgram.java` in place:

1. Bind a standard driver.a() Trigger to a command and observe release/interruption cleanup.
2. Add the drive default command; compare normal, slow and diagonal motion.
3. Record input, pose and requested speed with AdvantageKit; inspect your log.
4. Configure PathPlanner and follow TrainingLine from (1,1) to (2,1).
5. Register a deferred named command; add a Checkpoint event marker halfway.
6. Detect heartbeat data older than 0.50 seconds; inhibit drive and recover.

Use the matching course section for the explanation, boundary check and real
robot connection. `checkpoints/01` is the start of Lab 1, `checkpoints/02` is the
start of Lab 2, and so on. `answers/NN` is the completed lab. If you need to
recover, back up your edits, then copy that checkpoint's StudentProgram.java
into the source path above and its TrainingLine.path into
`src/main/deploy/pathplanner/paths/TrainingLine.path`. Do not compile checkpoint
or answer folders as additional source roots. Keep one cumulative working copy.

PathPlanner GUI 2026.1.2 opens this project root. Its path schema says 2025.0;
that is the file-format identifier used by this pinned library, not an installer
instruction. Marker position is a fraction of the segment, not elapsed time.
The robot preloads TrainingLine.auto after configuration and named-command registration.
Its resetOdom setting controls the initial pose reset when the auto starts. A bounded
command stops on completion/interruption; a stale heartbeat cancels autonomous.
Manual fault recovery resumes only the current held request, not an old canceled auto.
The browser dropdown is the autonomous selector; no dashboard chooser is needed.

## Tests and logs

`.\gradlew.bat test` exercises the infrastructure using a completed reference
program. It can pass while your StudentProgram TODOs remain unfinished. After
Lab 6, use `.\gradlew.bat test -PcheckStudent --rerun-tasks` to check your current
program. Earlier checkpoints should fail that final acceptance test.
Both modes use build/simulation-test as a disposable working directory, including
a complete deploy tree. They never replace your source .path/.auto files.
The checkStudent setting is a Gradle input so test results cannot be reused across modes.

The checks cover command cleanup, slow mode, diagonal normalization, actual
PathPlanner motion, repeated named events, reset/early disable, stale input and
recovery. They use native desktop WPILib simulation, not real hardware.

AdvantageKit writes `logs/*.wpilog`. Lab 3 adds Training/InputX, SlowMode,
XMeters, YMeters, HeadingDegrees and RequestedSpeedMps. Supplied signals include
AppliedSpeedMps, Light, EventCount, HeartbeatAgeSeconds and AlertActive.
The viewer may display them under `RealOutputs/Training/`. Stop Java first;
open the newest log in AdvantageScope (included with WPILib), or use v11 when
your mentor supplies its local file. The public course does not distribute v11. Plot the original
signals and state what each proves. In v11, use Topic explorer, search Training/,
click Load topic beside each needed signal, then choose graph A or B. Training
signals are indexed initially but loaded on demand to limit memory use. A requested speed is not measured motion.

Keep logs, build outputs and caches out of Git. Record your prediction, changed
file, observed result and next question in `learning-notes.txt`.

## Pinned versions and limits

See `versions.json`: WPILib 2026.2.1, Java 17, Gradle 8.11, AdvantageKit 26.0.2,
PathPlannerLib/GUI 2026.1.2, Commands v2. Do not upgrade one component alone.
If port 8767 is busy, stop the previous run. If native libraries cannot load,
follow the WPILib installer's Windows runtime requirements. The default run
does not need the native simulation GUI; `-Pgui` is an optional mentor tool.

A fresh student-account installer/VS Code walkthrough and native PathPlanner GUI
open/save/preview are separate manual acceptance checks. Successful simulator
tests do not establish SystemCore timing, real drivetrain performance, camera
freshness or competition readiness.


## Author a command and mechanism

Lesson 8's command-lab contains starter/answer src trees for LightForSeconds and
LightCommandTest. Copy the starter's new files to the matching src folders, complete
the TODOs, then run `.\gradlew.bat test --tests "frc.robot.LightCommandTest"`.

After the six core labs, mechanism-lab contains TrainingRoller, CaptureObject and
MechanismTest. The course's mechanism-lab.html explains the three TODOs, B-button
binding and Object present checkbox. Run
`.\gradlew.bat test --tests "frc.robot.MechanismTest"` after copying the starter.
Once these labs are installed, their tests always check your edited classes, even when the core SimulationTest uses its supplied reference. The answers are for comparison after trying. Preserve your own edits before copying.
These exercises are not compiled until you place their files under src.

## File map and input order

- Robot.java: constructor, practice(), scheduler and mode callbacks you should read.
- StudentProgram.java: your cumulative core-lab edits.
- RobotContainer.java: commands, standard CommandXboxController(0), paths and signals.
- Constants.java: named slow-mode and deadband settings.
- TrainingHarness.java: supplied logging startup, elapsed time and browser snapshots.
- Station.java / SimControls.java: supplied HTTP/watchdog and virtual controller packets.

The station applies a complete axis/button/mode snapshot, then notifies the simulated
Driver Station. Robot checks freshness, runs the scheduler, updates the model, records
logs and publishes browser state. No browser Gamepad support is required. Screen axes
are deliberately W+Y and D+X, not a claim about a physical driver's forward/left mapping.
See controller-bridge.html for the conversion. Windows instructions are verified at
the command/test level; a clean student-account VS Code/install walkthrough remains
manual. Other operating-system workflows are not yet classroom-tested.
