package frc.robot;

import java.util.Set;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import edu.wpi.first.wpilibj2.command.Commands;
import org.littletonrobotics.junction.Logger;

/** Checkpoint 04: Labs 1–3 done; start Lab 4. */
public class StudentProgram {
    public void configure(RobotContainer robot) {
        // A Trigger asks this question repeatedly. whileTrue starts on a press,
        // and cancels on release. Our command's end() performs the cleanup.
        robot.driver.a().whileTrue(robot.lightCommand());

        // A default command runs when this subsystem has no other command.
        // The supplied helper reads current input on each scheduler pass.
        robot.drive.setDefaultCommand(robot.manualDriveCommand());
        // LAB 4 TODO: add the connection shown in the matching lesson.
    }
    public void record(RobotContainer robot) {
        Logger.recordOutput("Training/InputX", robot.input().x());
        Logger.recordOutput("Training/SlowMode", robot.input().slow());
        Logger.recordOutput("Training/XMeters", robot.drive.getPose().getX());
        Logger.recordOutput("Training/YMeters", robot.drive.getPose().getY());
        Logger.recordOutput("Training/HeadingDegrees", robot.drive.getPose().getRotation().getDegrees());
        double xSpeed = robot.drive.getRequestedSpeeds().vxMetersPerSecond;
        double ySpeed = robot.drive.getRequestedSpeeds().vyMetersPerSecond;
        Logger.recordOutput("Training/RequestedSpeedMps", Math.hypot(xSpeed, ySpeed));
    }
    public boolean heartbeatIsStale(double ageSeconds) {
        // LAB 6 TODO: data OLDER THAN 0.50 seconds is stale.
        return false;
    }
}
