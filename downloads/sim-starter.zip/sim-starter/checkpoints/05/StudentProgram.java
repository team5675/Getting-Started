package frc.robot;

import java.util.Set;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import edu.wpi.first.wpilibj2.command.Commands;
import org.littletonrobotics.junction.Logger;

/** Checkpoint 05: start Lab 5; Labs 1–4 complete. */
public class StudentProgram {
    public void configure(RobotContainer robot) {
        // A Trigger asks this question repeatedly. whileTrue starts on a press,
        // and cancels on release. Our command's end() performs the cleanup.
        robot.driver.a().whileTrue(robot.lightCommand());

        // A default command runs when this subsystem has no other command.
        // The supplied helper reads current input on each scheduler pass.
        robot.drive.setDefaultCommand(robot.manualDriveCommand());

        // All speed callbacks below use ROBOT-relative velocities.
        // Pose remains in the fixed BLUE field frame.
        AutoBuilder.configure(
                robot.drive::getPose,
                robot.drive::resetPose,
                robot.drive::getRobotRelativeSpeeds,
                (speeds, feedforwards) -> robot.drive.driveRobotRelative(speeds),
                new PPHolonomicDriveController(new PIDConstants(5, 0, 0), new PIDConstants(5, 0, 0)),
                robot.trainingPathConfig(),
                () -> false, // No alliance mirroring on this classroom grid.
                robot.drive);
        // Our ideal velocity model does not use wheel feedforward voltages.
        robot.markPathConfigured();
        // LAB 5 TODO: add the connection shown in the matching lesson.
    }
    public void record(RobotContainer robot) {
        Logger.recordOutput("Training/InputX", robot.input().x());
        Logger.recordOutput("Training/SlowMode", robot.input().slow());
        Logger.recordOutput("Training/XMeters", robot.drive.getPose().getX());
        Logger.recordOutput("Training/YMeters", robot.drive.getPose().getY());
        Logger.recordOutput("Training/HeadingDegrees", robot.drive.getPose().getRotation().getDegrees());
        var request = robot.drive.getRequestedSpeeds();
        Logger.recordOutput("Training/RequestedSpeedMps", Math.hypot(request.vxMetersPerSecond, request.vyMetersPerSecond));
    }
    public boolean heartbeatIsStale(double ageSeconds) {
        // LAB 6 TODO: data OLDER THAN 0.50 seconds is stale.
        return false;
    }
}
