package frc.robot;

import java.util.Set;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import edu.wpi.first.wpilibj2.command.Commands;
import org.littletonrobotics.junction.Logger;

/** Checkpoint 01: start Lab 1; Labs 1–0 complete. */
public class StudentProgram {
    public void configure(RobotContainer robot) {

        // LAB 1 TODO: add the connection shown in the matching lesson.
    }
    public void record(RobotContainer robot) {
        // LAB 3 TODO: record input, slow mode, pose and requested speed.
    }
    public boolean heartbeatIsStale(double ageSeconds) {
        // LAB 6 TODO: data OLDER THAN 0.50 seconds is stale.
        return false;
    }
}
