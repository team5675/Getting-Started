package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.CommandScheduler;

/** A single actual LoggedRobot lifecycle: scheduler, PathPlanner, JNI and logging.
 * Default: test the supplied reference behavior. -PcheckStudent tests YOUR file.
 * One logger per JVM: AdvantageKit cannot restart its receiver after Logger.end().
 */
public class SimulationTest {
    private final AtomicReference<TrainingInput> input = new AtomicReference<>(TrainingInput.disabled());
    private void set(String mode,double x,double y,boolean light,boolean slow,boolean fault,boolean path) {
        input.set(new TrainingInput(mode,x,y,0,light,slow,fault,0,path));
        SimControls.publish(input.get());
    }
    private void step(double seconds) {
        for(int i=0;i<(int)Math.ceil(seconds/.02);i++) SimHooks.stepTiming(.02);
    }
    @Test void completeStudentJourney() throws Exception {
        assertTrue(HAL.initialize(500,0));
        SimHooks.restartTiming(); SimHooks.pauseTiming(); DriverStationSim.resetData();
        boolean student=Boolean.getBoolean("checkStudent");
        StudentProgram program = student ? new StudentProgram() : new CompletedProgram();
        Robot robot=null; Thread thread=null;
        AtomicReference<Throwable> failure=new AtomicReference<>();
        try {
            robot=new Robot(new TrainingHarness(input::get, program));
            Robot running=robot;
            thread=new Thread(running::startCompetition,"training-test-robot");
            thread.setUncaughtExceptionHandler((t,e)->failure.set(e));
            thread.start();
            SimHooks.stepTiming(0);
            set("disabled",0,0,false,false,false,false);step(.1);
            set("teleop",0,0,true,false,false,false);step(.1);
            assertTrue(robot.container.light.isOn(),"Lab 1: button starts light command");
            set("teleop",0,0,false,false,false,false);step(.1);
            assertFalse(robot.container.light.isOn(),"Release cleans up");
            set("teleop",0,0,true,false,false,false);step(.1);
            CommandScheduler.getInstance().schedule(robot.container.lightCommand().withTimeout(.1));
            step(.2);
            assertFalse(robot.container.light.isOn(),"Conflicting command interrupts, then times out; held trigger does not restart");
            set("disabled",0,0,false,false,false,false);step(.1);
            double start=robot.container.drive.getPose().getX();
            set("teleop",1,0,false,false,false,false);step(1);
            double normal=robot.container.drive.getPose().getX()-start;
            assertTrue(normal>.85&&normal<1.1,"Lab 2: default command drives at about 1m/s");
            start=robot.container.drive.getPose().getX();
            set("teleop",1,0,false,true,false,false);step(1);
            double slow=robot.container.drive.getPose().getX()-start;
            assertEquals(.35,slow/normal,.06,"Slow mode scale applies to live input");
            set("teleop",-1,-1,false,false,false,false);step(.1);
            var speed=robot.container.drive.getRobotRelativeSpeeds();
            assertEquals(1,Math.hypot(speed.vxMetersPerSecond,speed.vyMetersPerSecond),1e-6,"Diagonal is normalized");
            set("teleop",1,0,false,false,true,false);step(.7);
            assertTrue(robot.container.isStale(),"Lab 6: stale heartbeat raises real Alert state");
            assertEquals(1, robot.container.drive.getRequestedSpeeds().vxMetersPerSecond, 1e-9,
                    "Fault retains the active manual request for the log");
            var faultPose = robot.container.drive.getPose();
            step(.1);
            assertEquals(faultPose, robot.container.drive.getPose(), "Inhibited pose stays still");
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Fault inhibits motion");
            set("teleop",1,0,false,false,false,false);step(.1);
            assertFalse(robot.container.isStale(),"Fresh data recovers");
            assertTrue(robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond>.9,"Held input resumes after recovery");
            set("disabled",1,0,true,false,false,false);step(.1);
            assertFalse(robot.container.light.isOn(),"Disable cleans up");
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Disable stops");
            assertEquals(0, robot.container.drive.getRequestedSpeeds().vxMetersPerSecond, 1e-9,
                    "Disable clears intent as well as output");
            // Screen controls remain field-relative even after rotating the model.
            robot.container.drive.resetPose(new Pose2d(1,1,Rotation2d.fromDegrees(90)));
            set("teleop",0,1,false,false,false,false);step(.2);
            assertTrue(robot.container.drive.getPose().getY()>1.15, "W still moves screen up at heading 90");
            assertEquals(1,robot.container.drive.getPose().getX(),.02);
            set("teleop",-1,0,false,false,false,false);step(.2);
            assertTrue(robot.container.drive.getPose().getX()<.85, "A moves screen left");
            set("disabled",0,0,false,false,false,false);step(.1);
            // Path reset, event, finish and a second complete run.
            int before=robot.container.eventCount();
            for(int run=0;run<2;run++) {
                robot.container.drive.resetPose(new Pose2d(3,2,Rotation2d.fromDegrees(90)));
                set("autonomous",0,0,false,false,false,true);
                step(.04);
                assertEquals(1,robot.container.drive.getPose().getX(),.05,".auto resetOdom resets on initialization");
                assertEquals(1,robot.container.drive.getPose().getY(),.05);
                step(5);
                assertFalse(robot.container.pathFailed(),"Path must parse through real PathPlanner");
                assertEquals(2,robot.container.drive.getPose().getX(),.08,"Path ends near x=2");
                assertEquals(1,robot.container.drive.getPose().getY(),.08,"Path reset and y coordinate");
                assertEquals(before+run+1,robot.container.eventCount(),"Fresh named event each run");
                assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Finished path stops");
                set("disabled",0,0,false,false,false,true);step(.1);
            }
            set("autonomous",0,0,false,false,false,true);step(.5);
            set("disabled",0,0,false,false,false,true);step(.1);
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Interrupted path stops");
            // A sensor fault cancels a timed auto instead of resuming halfway later.
            set("autonomous",0,0,false,false,true,true);step(.7);
            assertTrue(robot.container.isStale());
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9);
            var canceledPose=robot.container.drive.getPose();
            set("autonomous",0,0,false,false,false,true);step(.2);
            assertFalse(robot.container.isStale());
            assertEquals(canceledPose,robot.container.drive.getPose(),"Fault recovery does not resume canceled auto");
            set("disabled",0,0,false,false,false,true);step(.1);
            // Reset OFF preserves the displaced initial pose, not a translated path.
            robot.container.drive.resetPose(new Pose2d(3,2,Rotation2d.fromDegrees(90)));
            set("autonomous",0,0,false,false,false,false);step(.04);
            var noReset = com.pathplanner.lib.auto.AutoBuilder.buildAuto("TrainingLineNoReset");
            CommandScheduler.getInstance().schedule(noReset);
            assertEquals(3,robot.container.drive.getPose().getX(),1e-9,"Loading/scheduling reset-off auto preserves pose");
            noReset.cancel();
            set("disabled",0,0,false,false,false,false);step(.1);
            assertFalse(program.heartbeatIsStale(.5),"Boundary is older than .5");
            assertTrue(program.heartbeatIsStale(.501));
            assertNull(failure.get(),"Robot thread must not fail silently");
        } finally {
            if(robot!=null) robot.endCompetition();
            if(thread!=null) { thread.join(2000);if(thread.isAlive())thread.interrupt();assertFalse(thread.isAlive(),"Robot thread stopped"); }
            if(robot!=null) robot.close();
            SimHooks.resumeTiming();
        }
    }
}
