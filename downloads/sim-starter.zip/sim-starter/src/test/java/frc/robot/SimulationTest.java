package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.CommandScheduler;

/** A single actual LoggedRobot lifecycle: scheduler, PathPlanner, JNI and logging.
 * Default: test the supplied reference behavior. -PcheckStudent tests YOUR file.
 * One logger per JVM: AdvantageKit cannot restart its receiver after Logger.end().
 */
public class SimulationTest {
    private final AtomicReference<TrainingInput> input = new AtomicReference<>(TrainingInput.disabled());
    private void set(String mode,double x,double y,boolean light,boolean slow,boolean fault,boolean path) {
        input.set(new TrainingInput(mode,x,y,0,light,slow,fault,0,path));
        DriverStationSim.setDsAttached(true);
        DriverStationSim.setAutonomous(mode.equals("autonomous"));
        DriverStationSim.setEnabled(!mode.equals("disabled"));
        DriverStationSim.notifyNewData();
    }
    private void step(double seconds) {
        for(int i=0;i<(int)Math.ceil(seconds/.02);i++) SimHooks.stepTiming(.02);
    }
    @Test void completeStudentJourney() throws Exception {
        assertTrue(HAL.initialize(500,0));
        SimHooks.restartTiming(); SimHooks.pauseTiming(); DriverStationSim.resetData();
        Path deployedPath=Path.of("src/main/deploy/pathplanner/paths/TrainingLine.path");
        byte[] originalPath=Files.readAllBytes(deployedPath);
        boolean student=Boolean.getBoolean("checkStudent");
        if(!student) Files.copy(Path.of("answers/06/TrainingLine.path"),deployedPath,java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        Robot robot=null; Thread thread=null;
        AtomicReference<Throwable> failure=new AtomicReference<>();
        try {
            robot=new Robot(input::get,student?new StudentProgram():new CompletedProgram());
            Robot running=robot;
            thread=new Thread(running::startCompetition,"training-test-robot");
            thread.setUncaughtExceptionHandler((t,e)->failure.set(e));
            thread.start();
            SimHooks.stepTiming(0);
            set("disabled",0,0,false,false,false,false);step(.1);
            set("teleop",0,0,true,false,false,false);step(.1);
            assertTrue(robot.container.light.isOn(),"Lab 1: button starts light command");
            set("teleop",0,0,false,false,false,false);step(.1);
            assertFalse(robot.container.light.isOn(),"Release cleans up");
            set("teleop",0,0,true,false,false,false);step(.1);
            CommandScheduler.getInstance().schedule(robot.container.lightCommand().withTimeout(.1));
            step(.2);
            assertFalse(robot.container.light.isOn(),"Conflicting command interrupts, then times out; held trigger does not restart");
            set("disabled",0,0,false,false,false,false);step(.1);
            double start=robot.container.drive.getPose().getX();
            set("teleop",1,0,false,false,false,false);step(1);
            double normal=robot.container.drive.getPose().getX()-start;
            assertTrue(normal>.85&&normal<1.1,"Lab 2: default command drives at about 1m/s");
            start=robot.container.drive.getPose().getX();
            set("teleop",1,0,false,true,false,false);step(1);
            double slow=robot.container.drive.getPose().getX()-start;
            assertEquals(.35,slow/normal,.06,"Slow mode scale applies to live input");
            set("teleop",-1,-1,false,false,false,false);step(.1);
            var speed=robot.container.drive.getRobotRelativeSpeeds();
            assertEquals(1,Math.hypot(speed.vxMetersPerSecond,speed.vyMetersPerSecond),1e-6,"Diagonal is normalized");
            set("teleop",1,0,false,false,true,false);step(.7);
            assertTrue(robot.container.isStale(),"Lab 6: stale heartbeat raises real Alert state");
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Fault inhibits motion");
            set("teleop",1,0,false,false,false,false);step(.1);
            assertFalse(robot.container.isStale(),"Fresh data recovers");
            assertTrue(robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond>.9,"Held input resumes after recovery");
            set("disabled",1,0,true,false,false,false);step(.1);
            assertFalse(robot.container.light.isOn(),"Disable cleans up");
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Disable stops");
            // Path reset, event, finish and a second complete run.
            int before=robot.container.eventCount();
            for(int run=0;run<2;run++) {
                robot.container.drive.resetPose(new Pose2d(3,2,Rotation2d.fromDegrees(90)));
                set("autonomous",0,0,false,false,false,true);
                step(5);
                assertFalse(robot.container.pathFailed(),"Path must parse through real PathPlanner");
                assertEquals(2,robot.container.drive.getPose().getX(),.08,"Path ends near x=2");
                assertEquals(1,robot.container.drive.getPose().getY(),.08,"Path reset and y coordinate");
                assertEquals(before+run+1,robot.container.eventCount(),"Fresh named event each run");
                assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Finished path stops");
                set("disabled",0,0,false,false,false,true);step(.1);
            }
            set("autonomous",0,0,false,false,false,true);step(.5);
            set("disabled",0,0,false,false,false,true);step(.1);
            assertEquals(0,robot.container.drive.getRobotRelativeSpeeds().vxMetersPerSecond,1e-9,"Interrupted path stops");
            assertFalse(new CompletedProgram().heartbeatIsStale(.5),"Boundary is older than .5");
            assertTrue(new CompletedProgram().heartbeatIsStale(.501));
            assertNull(failure.get(),"Robot thread must not fail silently");
        } finally {
            if(robot!=null) robot.endCompetition();
            if(thread!=null) { thread.join(2000);if(thread.isAlive())thread.interrupt();assertFalse(thread.isAlive(),"Robot thread stopped"); }
            if(robot!=null) robot.close();
            Files.write(deployedPath,originalPath);
            SimHooks.resumeTiming();
        }
    }
}
