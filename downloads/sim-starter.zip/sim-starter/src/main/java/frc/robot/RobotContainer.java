package frc.robot;

import java.util.function.Supplier;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.config.ModuleConfig;
import com.pathplanner.lib.config.RobotConfig;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.path.PathPlannerPath;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.system.plant.DCMotor;
import edu.wpi.first.wpilibj.Alert;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import frc.robot.commands.KeepLightOn;
import frc.robot.subsystems.PracticeLight;
import frc.robot.subsystems.TrainingDrive;
import org.littletonrobotics.junction.Logger;

/** Supplied connections; read one method when its lesson needs it. */
public class RobotContainer {
    public final TrainingDrive drive = new TrainingDrive();
    public final PracticeLight light = new PracticeLight();
    private final Supplier<TrainingInput> input;
    private final StudentProgram student;
    private final Alert staleAlert = new Alert("Training", "Simulated sensor heartbeat is stale; drive inhibited", Alert.AlertType.kWarning);
    private final Alert pathAlert = new Alert("Training", "Training path could not load; read the Terminal", Alert.AlertType.kError);
    private double lastHeartbeat = Timer.getFPGATimestamp();
    private double heartbeatAge;
    private boolean stale;
    private boolean pathConfigured;
    private int eventCount;
    public RobotContainer(Supplier<TrainingInput> input, StudentProgram student) {
        this.input = input;
        this.student = student;
        student.configure(this);
    }
    public TrainingInput input() { return input.get(); }
    public Command lightCommand() { return new KeepLightOn(light); }
    public Command manualDriveCommand() {
        // The supplier is read EVERY cycle, not once when the command is created.
        return Commands.runEnd(() -> {
            if (!edu.wpi.first.wpilibj.DriverStation.isTeleopEnabled()) { drive.stop(); return; }
            var controls = input();
            drive.driveFieldRelative(controls.x(), controls.y(), controls.turn(), controls.slow());
        }, drive::stop, drive).withName("Manual drive");
    }
    public RobotConfig trainingPathConfig() {
        // Fictional classroom dimensions and motor model. Never deploy these to a robot.
        var motor = DCMotor.getKrakenX60(1).withReduction(6.75);
        // Keep the ideal motor and free wheel speed consistent. An artificially
        // low free-speed value makes PathPlanner infer excessive torque loss.
        // The PATH constraints, not this motor parameter, set our 0.5 m/s limit.
        double idealFreeSpeed = motor.freeSpeedRadPerSec * 0.0508;
        var module = new ModuleConfig(0.0508, idealFreeSpeed, 1.0, motor, 40.0, 1);
        var config = new RobotConfig(50.0, 6.0, module,
                new Translation2d(.3, .3), new Translation2d(.3, -.3),
                new Translation2d(-.3, .3), new Translation2d(-.3, -.3));
        return config;
    }
    public void markPathConfigured() { pathConfigured = true; }
    public void eventReached() { eventCount++; }
    public int eventCount() { return eventCount; }
    public boolean isStale() { return stale; }
    public double heartbeatAge() { return heartbeatAge; }
    public boolean pathConfigured() { return pathConfigured; }
    public boolean pathFailed() { return pathAlert.get(); }
    public Command autonomousCommand(boolean choosePath) {
        if (!choosePath) return lightCommand().withTimeout(2.0);
        if (!pathConfigured) return Commands.print("Finish Lab 4 before selecting the path.");
        try {
            var path = PathPlannerPath.fromPathFile("TrainingLine");
            var start = path.getStartingHolonomicPose().orElseThrow();
            double duration = path.getIdealTrajectory(trainingPathConfig()).orElseThrow().getTotalTimeSeconds();
            if (!Double.isFinite(duration) || duration <= 0) {
                throw new IllegalArgumentException("TrainingLine must have a finite, positive duration; check path and model configuration");
            }
            pathAlert.set(false);
            return AutoBuilder.followPath(path)
                    .beforeStarting(() -> drive.resetPose(start))
                    .withTimeout(10.0)
                    .finallyDo(interrupted -> drive.stop());
        } catch (Exception error) {
            pathAlert.set(true);
            error.printStackTrace();
            return Commands.runOnce(drive::stop, drive);
        }
    }
    public void beforeScheduler() {
        double now = Timer.getFPGATimestamp();
        if (!input().pauseHeartbeat()) lastHeartbeat = now;
        heartbeatAge = Math.max(0, now - lastHeartbeat);
        stale = student.heartbeatIsStale(heartbeatAge);
        staleAlert.set(stale); // Real WPILib Alert, also published under Training.
        drive.setInhibited(stale);
    }
    public void afterScheduler(double dt) {
        drive.step(dt);
        student.record(this);
        // Supplied evidence about framework state; students add their experiment.
        Logger.recordOutput("Training/Light", light.isOn());
        Logger.recordOutput("Training/EventCount", eventCount);
        Logger.recordOutput("Training/HeartbeatAgeSeconds", heartbeatAge);
        Logger.recordOutput("Training/AlertActive", stale);
        Logger.recordOutput("Training/Reason", stale ? "STALE_HEARTBEAT" : "FRESH");
        Logger.recordOutput("Training/Mode", input().mode());
        Logger.recordOutput("Training/AppliedSpeedMps", Math.hypot(drive.getRobotRelativeSpeeds().vxMetersPerSecond,
                drive.getRobotRelativeSpeeds().vyMetersPerSecond));
    }
}
