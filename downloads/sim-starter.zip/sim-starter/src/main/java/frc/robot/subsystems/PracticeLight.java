package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

/** A remembered boolean, not a physical lamp. No hardware is constructed. */
public class PracticeLight extends SubsystemBase {
    private boolean on;
    private int starts;
    public void setOn(boolean value) {
        if (value && !on) starts++;
        if (value != on) System.out.println("Light on: " + value);
        on = value;
    }
    public boolean isOn() { return on; }
    public int getStarts() { return starts; }
}
