package frc.robot;

import edu.wpi.first.wpilibj.RobotBase;

/** The entry point is supplied. Students begin with StudentProgram.java. */
public final class Main {
    private Main() {}
    public static void main(String... args) {
        RobotBase.startRobot(Robot::new);
    }
}
