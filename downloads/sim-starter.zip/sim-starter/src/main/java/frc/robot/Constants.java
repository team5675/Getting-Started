package frc.robot;

/** Named settings let a teammate change one meaning, not hunt for a number. */
public final class Constants {
    private Constants() {}
    public static final double SLOW_MODE_SCALE = 0.35;
    public static final double DRIVE_DEADBAND = 0.08;
}
