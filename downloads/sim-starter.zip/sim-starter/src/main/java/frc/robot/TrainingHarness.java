package frc.robot;

import java.util.Locale;
import java.util.function.Supplier;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.Timer;
import frc.robot.subsystems.TrainingDrive;
import org.littletonrobotics.junction.Logger;
import org.littletonrobotics.junction.networktables.NT4Publisher;
import org.littletonrobotics.junction.wpilog.WPILOGWriter;

/** SUPPLIED INFRASTRUCTURE: browser transport, logging setup and elapsed time.
 * Robot still shows the lifecycle and scheduler; StudentProgram holds lab edits.
 */
public final class TrainingHarness implements AutoCloseable {
    private Station station;
    private Supplier<TrainingInput> controls;
    private final StudentProgram student;
    private double previousTime;
    private long lastReset;
    private volatile String snapshot = "{\"mode\":\"disabled\"}";
    public TrainingHarness() { this(null, new StudentProgram()); }
    public TrainingHarness(Supplier<TrainingInput> testInput, StudentProgram student) {
        controls = testInput;
        this.student = student;
    }
    public RobotContainer start() {
        if (RobotBase.isReal()) throw new IllegalStateException("Desktop training only");
        Logger.recordMetadata("ProjectName", "WiredCats Sim Starter 2026.2.1");
        Logger.recordMetadata("Model", "Ideal velocities; no hardware or sensor physics");
        Logger.addDataReceiver(new WPILOGWriter("logs", WPILOGWriter.AdvantageScopeOpenBehavior.NEVER));
        Logger.addDataReceiver(new NT4Publisher());
        Logger.start();
        if (controls == null) {
            station = new Station(() -> snapshot);
            controls = station::input;
        }
        // Make joystick 0 available before configure() creates button bindings.
        if (station == null) { SimControls.publish(controls.get()); }
        RobotContainer container = new RobotContainer(controls, student);
        previousTime = Timer.getFPGATimestamp();
        if (station != null) {
            System.out.println("WiredCats training ready. Open http://127.0.0.1:8767");
        }
        return container;
    }
    public TrainingInput input() { return controls.get(); }
    public double beginCycle(RobotContainer container) {
        double now = Timer.getFPGATimestamp();
        double dt = Math.max(0, Math.min(0.1, now - previousTime));
        previousTime = now;
        TrainingInput input = input();
        if (input.reset() != lastReset) {
            lastReset = input.reset();
            if (DriverStation.isDisabled()) {
                container.drive.resetPose(TrainingDrive.initialPose());
            }
        }
        return dt;
    }
    public void show(RobotContainer container) {
        var pose = container.drive.getPose();
        var requested = container.drive.getRequestedSpeeds();
        var applied = container.drive.getRobotRelativeSpeeds();
        String mode = DriverStation.isDisabled() ? "disabled" : DriverStation.isAutonomous() ? "autonomous" : "teleop";
        snapshot = String.format(Locale.ROOT,
                "{\"mode\":\"%s\",\"xMeters\":%.6f,\"yMeters\":%.6f,\"headingDegrees\":%.4f,"
                + "\"requestedSpeed\":%.5f,\"appliedSpeed\":%.5f,\"light\":%b,\"eventCount\":%d,"
                + "\"alertActive\":%b,\"alertText\":\"%s\",\"heartbeatAgeSeconds\":%.3f,\"pathReady\":%b,\"controlAgeMs\":%.0f}",
                mode, pose.getX(), pose.getY(), pose.getRotation().getDegrees(),
                Math.hypot(requested.vxMetersPerSecond, requested.vyMetersPerSecond),
                Math.hypot(applied.vxMetersPerSecond, applied.vyMetersPerSecond),
                container.light.isOn(), container.eventCount(), container.isStale() || container.pathFailed(),
                container.pathFailed() ? "Path load failed; see Terminal" : "Simulated sensor heartbeat stale; drive inhibited",
                container.heartbeatAge(), container.pathConfigured(), station == null ? 0 : station.ageMillis());
    }
    @Override public void close() {
        if (station != null) { station.close(); }
        Logger.end();
    }
}
