package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.PracticeLight;

/** Lesson 8: the scheduler owns the timing, so this action never waits in a loop. */
public class KeepLightOn extends Command {
    private final PracticeLight light;
    public KeepLightOn(PracticeLight light) {
        this.light = light;
        addRequirements(light); // Another light command must interrupt this one.
    }
    @Override public void initialize() { light.setOn(true); }
    @Override public void end(boolean interrupted) { light.setOn(false); }
}
