package frc.robot;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/** Supplied browser adapter. Binds loopback only and controls SIMULATED DS data.
 * A missed heartbeat clears input and requires a fresh mode-button click.
 */
public class Station implements AutoCloseable {
    private final HttpServer server;
    private final ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor();
    private TrainingInput input = TrainingInput.disabled();
    private long receivedNanos = System.nanoTime();
    private long sequence = -1;
    private long revokedRevision = -1;
    private long revision = 0;
    private String client = "";
    private String dsMode = "";
    public Station(Supplier<String> state) {
        try {
            server = HttpServer.create(new InetSocketAddress("127.0.0.1", 8767), 0);
            server.createContext("/", exchange -> {
                if (!exchange.getRequestURI().getPath().equals("/")) { send(exchange,404,"text/plain","Not found"); return; }
                try (var stream = Station.class.getResourceAsStream("/station.html")) {
                    if (stream == null) throw new IOException("station.html missing");
                    send(exchange,200,"text/html",new String(stream.readAllBytes(),StandardCharsets.UTF_8));
                }
            });
            server.createContext("/state", exchange -> send(exchange,200,"application/json",state.get()));
            server.createContext("/control", this::control);
            server.start();
            watchdog.scheduleAtFixedRate(this::publishDriverStation, 0, 20, TimeUnit.MILLISECONDS);
        } catch (IOException error) { throw new IllegalStateException("Port 8767 is busy; stop the previous training run",error); }
    }
    public synchronized TrainingInput input() { expire(); return input; }
    public synchronized double ageMillis() { return (System.nanoTime()-receivedNanos)/1e6; }
    private synchronized void expire() {
        if (ageMillis() > 750 && !input.mode().equals("disabled")) {
            revokedRevision = Math.max(revokedRevision, revision);
            input = TrainingInput.disabled();
        }
    }
    private synchronized void publishDriverStation() {
        expire();
        String next = input.mode();
        if (!next.equals(dsMode)) {
            DriverStationSim.setEnabled(!next.equals("disabled"));
            DriverStationSim.setAutonomous(next.equals("autonomous"));
            DriverStationSim.setTest(false);
            dsMode = next;
        }
        DriverStationSim.setDsAttached(true);
        DriverStationSim.notifyNewData();
    }
    private void control(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equals("POST")) { send(exchange,405,"text/plain","POST required"); return; }
        String origin = exchange.getRequestHeaders().getFirst("Origin");
        if (origin != null && !origin.equals("http://127.0.0.1:8767")) { send(exchange,403,"text/plain","Use the local station"); return; }
        byte[] bytes = exchange.getRequestBody().readNBytes(4097);
        if (bytes.length > 4096) { send(exchange,413,"text/plain","Too large"); return; }
        Map<String,String> values = new HashMap<>();
        for (String pair : new String(bytes,StandardCharsets.UTF_8).split("&")) {
            String[] pieces = pair.split("=",2);
            if (pieces.length == 2) values.put(pieces[0],URLDecoder.decode(pieces[1],StandardCharsets.UTF_8));
        }
        try {
            synchronized (this) {
                expire();
                String incomingClient = values.getOrDefault("client","");
                if (incomingClient.isEmpty()) throw new IllegalArgumentException();
                if (!client.equals(incomingClient)) {
                    if (!input.mode().equals("disabled")) { send(exchange,409,"text/plain","Another station is active"); return; }
                    client = incomingClient; sequence = -1; revokedRevision = -1;
                }
                long incomingSeq = Long.parseLong(values.get("seq"));
                if (incomingSeq <= sequence) { send(exchange,409,"text/plain","Old input"); return; }
                sequence = incomingSeq;
                revision = Long.parseLong(values.get("revision"));
                String mode = values.get("mode");
                if (!java.util.Set.of("disabled","teleop","autonomous").contains(mode)) throw new IllegalArgumentException();
                if (revision <= revokedRevision) mode = "disabled";
                input = new TrainingInput(mode,axis(values,"x"),axis(values,"y"),axis(values,"omega"),
                        Boolean.parseBoolean(values.get("light")),Boolean.parseBoolean(values.get("slow")),
                        Boolean.parseBoolean(values.get("pauseHeartbeat")),Long.parseLong(values.get("reset")),
                        Boolean.parseBoolean(values.get("path")));
                receivedNanos = System.nanoTime();
            }
            send(exchange,200,"text/plain","OK");
        } catch (RuntimeException error) { send(exchange,400,"text/plain","Invalid input"); }
    }
    private static double axis(Map<String,String> values,String key) {
        double value = Double.parseDouble(values.get(key));
        if (!Double.isFinite(value)) throw new IllegalArgumentException();
        return Math.max(-1,Math.min(1,value));
    }
    private static void send(HttpExchange e,int status,String type,String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        e.getResponseHeaders().set("Content-Type",type+"; charset=utf-8");
        e.getResponseHeaders().set("Cache-Control","no-store");
        e.sendResponseHeaders(status,bytes.length);
        try(var stream=e.getResponseBody()) { stream.write(bytes); }
    }
    @Override public void close() {
        watchdog.shutdownNow();
        DriverStationSim.setEnabled(false);
        DriverStationSim.notifyNewData();
        server.stop(0);
    }
}
