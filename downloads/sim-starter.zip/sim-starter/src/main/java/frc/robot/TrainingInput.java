package frc.robot;

/** One immutable snapshot prevents half-old, half-new input between threads. */
public record TrainingInput(String mode, double x, double y, double turn,
        boolean light, boolean slow, boolean pauseHeartbeat, long reset, boolean path) {
    public static TrainingInput disabled() {
        return new TrainingInput("disabled", 0, 0, 0, false, false, false, 0, false);
    }
}
