package frc.robot;

/** One immutable snapshot prevents half-old, half-new input between threads. */
public record TrainingInput(String mode, double x, double y, double turn,
        boolean light, boolean slow, boolean pauseHeartbeat, long reset, boolean path,
        boolean roller, boolean objectPresent) {
    /** Keep the core-lab input constructor small; Lab 7 adds two optional signals. */
    public TrainingInput(String mode, double x, double y, double turn, boolean light,
            boolean slow, boolean pauseHeartbeat, long reset, boolean path) {
        this(mode, x, y, turn, light, slow, pauseHeartbeat, reset, path, false, false);
    }
    public static TrainingInput disabled() {
        return new TrainingInput("disabled", 0, 0, 0, false, false, false, 0, false);
    }
}
