package frc.robot;

import java.util.Locale;
import java.util.function.Supplier;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.subsystems.TrainingDrive;
import org.littletonrobotics.junction.LoggedRobot;
import org.littletonrobotics.junction.Logger;
import org.littletonrobotics.junction.networktables.NT4Publisher;
import org.littletonrobotics.junction.wpilog.WPILOGWriter;

/** Startup runs once in Robot(). Periodic work returns quickly each pass. */
public class Robot extends LoggedRobot {
    public final RobotContainer container;
    private Station station;
    private final Supplier<TrainingInput> controls;
    private Command autonomous;
    private double previousTime;
    private long lastReset;
    private volatile String snapshot = "{\"mode\":\"disabled\"}";
    public Robot() { this(null, new StudentProgram()); }
    /** The integration test supplies input without opening a browser server. */
    public Robot(Supplier<TrainingInput> testInput, StudentProgram student) {
        if (RobotBase.isReal()) throw new IllegalStateException("Desktop training only");
        Logger.recordMetadata("ProjectName", "WiredCats Sim Starter 2026.2.1");
        Logger.recordMetadata("Model", "Ideal velocities; no hardware or sensor physics");
        Logger.addDataReceiver(new WPILOGWriter("logs", WPILOGWriter.AdvantageScopeOpenBehavior.NEVER));
        Logger.addDataReceiver(new NT4Publisher());
        Logger.start();
        if (testInput == null) {
            station = new Station(() -> snapshot);
            controls = station::input;
        } else controls = testInput;
        container = new RobotContainer(controls, student);
        previousTime = Timer.getFPGATimestamp();
        practice(); // This is our helper. WPILib does not call it automatically.
    }
    /** Older calculation labs replace ONLY this helper. No @Override is needed. */
    private void practice() {
        System.out.println("WiredCats training ready. Open http://127.0.0.1:8767");
    }
    @Override public void robotPeriodic() {
        double now = Timer.getFPGATimestamp();
        double dt = Math.max(0, Math.min(0.1, now - previousTime));
        previousTime = now;
        var input = controls.get();
        if (input.reset() != lastReset) {
            lastReset = input.reset();
            if (DriverStation.isDisabled()) container.drive.resetPose(TrainingDrive.initialPose());
        }
        container.beforeScheduler();
        CommandScheduler.getInstance().run(); // Keep this: it advances commands.
        container.afterScheduler(dt);
        var pose = container.drive.getPose();
        var requested = container.drive.getRequestedSpeeds();
        var applied = container.drive.getRobotRelativeSpeeds();
        String mode = DriverStation.isDisabled() ? "disabled" : DriverStation.isAutonomous() ? "autonomous" : "teleop";
        snapshot = String.format(Locale.ROOT,
                "{\"mode\":\"%s\",\"xMeters\":%.6f,\"yMeters\":%.6f,\"headingDegrees\":%.4f,"
                + "\"requestedSpeed\":%.5f,\"appliedSpeed\":%.5f,\"light\":%b,\"eventCount\":%d,"
                + "\"alertActive\":%b,\"alertText\":\"%s\",\"heartbeatAgeSeconds\":%.3f,\"pathReady\":%b,\"controlAgeMs\":%.0f}",
                mode, pose.getX(), pose.getY(), pose.getRotation().getDegrees(),
                Math.hypot(requested.vxMetersPerSecond, requested.vyMetersPerSecond),
                Math.hypot(applied.vxMetersPerSecond, applied.vyMetersPerSecond),
                container.light.isOn(), container.eventCount(), container.isStale() || container.pathFailed(),
                container.pathFailed() ? "Path load failed; see Terminal" : "Simulated sensor heartbeat stale; drive inhibited",
                container.heartbeatAge(), container.pathConfigured(), station == null ? 0 : station.ageMillis());
    }
    @Override public void autonomousInit() {
        autonomous = container.autonomousCommand(controls.get().path());
        CommandScheduler.getInstance().schedule(autonomous);
    }
    @Override public void teleopInit() {
        if (autonomous != null) autonomous.cancel();
    }
    @Override public void disabledInit() {
        CommandScheduler.getInstance().cancelAll();
        container.drive.stop();
        container.light.setOn(false);
    }
    @Override public void close() {
        if (station != null) station.close();
        CommandScheduler.getInstance().cancelAll();
        Logger.end();
        super.close();
    }
}
