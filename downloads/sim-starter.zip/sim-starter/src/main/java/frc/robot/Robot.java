package frc.robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import org.littletonrobotics.junction.LoggedRobot;

/** Startup runs once in Robot(). Every periodic callback must return quickly. */
public class Robot extends LoggedRobot {
    public final RobotContainer container;
    private final TrainingHarness harness;
    private Command autonomous;

    public Robot() { this(new TrainingHarness()); }
    // Supplied test seam: the same robot lifecycle can use scripted inputs.
    Robot(TrainingHarness harness) {
        this.harness = harness;
        container = harness.start();
        practice(); // Our helper: WPILib does not call it automatically.
    }
    /** Calculation lessons replace ONLY this helper. No @Override is needed. */
    private void practice() {
        // Add the current lesson's short calculation here.
    }
    @Override public void robotPeriodic() {
        double dt = harness.beginCycle(container);
        container.beforeScheduler(); // Freshness checks set output inhibition.
        // A trajectory uses elapsed time: blocking motion does not pause it.
        // Cancel auto on a sensor fault; recovery requires a new mode selection.
        if (DriverStation.isAutonomousEnabled() && container.isStale() && autonomous != null) {
            autonomous.cancel();
        }
        CommandScheduler.getInstance().run(); // Starts, executes and ends commands.
        container.afterScheduler(dt);         // Update model, then record evidence.
        harness.show(container);              // Publish the browser snapshot.
    }
    @Override public void autonomousInit() {
        autonomous = container.autonomousCommand(harness.input().path());
        CommandScheduler.getInstance().schedule(autonomous);
    }
    @Override public void teleopInit() {
        if (autonomous != null) { autonomous.cancel(); }
    }
    @Override public void disabledInit() {
        CommandScheduler.getInstance().cancelAll();
        container.drive.stop();
        container.light.setOn(false);
    }
    @Override public void close() {
        CommandScheduler.getInstance().cancelAll();
        harness.close();
        super.close();
    }
}
