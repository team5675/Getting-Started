package frc.robot.subsystems;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Twist2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/** Ideal velocity model: no motors, tire slip, sensor noise or physical inertia.
 * This proves software connections, NOT real swerve tuning or calibration.
 */
public class TrainingDrive extends SubsystemBase {
    private Pose2d pose = initialPose();
    private ChassisSpeeds requested = new ChassisSpeeds();
    private ChassisSpeeds applied = new ChassisSpeeds();
    private boolean inhibited;
    public static Pose2d initialPose() { return new Pose2d(1, 1, new Rotation2d()); }
    public Pose2d getPose() { return pose; }
    public ChassisSpeeds getRobotRelativeSpeeds() { return applied; }
    public ChassisSpeeds getRequestedSpeeds() { return requested; }
    public void resetPose(Pose2d value) { pose = value; stop(); }
    public void setInhibited(boolean value) { inhibited = value; if (value) stop(); }
    public void driveRobotRelative(ChassisSpeeds speeds) {
        requested = speeds;
        if (inhibited || DriverStation.isDisabled()) applied = new ChassisSpeeds();
        else applied = speeds;
    }
    public void stop() { requested = new ChassisSpeeds(); applied = new ChassisSpeeds(); }
    public void driveFieldRelative(double x, double y, double turn, boolean slow) {
        // Normalize the XY vector together: diagonals cannot exceed full speed.
        double magnitude = Math.max(1.0, Math.hypot(x, y));
        double scale = slow ? 0.35 : 1.0;
        double vx = x / magnitude * scale;
        double vy = y / magnitude * scale;
        driveRobotRelative(ChassisSpeeds.fromFieldRelativeSpeeds(vx, vy, turn * scale,
                pose.getRotation()));
    }
    public void step(double seconds) {
        if (DriverStation.isDisabled() || inhibited) { stop(); return; }
        pose = pose.exp(new Twist2d(applied.vxMetersPerSecond * seconds,
                applied.vyMetersPerSecond * seconds, applied.omegaRadiansPerSecond * seconds));
    }
}
