package frc.robot;

import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.XboxControllerSim;

/** Supplied adapter: publish a complete virtual-controller/DS packet together.
 * Students read CommandXboxController in RobotContainer, just as on a real robot.
 * This classroom VIEW maps right to field +X and up to field +Y. A real driver's
 * forward/left field mapping is a separate choice, explained in controller-bridge.
 */
public final class SimControls {
    private static final XboxControllerSim controller = new XboxControllerSim(0);
    private SimControls() {}
    public static synchronized void publish(TrainingInput input) {
        controller.setAxisCount(6);
        controller.setButtonCount(10);
        controller.setPOVCount(1);
        controller.setPOV(-1);
        controller.setLeftX(input.x());       // D/right is controller +X.
        controller.setLeftY(-input.y());      // W/up is controller -Y.
        controller.setRightX(-input.turn());  // Q/CCW is opposite stick-right.
        controller.setAButton(input.light());
        controller.setBButton(input.roller());
        controller.setLeftBumperButton(input.slow());
        DriverStationSim.setEnabled(!input.mode().equals("disabled"));
        DriverStationSim.setAutonomous(input.mode().equals("autonomous"));
        DriverStationSim.setTest(false);
        DriverStationSim.setDsAttached(true);
        DriverStationSim.notifyNewData(); // Publish AFTER all axes/buttons/mode.
    }
}
