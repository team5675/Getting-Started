package frc.robot;

import java.util.Set;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import edu.wpi.first.wpilibj2.command.Commands;
import org.littletonrobotics.junction.Logger;

/** Answer 01: completed through Lab 1. Future-lab TODOs remain. */
public class StudentProgram {
    public void configure(RobotContainer robot) {
        // A Trigger asks this question repeatedly. whileTrue starts on a press,
        // and cancels on release. Our command's end() performs the cleanup.
        robot.driver.a().whileTrue(robot.lightCommand());
    }
    public void record(RobotContainer robot) {
        // LAB 3 TODO: record input, slow mode, pose and requested speed.
    }
    public boolean heartbeatIsStale(double ageSeconds) {
        // LAB 6 TODO: data OLDER THAN 0.50 seconds is stale.
        return false;
    }
}
