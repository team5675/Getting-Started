package frc.robot;

import java.util.Set;
import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import org.littletonrobotics.junction.Logger;

/** Checkpoint 02: completed through Lab 2. Edit the TODO for your lab. */
public class StudentProgram {
    public void configure(RobotContainer robot) {
        // A Trigger asks this question repeatedly. whileTrue starts on a press,
        // and cancels on release. Our command's end() performs the cleanup.
        new Trigger(() -> robot.input().light()).whileTrue(robot.lightCommand());

        // A default command runs when this subsystem has no other command.
        // The supplied helper reads current input on each scheduler pass.
        robot.drive.setDefaultCommand(robot.manualDriveCommand());
        // LAB 2 TODO: add the connection shown in the matching lesson.
    }
    public void record(RobotContainer robot) {
        // LAB 3 TODO: record input, slow mode, pose and requested speed.
    }
    public boolean heartbeatIsStale(double ageSeconds) {
        // LAB 6 TODO: data OLDER THAN 0.50 seconds is stale.
        return false;
    }
}
