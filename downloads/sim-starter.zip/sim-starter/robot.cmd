@echo off
rem ===========================================================================
rem  robot.cmd  -  build, simulate or test this project with WPILib 2026's Java
rem
rem    .\robot                                   start the simulation
rem    .\robot build                             compile and run the reference test
rem    .\robot test -PcheckStudent --rerun-tasks check your own labs (after Lab 6)
rem
rem  Anything after "robot" is passed straight to Gradle, so
rem  .\robot test --tests "frc.robot.LightCommandTest" works too.
rem
rem  To stop the simulation: click in the Terminal and press Ctrl+C. Windows
rem  then asks "Terminate batch job (Y/N)?" - type Y and press Enter.
rem
rem  On Windows, WPILib 2026 always installs into %PUBLIC%\wpilib\2026
rem  (normally C:\Users\Public\wpilib\2026). Mentors: if your 2026 JDK is
rem  somewhere else, set WPILIB_2026_JDK to that jdk folder first.
rem ===========================================================================
setlocal EnableExtensions DisableDelayedExpansion

rem ---- 1. Find the WPILib 2026 Java (same rule the WPILib installer uses) ----
if defined WPILIB_2026_JDK (
  set "JDK=%WPILIB_2026_JDK%"
) else if defined PUBLIC (
  set "JDK=%PUBLIC%\wpilib\2026\jdk"
) else (
  set "JDK=C:\Users\Public\wpilib\2026\jdk"
)
if not exist "%JDK%\bin\java.exe" goto :nojava
"%JDK%\bin\java.exe" -version 2>&1 | findstr /r /c:"version .17\." >nul
if errorlevel 1 goto :wrongjava

rem ---- 2. Gradle reads JAVA_HOME. Run from this project's own folder. -------
set "JAVA_HOME=%JDK%"
cd /d "%~dp0"
if not exist "gradlew.bat" goto :nogradle
if "%~1"=="" goto :simulate
call gradlew.bat %*
exit /b %ERRORLEVEL%

:simulate
call gradlew.bat simulateJava
exit /b %ERRORLEVEL%

:nojava
echo Could not find the Java that WPILib 2026 installs.
echo Looked for: %JDK%\bin\java.exe
echo Install WPILib 2026 (Lesson 1, step 1) or ask a mentor for help.
exit /b 2

:wrongjava
echo The Java found at %JDK% is not Java 17.
echo This project needs the Java 17 that comes with WPILib 2026. Ask a mentor.
exit /b 2

:nogradle
echo gradlew.bat is missing from %~dp0
echo Extract the whole sim-starter ZIP again, then try once more.
exit /b 2
