@echo off
rem ===========================================================================
rem  robot.cmd  -  build, simulate or test this project with WPILib 2026's Java
rem
rem    .\robot                                   start the simulation
rem    .\robot build                             compile and run the reference test
rem    .\robot test -PcheckStudent --rerun-tasks check your own labs (after Lab 6)
rem    .\robot lab8                              add Lesson 8's starter files to src
rem    .\robot lab7                              add Lab 7's starter files to src
rem
rem  lab8 and lab7 copy only files that src does not have yet, so they never
rem  replace your own edits. Anything else after "robot" is passed straight to
rem  Gradle, so
rem  .\robot test --tests "frc.robot.LightCommandTest" works too.
rem
rem  To stop the simulation: click in the Terminal and press Ctrl+C. Windows
rem  then asks "Terminate batch job (Y/N)?" - type Y and press Enter.
rem
rem  On Windows, WPILib 2026 always installs into %PUBLIC%\wpilib\2026
rem  (normally C:\Users\Public\wpilib\2026). Mentors: if your 2026 JDK is
rem  somewhere else, set WPILIB_2026_JDK to that jdk folder first.
rem ===========================================================================
setlocal EnableExtensions DisableDelayedExpansion

rem ---- 0. ".\robot lab8" / ".\robot lab7": add a lab's starter files ---------
if /i "%~1"=="lab8" (
  set "LAB=command-lab"
  set "LESSON=Lesson 8"
  goto :addlab
)
if /i "%~1"=="lab7" (
  set "LAB=mechanism-lab"
  set "LESSON=Lab 7"
  goto :addlab
)

rem ---- 1. Find the WPILib 2026 Java (same rule the WPILib installer uses) ----
if defined WPILIB_2026_JDK (
  set "JDK=%WPILIB_2026_JDK%"
) else if defined PUBLIC (
  set "JDK=%PUBLIC%\wpilib\2026\jdk"
) else (
  set "JDK=C:\Users\Public\wpilib\2026\jdk"
)
if not exist "%JDK%\bin\java.exe" goto :nojava
"%JDK%\bin\java.exe" -version 2>&1 | findstr /r /c:"version .17\." >nul
if errorlevel 1 goto :wrongjava

rem ---- 2. Gradle reads JAVA_HOME. Run from this project's own folder. -------
set "JAVA_HOME=%JDK%"
cd /d "%~dp0"
if not exist "gradlew.bat" goto :nogradle
if "%~1"=="" goto :simulate
call gradlew.bat %*
exit /b %ERRORLEVEL%

:simulate
call gradlew.bat simulateJava
exit /b %ERRORLEVEL%

:addlab
rem robocopy /XC /XN /XO copies only files that are not in src yet. Exit codes:
rem bit 1 = files copied, 8 or more = failure.
set "FROM=%~dp0%LAB%\starter\src"
if not exist "%FROM%\" goto :nolab
echo Adding the %LESSON% starter files to src. Files you already have are kept.
robocopy "%FROM%" "%~dp0src" /E /XC /XN /XO /XX /NJH /NJS /NDL /NC /NS /NP
set "COPIED=%ERRORLEVEL%"
if %COPIED% GEQ 8 goto :copyfailed
set /a COPIED=COPIED %% 2
if "%COPIED%"=="1" (
  echo Done. The files listed above are now in src.
) else (
  echo Nothing new to add: these files are already in src. Your edits were kept.
)
exit /b 0

:nolab
echo This folder has no %LAB%\starter\src.
echo Extract the whole sim-starter ZIP again, or ask a mentor.
exit /b 1

:copyfailed
echo Copying the %LESSON% files failed. Nothing you edited was replaced. Ask a mentor.
exit /b 1

:nojava
echo Could not find the Java that WPILib 2026 installs.
echo Looked for: %JDK%\bin\java.exe
echo Install WPILib 2026 (Lesson 1, step 1) or ask a mentor for help.
exit /b 2

:wrongjava
echo The Java found at %JDK% is not Java 17.
echo This project needs the Java 17 that comes with WPILib 2026. Ask a mentor.
exit /b 2

:nogradle
echo gradlew.bat is missing from %~dp0
echo Extract the whole sim-starter ZIP again, then try once more.
exit /b 2
