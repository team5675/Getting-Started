package frc.robot.commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.TrainingRoller;
import frc.robot.subsystems.TrainingRoller.Request;

/** Stop on a sensor OR a two-second limit. Sensor wins if both occur together. */
public class CaptureObject extends Command {
    private final TrainingRoller roller;
    private final Timer timer = new Timer();
    public CaptureObject(TrainingRoller roller) {
        this.roller = roller;
        addRequirements(roller); // Conflicting commands interrupt this one.
    }
    @Override public void initialize() {
        timer.restart(); // A fresh timer for EVERY execution, including repeats.
        roller.setResult("RUNNING");
        // TODO: ask the roller to RUN.
    }
    @Override public boolean isFinished() {
        return timer.hasElapsed(2.0); // TODO: also finish when the sensor sees an object.
    }
    @Override public void end(boolean interrupted) {
        // Interrupted does not mean timed out: disable and conflicts also cancel.
        String reason = interrupted ? "INTERRUPTED" : roller.hasObject() ? "SENSOR" : "TIMEOUT";
        roller.stop();
        timer.stop();
        roller.setResult(reason);
        System.out.println("Roller finished: " + reason);
    }
}
