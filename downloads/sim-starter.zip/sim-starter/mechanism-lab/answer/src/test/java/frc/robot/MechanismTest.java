package frc.robot;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.wpilibj.simulation.DriverStationSim;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import edu.wpi.first.wpilibj2.command.Commands;
import frc.robot.commands.CaptureObject;
import frc.robot.subsystems.TrainingRoller;

/** Native scheduler tests of the student's mechanism; no browser or robot needed. */
public class MechanismTest {
    private void step(double seconds) {
        for(int i=0;i<(int)Math.ceil(seconds/.02);i++) {
            SimHooks.stepTiming(.02);
            CommandScheduler.getInstance().run();
        }
    }
    @Test void sensorTimeoutInterruptionAndRepeat() {
        HAL.initialize(500,0); SimHooks.pauseTiming(); DriverStationSim.resetData();
        var scheduler=CommandScheduler.getInstance();
        scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
        SimControls.publish(new TrainingInput("teleop",0,0,0,false,false,false,0,false));
        AtomicBoolean sensor=new AtomicBoolean(false);
        TrainingRoller roller=new TrainingRoller(sensor::get);
        try {
            CaptureObject command=new CaptureObject(roller);
            scheduler.schedule(command); step(.1);
            assertEquals(.4,roller.appliedOutput(),1e-9,"Requested RUNNING is applied");
            sensor.set(true); step(.04);
            assertFalse(command.isScheduled());
            assertEquals("SENSOR",roller.getResult());
            assertEquals(0,roller.appliedOutput());
            // Already-true sensor finishes immediately on another execution.
            scheduler.schedule(command); step(.02);
            assertFalse(command.isScheduled()); assertEquals("SENSOR",roller.getResult());
            sensor.set(false); scheduler.schedule(command); step(2.1);
            assertFalse(command.isScheduled()); assertEquals("TIMEOUT",roller.getResult());
            assertEquals(0,roller.appliedOutput());
            // Same command object can run again: timer must have restarted.
            scheduler.schedule(command); step(.1); assertTrue(command.isScheduled());
            scheduler.schedule(Commands.runOnce(roller::stop,roller)); step(.02);
            assertEquals("INTERRUPTED",roller.getResult()); assertEquals(0,roller.appliedOutput());
            scheduler.schedule(command); step(.1);
            SimControls.publish(TrainingInput.disabled()); step(.04);
            assertFalse(command.isScheduled()); assertEquals("INTERRUPTED",roller.getResult());
            assertEquals(TrainingRoller.Request.STOPPED,roller.getRequest());
            SimControls.publish(new TrainingInput("teleop",0,0,0,false,false,false,0,false));
            step(.04); assertEquals(0,roller.appliedOutput(),"Re-enable does not resume a canceled request");
        } finally {
            scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
            SimControls.publish(TrainingInput.disabled()); SimHooks.resumeTiming();
        }
    }
}
