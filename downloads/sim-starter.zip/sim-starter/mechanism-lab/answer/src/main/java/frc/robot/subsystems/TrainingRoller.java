package frc.robot.subsystems;

import java.util.function.BooleanSupplier;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import org.littletonrobotics.junction.Logger;

/** Lab 7: a fictional mechanism; no motor or 2027 game piece is modeled.
 * Requests describe intent. The input supplier reports a separate sensor fact.
 * Ordinary command requirements decide ownership; this is NOT a priority manager.
 */
public class TrainingRoller extends SubsystemBase {
    public enum Request { STOPPED, RUNNING, EJECTING }
    private Request requested = Request.STOPPED;
    private final BooleanSupplier objectPresent;
    private String result = "IDLE";
    public TrainingRoller(BooleanSupplier objectPresent) { this.objectPresent = objectPresent; }
    public void request(Request next) {
        requested = next;
    }
    public void stop() { requested = Request.STOPPED; }
    public Request getRequest() { return requested; }
    public boolean hasObject() { return objectPresent.getAsBoolean(); }
    public void setResult(String next) { result = next; }
    public String getResult() { return result; }
    public double appliedOutput() {
        if (DriverStation.isDisabled()) return 0;
        return switch (requested) {
            case RUNNING -> 0.4;
            case EJECTING -> -0.3;
            case STOPPED -> 0.0;
        };
    }
    @Override public void periodic() {
        Logger.recordOutput("Training/Roller/Request", requested.toString());
        Logger.recordOutput("Training/Roller/AppliedOutput", appliedOutput());
        Logger.recordOutput("Training/Roller/ObjectPresent", hasObject());
        Logger.recordOutput("Training/Roller/Result", result);
    }
}
