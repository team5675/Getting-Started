Use the matching mechanism-lab.html (Lab 7) on the course website.
Add the starter files to your project: in the Terminal, type  .\robot lab7
It copies starter/src files to the same paths under src and never replaces
a file you already have, so your own edits are kept.
Complete TODOs before consulting answer. The test files check your edited classes.
