Use the matching mechanism-lab.html (Lab 7) on the course website.
Copy starter/src files to the same paths under your project src.
Do not overwrite your own edits without a backup or Git checkpoint.
Complete TODOs before consulting answer. The test files check your edited classes.
