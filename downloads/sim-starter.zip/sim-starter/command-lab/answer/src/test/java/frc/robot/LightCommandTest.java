package frc.robot;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import edu.wpi.first.hal.HAL;
import edu.wpi.first.wpilibj.simulation.SimHooks;
import edu.wpi.first.wpilibj2.command.CommandScheduler;
import frc.robot.commands.LightForSeconds;
import frc.robot.subsystems.PracticeLight;

public class LightCommandTest {
    @Test void startsFinishesRepeatsAndCleansUp() {
        HAL.initialize(500,0); SimHooks.pauseTiming();
        var scheduler=CommandScheduler.getInstance();
        scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
        SimControls.publish(new TrainingInput("teleop",0,0,0,false,false,false,0,false));
        var light=new PracticeLight();
        var command=new LightForSeconds(light,.1);
        try {
            scheduler.schedule(command); scheduler.run(); assertTrue(light.isOn());
            SimHooks.stepTiming(.12); scheduler.run();
            assertFalse(command.isScheduled()); assertFalse(light.isOn());
            scheduler.schedule(command); scheduler.run(); assertTrue(light.isOn());
            SimControls.publish(TrainingInput.disabled()); scheduler.run();
            assertFalse(command.isScheduled()); assertFalse(light.isOn());
        } finally {
            scheduler.cancelAll(); scheduler.unregisterAllSubsystems();
            SimControls.publish(TrainingInput.disabled()); SimHooks.resumeTiming();
        }
    }
}
