package frc.robot.commands;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.PracticeLight;

/** Lesson 8 authoring exercise: a command that finishes itself after a duration. */
public class LightForSeconds extends Command {
    private final PracticeLight light;
    private final double seconds;
    private final Timer timer = new Timer();
    public LightForSeconds(PracticeLight light, double seconds) {
        if (!Double.isFinite(seconds) || seconds < 0) throw new IllegalArgumentException("Use a finite nonnegative duration");
        this.light = light;
        this.seconds = seconds;
        addRequirements(light);
    }
    @Override public void initialize() {
        timer.restart();
        // TODO: turn the light on.
    }
    @Override public boolean isFinished() {
        return timer.hasElapsed(seconds);
    }
    @Override public void end(boolean interrupted) {
        // TODO: turn the light off, including when interrupted.
        timer.stop();
    }
}
