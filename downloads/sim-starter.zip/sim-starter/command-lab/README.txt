Use the matching first-command.html (Lesson 8) on the course website.
Add the starter files to your project: in the Terminal, type  .\robot lab8
It copies starter/src files to the same paths under src and never replaces
a file you already have, so your own edits are kept.
Complete TODOs before consulting answer. The test files check your edited classes.
